namespace CosmosValidationAPI.Models
{
    public class IndexSearchRequest
    {
        public SearchInfo? SearchInfo { get; set; }
        public string? Search_Type { get; set; }
        public string? Match_Type { get; set; }
        public List<string>? FNF_DocType { get; set; }
    }

    public class SearchInfo
    {
        public string? FIPS { get; set; }
        public string? APN { get; set; }
        public string? DPID { get; set; }
    }

    public class FunctionValidation
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? SubscriptionDetails { get; set; }
    }
}

using CosmosValidationAPI.Models;
using CosmosValidationAPI.Services;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json.Linq;

namespace CosmosValidationAPI.Validations
{
    public static class ValidationAPISubscription
    {
        public static async Task<FunctionValidation> CheckAccess(
            string? SubscriptionId, string? ClientId, string? Database,
            string? Container, List<string>? FNF_DocType, IConnection _connection)
        {
            FunctionValidation indexSearchValidation = new FunctionValidation { Success = true, Message = string.Empty };
            List<string> permitted_DocTypes = new List<string>();

            CosmosClient client = _connection.GetReadCosmosClient();
            Container subscriptionContainer = client.GetContainer(_connection.SubscriptionDatabase, _connection.SubscriptionContainer);

            var docTypeParams = new List<string>();
            for (int i = 0; i < FNF_DocType.Count; i++)
            {
                docTypeParams.Add($"@docType{i}");
            }

            var query = new QueryDefinition(
                "SELECT VALUE { FNF_DocType: c.FNF_DocType, SubscriptionName: c.SubscriptionName } " +
                "FROM c " +
                "WHERE c.SubscriptionId = @subscriptionId " +
                "AND c.ClientId = @clientId " +
                $"AND c.FNF_DocType IN ({string.Join(",", docTypeParams)}) " +
                "AND c.Database = @database " +
                "AND c.Container = @container " +
                "AND c.IsEnabled = true")
                .WithParameter("@subscriptionId", SubscriptionId?.ToUpper())
                .WithParameter("@clientId", ClientId?.ToUpper())
                .WithParameter("@database", Database) // Exact case match
                .WithParameter("@container", Container); // Exact case match

            for (int i = 0; i < FNF_DocType.Count; i++)
            {
                query = query.WithParameter($"@docType{i}", FNF_DocType[i].ToUpper());
            }

            var queryResultSetIterator = subscriptionContainer.GetItemQueryIterator<dynamic>(query);

            while (queryResultSetIterator.HasMoreResults)
            {
                var currentResultSet = await queryResultSetIterator.ReadNextAsync();
                foreach (var item in currentResultSet)
                {
                    string strFNF_DocType = ((JValue)item["FNF_DocType"]).Value.ToString();
                    string strSubscriptionName = ((JValue)item["SubscriptionName"]).Value.ToString();

                    permitted_DocTypes.Add(strFNF_DocType);
                    indexSearchValidation.SubscriptionDetails = "SubscriptionName: " + strSubscriptionName;
                }
            }

            List<string> notpermitted_DocTypes = FNF_DocType.Except(permitted_DocTypes, StringComparer.OrdinalIgnoreCase).ToList();

            if (notpermitted_DocTypes.Count > 0)
            {
                indexSearchValidation.Success = false;
                indexSearchValidation.Message = $"Not allowed DocTypes: {string.Join(", ", notpermitted_DocTypes)}. \n" +
                                                $"[DEBUG] Queried With: SubId='{SubscriptionId}', ClientId='{ClientId}', " +
                                                $"DB='{Database}', Container='{Container}'. Did these match your Cosmos Document exactly?";
            }

            return indexSearchValidation;
        }
    }
}

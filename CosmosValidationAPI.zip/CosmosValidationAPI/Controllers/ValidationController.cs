using CosmosValidationAPI.Models;
using CosmosValidationAPI.Services;
using CosmosValidationAPI.Validations;
using Microsoft.AspNetCore.Mvc;

namespace CosmosValidationAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ValidationController : ControllerBase
    {
        private readonly IConnection _connection;

        public ValidationController(IConnection connection)
        {
            _connection = connection;
        }

        // URL Route captures Database and Container: /api/Validation/IndexSearch/ext_icex_Dpid/property
        [HttpPost("IndexSearch/{database}/{container}")]
        public async Task<IActionResult> IndexSearch(
            string database, 
            string container, 
            [FromBody] IndexSearchRequest request,
            
            // Extract IDs from headers (defaults provided for easy testing in swagger)
            [FromHeader(Name = "clientId")] string clientId = "860924A2-F625-4ED1-A463-0069FCD2C0B7",
            [FromHeader(Name = "subscriptionId")] string subscriptionId = "621A129D1C7C4873B5FD892F874F350A")
        {
            if (request == null || request.FNF_DocType == null || request.FNF_DocType.Count == 0)
            {
                return BadRequest("Invalid request body. Ensure FNF_DocType is provided.");
            }

            try
            {
                FunctionValidation result = await ValidationAPISubscription.CheckAccess(
                    subscriptionId,
                    clientId,
                    database,
                    container,
                    request.FNF_DocType,
                    _connection);

                if (!result.Success)
                {
                    return BadRequest(new
                    {
                        responseCode = "LSA_06",
                        responseCodeDescription = "ValidationError",
                        message = result.Message,
                        responseTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
                    });
                }

                return Ok(new 
                { 
                    message = "Access verified successfully.", 
                    validationDetails = result 
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Cosmos Error: {ex.Message}");
            }
        }
    }
}

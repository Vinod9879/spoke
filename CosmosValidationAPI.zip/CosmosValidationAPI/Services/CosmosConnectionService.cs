using Microsoft.Azure.Cosmos;

namespace CosmosValidationAPI.Services
{
    public interface IConnection
    {
        string SubscriptionDatabase { get; }
        string SubscriptionContainer { get; }
        CosmosClient GetReadCosmosClient();
    }

    public class CosmosConnectionService : IConnection
    {
        private readonly CosmosClient _cosmosClient;
        public string SubscriptionDatabase { get; }
        public string SubscriptionContainer { get; }

        public CosmosConnectionService(IConfiguration configuration)
        {
            var config = configuration.GetSection("Cosmos");
            
            string connectionString = config["ConnectionString"] ?? throw new ArgumentNullException("ConnectionString missing");
            SubscriptionDatabase = config["Database"] ?? throw new ArgumentNullException("Database missing");
            SubscriptionContainer = config["Container"] ?? throw new ArgumentNullException("Container missing");

            _cosmosClient = new CosmosClient(connectionString, new CosmosClientOptions
            {
                ConnectionMode = ConnectionMode.Direct
            });
        }

        public CosmosClient GetReadCosmosClient() => _cosmosClient;
    }
}

using CosmosValidationAPI.Services;

var builder = WebApplication.CreateBuilder(args);

// Add API Controllers
builder.Services.AddControllers();

// Add Swagger for easy UI testing
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Inject our Cosmos DB Connection Service
builder.Services.AddSingleton<IConnection, CosmosConnectionService>();

var app = builder.Build();

// Configure pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// app.UseHttpsRedirection(); // Removed to prevent localhost port crash
app.UseAuthorization();
app.MapControllers();

app.Run();

﻿using Newtonsoft.Json.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Serialization;


namespace SpokeAPI.Models
{
    public class IndexSearchModel
    {
        public class IndexSearchRequest
        {
            public SearchInfo? searchInfo { get; set; }
            public string? Search_Type { get; set; }
            public string? Match_Type { get; set; }
            public List<string>? FNF_DocType { get; set; }
            public string? Database { get; set; }
            public string? Container { get; set; }
            public string? SubscriptionKey { get; set; }
            public string? TransactionId { get; set; }
            public string? ClientId { get; set; }

            public string? query { get; set; }
            public bool boolFpsNApnDpidSearch { get; set; } = false;
            public bool boolFipsFullStreetCityState { get; set; } = false;
            public bool boolFipsFullStZipCode { get; set; } = false;

            public bool boolFipsRecordingDateDocumentNumberFileType { get; set; }

            public bool isFipsRecordingDateDocumentNumberFileType()
            {
                boolFipsRecordingDateDocumentNumberFileType = !string.IsNullOrWhiteSpace(searchInfo?.FIPS?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.RecordingDate?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.DocumentNumber?.ToString());
                return boolFipsRecordingDateDocumentNumberFileType;
            }

            public bool boolFipsRecordingDateBookNumberPageNumberFileType { get; set; }

            public bool isFipsRecordingDateBookNumberPageNumberFileType()
            {
                boolFipsRecordingDateBookNumberPageNumberFileType = !string.IsNullOrWhiteSpace(searchInfo?.FIPS?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.RecordingDate?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.BookNumber?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.PageNumber?.ToString());
                return boolFipsRecordingDateBookNumberPageNumberFileType;
            }
            public bool isFipsApnDipdSearch()
            {
                boolFpsNApnDpidSearch = !string.IsNullOrWhiteSpace(searchInfo?.APN?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.FIPS?.ToString()) && string.IsNullOrWhiteSpace(searchInfo?.DPID?.ToString());
                if(boolFpsNApnDpidSearch)
                return boolFpsNApnDpidSearch;
                else
                    boolFpsNApnDpidSearch = string.IsNullOrWhiteSpace(searchInfo?.APN?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.FIPS?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.DPID?.ToString());
                    return boolFpsNApnDpidSearch;
            }
            public bool isFipsFullStCityState()
            {
                boolFipsFullStreetCityState = !string.IsNullOrWhiteSpace(searchInfo?.FIPS?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.FullStreetAddress?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.City?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.State?.ToString());
                return boolFipsFullStreetCityState;
            }
            public bool isFipsFullStZip()
            {
                boolFipsFullStZipCode = !string.IsNullOrWhiteSpace(searchInfo?.FIPS?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.FullStreetAddress?.ToString()) && !string.IsNullOrWhiteSpace(searchInfo?.Zip?.ToString());
                return boolFipsFullStZipCode;
            }
        }
        public class SearchInfo
        {
            [Required]
            [Display(Name = "Fips")]
            public string? FIPS { get; set; } = string.Empty;
            [Display(Name = "Apn")]
            public string? APN { get; set; } = string.Empty;
            [Display(Name = "Apn")]
            public string? DPID { get; set; } = string.Empty;
            [Display(Name = "OwnerName")]
            public string? OwnerName { get; set; } = string.Empty;
            [Display(Name = "Property_Full_Street_Address")]
            public string? FullStreetAddress { get; set; } = string.Empty;
            [Display(Name = "Property_Unit_Number")]
            public string? UnitNumber { get; set; } = string.Empty;
            [Display(Name = "Property_City_Name")]
            public string? City { get; set; } = string.Empty;
            [Display(Name = "Property_State")]
            public string? State { get; set; } = string.Empty;
            [Display(Name = "Property_Zip_Code")]
            public string? Zip { get; set; } = string.Empty;
            [Display(Name = "Property_Zip_4")]
            public string? Zip4 { get; set; } = string.Empty;

            [Display(Name = "RecordingDate")]
            public string? RecordingDate { get; set; } = string.Empty;
            [Display(Name = "DocumentNumber")]
            public string? DocumentNumber { get; set; } = string.Empty;
            [Display(Name = "BookNumber")]
            public string? BookNumber { get; set; } = string.Empty;
            [Display(Name = "PageNumber")]
            public string? PageNumber { get; set; } = string.Empty;

        }

        public class IndexSearchPropertyResponse
        {
            public DateTime? responseDateTime { get; set; } = DateTime.UtcNow;
            public string? responseCode { get; set; }
            public string? responseCodeDescription { get; set; }
            [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
            public SearchInfo? searchInfo { get; set; }
            [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
            public JsonDocument? responseJson { get; set; }

        }


        public class IndexSearchPropertySearchResponse
        {
            public DateTime? responseDateTime { get; set; } = DateTime.UtcNow;
            public string? responseCode { get; set; }
            public string? responseCodeDescription { get; set; }
            public JsonDocument? responsePicklist { get; set; }

        }
      

        public class IndexSearchValidationResponse
        {
            public Response? Create(string code, string codedescription, string msg)
            {
                return new Response { ResponseCode = code, ResponseCodeDescription = codedescription, Message = msg };
            }
            public class Response
            {
                public string? ResponseCode { get; set; }
                public string? ResponseCodeDescription { get; set; }
                public string? Message { get; set; }
                public string ResponseTime => DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
            }

        }

        public class SearchQueryParameters
        {
            public string? SearchProperty { get; set; }
            public string? SearchPropertyDBname { get; set; }
            public string? SearchPropertyValue { get; set; }

        }
        public class DocumentProperySearchResponse
        {
            public string? id { get; set; }
            public string? Fips_APN { get; set; }
            public string? FNF_DocType { get; set; }
        }

        public class QuerySearchResult
        {
            public List<dynamic>? dynamicListResult { get; set; }
            public JObject? JObjectResult { get; set; }
            public bool boolJsonDocument { get; set; } = false;

            public int CountResult { get; set; } = 0;

            public int TotalTimeProperyContainerSearch { get; set; } = 0;
            public double TotalTimeProperyContainerRequestCharge { get; set; } = 0;
            public int TotalTimePropertySearchContainerSearch { get;set; } = 0;
            public double TotalPropertySearchContainerRequestCharge{ get; set; } = 0;

        }
    }
}

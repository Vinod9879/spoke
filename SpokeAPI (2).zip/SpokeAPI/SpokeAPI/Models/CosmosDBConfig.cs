﻿

using Microsoft.Identity.Client;

namespace SpokeAPI.Models
{
    public class CosmosDBConfig
    {
        public string? database { get; set; }
        public string? container { get; set; }
        public List<string>? fnf_doctype { get; set; }
        public List<string>? search_type { get; set; }
        public List<string>? query_params { get; set; }
    }

    public class ConfigPartitionKeys
    {
        public string? database { get; set; }
        public string? container { get; set; }
        public List<string>? query_params { get; set; }
        public Dictionary<string, string>? partitionsKeyHypenAlias { get; set; } = new Dictionary<string, string>();

    }

    public class CosmosDBConfigValidation
    {
        public bool? Success { get; set; } = true;
        public string? Message { get; set; }
    }

    public class CosmosDBObject_Request
    {
        public string? database { get; set; }
        public string? container { get; set; }  
        public scaleandSettings? scaleandSettings { get; set; }
        public string? OperationType { get; set; }
        public string? AccountTotalThroughputLimit { get; set; }
        public string? TimeToLive { get; set; } = "false";


    }
    public class scaleandSettings
    {
        public string? throughput { get; set; }
        public List<string>?  partitionkey { get; set; }
        public IndexingPolicy? indexingPolicy { get; set; }

    }
    public class IndexingPolicy
    {
        public List<string>? IncludePath { get; set; }
        public List<string>? ExcludePath { get; set; }
    }



    public class CosmosDBVersion
    {
        public List<Version_Config>? Containers { get; set; }
        public List<Version_Config>? Databases { get; set; }
    }

    public class Version_Config
    {
        public string LookupName { get; set; } = string.Empty;
        public string LookupValue { get; set; } = string.Empty;
    }
}

﻿

namespace SpokeAPI.Models
{
    public class ManageSubscriptionsModels
    {
        public  string? id { get; set; }
        public string? SubscriptionId { get; set; }
        public string? SubscriptionName { get; set; }
        public string? Database { get; set; }
        public string? Container { get; set; }
        public string? FNF_DocType { get; set; }
        public string? ClientId { get; set; }
        public bool? IsEnabled { get; set; }
        public List<AuditHistory>? AuditHistory { get; set; }
    }
    public class AuditHistory
    { 
        public DateTime LastModifiedDate { get; set; }
        private  string? _UpdatedByClientId  { get; set; }
        public string? UpdatedByClientId { get => _UpdatedByClientId; set { _UpdatedByClientId = value?.ToUpper(); } }
        private string? _UpdatedBySubscriptionId { get; set; }
        public string? UpdatedBySubscriptionId { get => _UpdatedBySubscriptionId; set { _UpdatedBySubscriptionId = value?.ToUpper(); } }
        public bool? IsEnabled { get; set; } =false;
    }

    public class ManageSubscriptionRequest
    {
        private string? _subscriptionid = string.Empty;
        public string? SubscriptionId { get => _subscriptionid; set { _subscriptionid = value?.ToUpper(); } }
        private string? _SubscriptionName = string.Empty;
        public string? SubscriptionName { get => _SubscriptionName; set { _SubscriptionName = value?.ToUpper(); } }
        private string? _Clientid = string.Empty;
        public string? Clientid { get => _Clientid; set { _Clientid = value?.ToUpper(); } }
        private string? _Database = string.Empty;
        public string? Database { get => _Database; set { _Database = value?.ToLower(); } }
        private string? _Container = string.Empty;
        public string? Container { get => _Container; set { _Container = value?.ToLower(); } }
        private string? _FNF_DocType = string.Empty;
        public string? FNF_DocType { get => _FNF_DocType; set { _FNF_DocType = value?.ToUpper(); } }

        public bool? IsEnabled { get; set; } = null;
        private string? _transactionID = string.Empty;
        public string? TransactionID { get => _transactionID; set { _transactionID = value?.ToUpper(); } }

    }


}

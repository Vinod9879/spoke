﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.PointedLookupModel;

namespace SpokeAPI.Models
{
    public class QueryAPIModel
    {
        public class QueryAPIRequest
        {
            public string? Database { get; set; }
            public string? Container { get; set; }
            public string? ContinuationToken { get; set; }
            public string? query { get; set; }
            public string? IDKey { get; set; }
            public string? IDValue { get; set; }
            public string? PartionKey1 { get; set; }
            public string? PartionKey1Value { get; set; }
            public string? PartionKey2 { get; set; }
            public string? PartionKey2Value { get; set; }
            public string? PartionKey3 { get; set; }
            public string? PartionKey3Value { get; set; }
            public string? SubscriptionKey { get; set; }
            public string? TransactionId { get; set; }
            public string? ClientId { get; set; }
            public string? RequestBody { get; set; }
            public HttpRequest? req { get; set; }
            public Dictionary<string , string >? QueryParameter { get; set; }
           public IEnumerable<List<string>>? PartitionKeys {  get; set; }
              
        }
        public class QueryAPIResult
        {
            public List<dynamic>? dynamicListResult { get; set; }
            // public JObject? JObjectResult { get; set; }
            //  public bool boolJsonDocument { get; set; } = false;
            // public int CountResult { get; set; } = 0;
            public string? continuationOptions { get; set; }
            public int TotalTimeQueryAPISearch { get; set; } = 0;
            public double TotalRequestChargeQueryAPI { get; set; } = 0;
          
        }

        public class QuerySearchResponse
        {
            public DateTime? responseDateTime { get; set; } = DateTime.UtcNow;
            public string? responseCode { get; set; }
            public string? responseCodeDescription { get; set; }
            public string? ContinuationToken { get; set; }
            public List<dynamic>? responseJson { get; set; }
        }

        public class ParseQueryAPIRequest
        {
         public   QueryAPIRequest? queryAPIRequest { get; set; }
            public FunctionValidation? functionValidation { get; set; }

        }
    }
}

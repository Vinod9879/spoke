﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Cosmos;
using System.Text.Json;

namespace SpokeAPI.Models
{
    public class PointedLookupModel
    {
        public class PointedLookupRequest
        {
            public string? Database { get; set; }
            public string? Container { get; set; }
            public string? IDKey { get; set; }
            public string? IDValue { get; set; }
            public string? PartionKey1 { get; set; }
            public string? PartionKey1Value { get; set; }
            public string? PartionKey2 { get; set; }
            public string? PartionKey2Value { get; set; }
            public string? PartionKey3 { get; set; }
            public string? PartionKey3Value { get; set; }
            public string? FNF_DocType { get; set; }
            public int? NumberofPartitionKey { get; set; } = 0;
            public string? SubscriptionKey { get; set; }
            public string? ClientId { get; set; }
            public PartitionKey PartitionKey { get; set; }
            public HttpRequest? Req { get; set; }
            public Dictionary<string, string>? ReqParameter { get; set; }

        }


        public class PointedLookupResponse
        {
            public DateTime? responseDateTime { get; set; } = DateTime.UtcNow;
            public string? responseCode { get; set; }
            public string? responseCodeDescription { get; set; }
            public JsonDocument? responseJson { get; set; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Models
{
    public class CommonModels
    {
        public class FunctionResponse
        {
            public Response? Create(string code, string codedescription, string msg)
            {
                return new Response { ResponseCode = code, ResponseCodeDescription = codedescription, Message = msg };
            }

            public class Response
            {
                public string ResponseTime => DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
                public string? ResponseCode { get; set; }
                public string? ResponseCodeDescription { get; set; }
                public string? Message { get; set; }
               
            }
        }


        public class FailedResponse
        {
            public DateTime? responseDateTime { get; set; } = DateTime.UtcNow;
            public string? responseCode { get; set; }
            public string? responseCodeDescription { get; set; }
            [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
            public string? message { get; set; }


        }

        public class FunctionValidation
        {
            public bool? Success { get; set; } = true;
            public string? Message { get; set; } = string.Empty;
            public int TotalTimeCheckAccess { get; set; } = 0;
            public double? TotalRequestChargeCheckAccess { get; set; } = 0.00;
            public string? CheckAccesQuery { get; set; } = string.Empty;

            public double? TotalRequestchargeManagesubscription { get; set; } = 0.00;
            public double? TotalTimeManagesubscription { get; set; } = 0.00;
            public string? SubscriptionDetails { get; set; } = "";
            public int StatusCode { get; set; }
            public string? ResponseCodeDescription { get; set; }
            public string? ResponseCode { get; set; }
        }
        public class ValidationResponse
        {
            public string? ResponseCode { get; set; }
            public string? ResponseCodeDescription { get; set; }
            public string? Message { get; set; }
            public string? ResponseTime => DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
        }
        public static class GlobalTransactionID
        {
            public static string? TransactionID { get; set; } = " ";

        }
      
    }
}
    

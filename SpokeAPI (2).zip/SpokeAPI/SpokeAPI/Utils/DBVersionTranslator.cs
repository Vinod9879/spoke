﻿#nullable disable

using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using System.Text.Json;

namespace SpokeAPI.Utils
{
    public static class DBVersionTranslator
    {
               public static string GetCurrentDBVersion(string databasename,IConnection _connection)
        {
            CosmosDBVersion CosmosDBVersion = JsonSerializer.Deserialize<CosmosDBVersion>(_connection.DatabaseVersionConfig);
            Version_Config dbver = CosmosDBVersion.Databases.Find(x => x.LookupName == databasename);
            return dbver == null ? databasename : dbver.LookupValue;
        }

        public static string GetCurrentContainerVersion(string container, IConnection _connection)
        {
            CosmosDBVersion CosmosDBVersion = JsonSerializer.Deserialize<CosmosDBVersion>(_connection.DatabaseVersionConfig);
            Version_Config containerver = CosmosDBVersion.Containers.Find(x => x.LookupName == container);
            return containerver == null ? container : containerver.LookupValue;
        }
    }
}

﻿using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Serialization.HybridRow.Schemas;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.EnumsLog;

namespace SpokeAPI.Utils
{
    public static class GetItemPointedSearch
    {
        public static async Task<JsonDocument> ReadItemAsync(Container container, String id , string partitionkey, ManageSubscriptionRequest manageSubscriptionRequest, FunctionValidation manageSubscriptionValidation,IConnection _connection, Microsoft.Extensions.Logging.ILogger<Functions.ManageSubscription> _logger, string TransactionId)
        {
            CosmosClient client = _connection.GetReadWriteCosmosClient();
            client.GetContainer(container.Database.Id, container.Id);
            Microsoft.Azure.Cosmos.PartitionKey partitionKeys = new Microsoft.Azure.Cosmos.PartitionKey(partitionkey);
            ItemResponse<ExpandoObject> response = await container.ReadItemAsync<ExpandoObject>(id, partitionKeys);
            manageSubscriptionValidation.TotalRequestchargeManagesubscription = response.RequestCharge;
            manageSubscriptionValidation.TotalTimeManagesubscription = response.Diagnostics.GetClientElapsedTime().Milliseconds;
            if (manageSubscriptionValidation.TotalRequestchargeManagesubscription != 0.00)
            _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails,
            manageSubscriptionRequest.SubscriptionId, ManageSubscription.SearchType, EnumsLog.ApiType.ManageSubscription, _connection.SubscriptionDatabase, _connection.SubscriptionContainer, manageSubscriptionValidation.TotalTimeManagesubscription, manageSubscriptionValidation.TotalRequestchargeManagesubscription, TransactionId);
            return JsonDocument.Parse(System.Text.Json.JsonSerializer.Serialize(response.Resource));
        }
    }
}

﻿

namespace SpokeAPI.Utils
{
    public static class EnumsLog
    {
        public static class ManageSubscription
        {
            public const string TriggeredManageSubscriptionfunction = "Triggered ManageSubscription function - SubscriptionID:'{0}',TransactionId:'{1}' ";
            public const string CompletedManageSubscriptionfunction = "Completed  ManageSubscription function - ResponseStatusDescription:'{0}' SubscriptionID:'{1}',TransactionId:'{2}'";
            public const string Started_UpsertSubscription_Method = "Started UpsertSubscription Method - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string No_change_in_upsert_operation = "No change in upsert operation - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Write_audit_history = "Write audit history - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Update_is_succes = "Update is success - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Existing_Subscription_not_found = "Existing Subscription not found - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Service_not_found_Please_check_service_client_and_container = "Service not found Please check service client and container - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Insert_is_successful = "Insert is successful - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string SearchType = "Subscription Search";
        }

        public static class IndexSearch
        {
            public const string TriggeredIndexSearchfunction = "Triggered IndexSearch function - SubscriptionID:'{0}' TransactionId:'{1}' ";
            public const string CompletedIndexSearchfunction = "Completed  IndexSearch function  - ResponseStatusDescription:'{0}' SubscriptionID:'{1}' TransactionId:'{2}'   ";
            public const string MalformedRequest_user_input = "MalformedRequest user input  - SubscriptionID:'{0}' TransactionId:'{1}' ";
            public const string Created_query = "Created query - Query:'{2}'  SubscriptionID:'{0}' TransactionId:'{1}' ";
            public const string Ended_Property_container_search = "Ended Property container search - SubscriptionID:'{0}' , TransactionId:'{1}'";
            public const string Intitiate_in_Property_Search_container_count_is_1 = "Intitiate Search  in Property container as count is 1 - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Getting_APN_from_propery_container_search_result = "Getting APN from propery container search result - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Getting_DPID_from_propery_container_search_result = "Getting DPID from propery container search result - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Intiated_in_Property_Search_container = "Intiated in Property_Search container - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Ended_in_Property_Search_container = "SuccessFul search in Property_Search container - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Started_in_Property_container_with_APN = "Started in Property container with APN - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Ended_search_in_Property_container_with_APN = "Ended search in Property container with APN - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Response_picklist_Property_Search_containe_more_result = "Response picklist Property_Search container has more than 1 result - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Intiatedthe_Query_in_Propery_container = "Intiated  the Query in Propery container - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Endthe_Query_in_Propery_container = "SuccessFul search in  in Propery container - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string InternalSeverError = "IndexSearch function Internal Server Error - Error: '{2}' SubscriptionID:'{0}' TransactionId:'{1}' ";
            public const string Resultnotfound = "Property container result not found - Error: '{1}' Details '{2}' SubscriptionID:'{3}' TransactionId:'{4}' ";

        }

        public static class PointedLookup
        {
            public const string TriggeredPointedLookupfunction = "Triggered PointLookup function - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string CompletedPointedLookupfunction = "Completed  PointLookup function -  ResponseStatusDescription:'{0}' SubscriptionID:'{1}',TransactionId:'{2}'";
            public const string Initiate_LookupAsync_method = "Initiate Point LookupAsync method - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Ordering_PartitionKey_and_assigning_to_pointedLookupRequest_ = "Ordering PartitionKey and assigning to pointLookupRequest - SubscriptionID:'{0}', TransactionId:'{1}' ";
            public const string Pointed_look_up_sucessfully_retrived_the_data = "Point look up sucessfully retrived the data - SubscriptionID:'{0}' , TransactionId:'{1}'";
        }
        public static class QueryAPI
        {
            public const string TriggeredQueryAPIfunction = "Triggered QueryAPI function - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string CompletedQueryAPIfunction = "Completed  QueryAPI function -  ResponseStatusDescription:'{0}' SubscriptionID:'{1}',TransactionId:'{2}'";
            public const string Initiate_GetQueryResult_method = "Initiate GetQueryResult method - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string InitiateDataBaseConnection = "Initiate database Connection - SubscriptionID:'{0}', TransactionId:'{1}' ";
            public const string InitiateQuery = " Initiate Query Request - SubscriptionID:'{0}',TransactionId:'{1}',Query:'{2}',Parameter:'{3}'";
            public const string QuerySuccessful = " QuerySuccessful - SubscriptionID:'{0}',TransactionId:'{1}'";
        }

        public static class ManageCosmosDB
        {
            public const string TriggeredManageCosmosDBfunction = "Triggered ManageCosmosDB function - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string CompletedManageCosmosDBfunction = "Completed  ManageCosmosDB function - ResponseStatusDescription:'{0}' SubscriptionID:'{1}',TransactionId:'{2}'";
            public const string CreatingNewdatabase = "Creating New Database - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string CreatingNewdatabaseSuccessful = "Creating New Database Success - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string DatabaseExists = "Database already exists - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string StartedUpdateThroughput = "Started UpdateThroughput - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string CompletedUpdateThroughputUpdate = "Completed UpdateThroughput update - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string CreatingContainerStarted = "Creating/Update Container Started - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string CreatingContainerSuccess = "Creating/Update Container Success - SubscriptionID:'{0}' ,TransactionId:'{1}'";
             
        }
     
            public static class General
        {
            public const string Validating_user_input = "Validating user input - SubscriptionID:'{0}',TransactionId:'{1}'";
            public const string Validation_error = "Validation error - SubscriptionID:'{0}' TransactionId:'{1}'";
            public const string Validation_success = "Validation success - SubscriptionID:'{0}' TransactionId:'{1}'";
            public const string Validation_failed = "Validation failed - SubscriptionID:'{0}' TransactionId:'{1}'";
            public const string ResourcesContainer_not_found = "Resources/Container not found - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Service_not_found_Please_check_service_client_and_container = "Service not found Please check service client and container - SubscriptionID:'{0}' ,TransactionId:'{1}'";
            public const string Readbodyissuccessfull = "Read body is successful - SubscriptionID:'{0}' TransactionId:'{1}'";
            public const string FailedtoReadtheBody = "Failed to read the body - SubscriptionID:'{0}' TransactionId:'{1}'";
            public const string Checkaccesscomplete = "Check access complete - ";
            public const string SubscriptionID = " SubscriptionID:";
            public const string TransactionId = " TransactionId:";
            public const string FnfDocType = " FnfDocType:";
            public const string SubscriptionName = " SubscriptionName:";
        }
      
        public static class TotalTimeAndRequestChargeLog
        {
            public const string TotalTimeAndRequestChargeLogDetails = "Database Metric - SubscriptionID: {0},SearchType: {1}, APIType:{2}, Database: {3}, Container: {4}, TimeElapsed: {5} ms, RequestCharge: {6},TransactionId:'{7}'";
        }
        public static class ApiType
        {
            public const string IndexSearch = "IndexSearch";
            public const string PointedLookup = "PointLookup";
            public const string ManageSubscription = "ManageSubscription" ;
            public const string QueryAPI = "QueryAPI";
        }
    }
}

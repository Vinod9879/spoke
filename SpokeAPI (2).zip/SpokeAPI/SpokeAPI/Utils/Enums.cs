﻿

using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Utils
{
    public static class Enums
    {
        public static class QueryAPIMessages
        {
            public const string invalidJsonBody = "Provided Body not a valid Json";
            public const string InputNotinExpectedformatBodycannotBeEmpty = "Input not in expected format - Body cannot be empty";
            public const string InputJsonBodyNotValid = "Input not in expected format - Read body failed, Json not Valid";
            public const string InputInvalid = "Input not in expected format - Read body failed, Json not Valid";
            public const string InputNotinExpectedformatKeywordNotMatching = "Input not in expected format - Keyword missmatch either query or parameter";
            public const string FailedToParseTherequest = "Input not in expected format - Failed To Parse The request";
            public const string FilterParameterCannotBeEmpty = "Input not in expected format - No Partition key filter applied";
            public const string InvalidPartitionKey = "Input not in expected format - Invalid Partition key filter applied";
            public const string FilterWhereClauseNotAppiled = "Input not in expected format - Filter not applied";
            public const string SubqueryAggregationFunctionsNotAllowed = "Input not in expected format - Join,Distinct,Group By,Order By,Order By Rank,Subquery are Invalid";
            public const string InputInvalidQueryParameterInvalid = "Input not in expected format - ContinuationToken is a valid Query Parameter";
            public const string InputInvalidQueryParameter = "Input not in expected format -  query or parameter not supplied";
        }
        public static class ManageSubscriptionMessages
        {
            public const string SubscriptionConfigCreatedsuccessfully = "Subscription Config Created successfully";
            public const string InternalErrorOccurredPleasecontactSupport = "Internal Server Error,Please Contact Support";
            public const string ProvidedSubscriptionConfigurationisalreadydisabled = "Provided Subscription Configuration is already disabled";
            public const string ProvidedSubscriptionConfigurationisalreadyenabled = "Provided Subscription Configuration is already enabled";
            public const string InputNotinExpectedformat = "Input not in expected format - Body cannot be empty";
            public const string InputBodyNotValid = "Input not in expected format - Read body failed, issue with datatype or fields or body";
            public const string InputInvalid = "Input not in expected format";
            public const string InputNotinExpectedformatSubscriptionIdisnotsupplied = "Input not in expected format -  SubscriptionId is not supplied";
            public const string InputNotinExpectedformatClientIDisnotsupplied = "Input not in expected format -  ClientID is not supplied";
            public const string InputNotinExpectedformatDocumenttypeisnotsupplied = "Input not in expected format -  Document type is not supplied";
            public const string InputNotinExpectedformatDatabaseisnotsupplied = "Input not in expected format -  Database is not supplied";
            public const string InputNotinExpectedformatContainerisnotsupplied = "Input not in expected format -  Container is not supplied";
            public const string InputNotinExpectedformatOperationTypeisnotsupplied = "Input not in expected format -  OperationType is not supplied IsEnable either true or false";
            public const string InputNotinExpectedformatSubscriptionNameisnotsupplied = "Input not in expected format -  SubscriptionName is not supplied";
            public const string SubscriptionConfigupdatedsuccessfully = "Subscription Config updated successfully";
           
        }
        public static class IndexSearchMessages
        {
          
            public const string Invalidsearchcombination = "Invalid search combination";
            public const string InvalidFipsRecordingdate = "Input not in expected format - Fips (or) RecordingDate (or) Filetype is not supplied";
            public const string InvalidsearchType = "SearchType not Supported - Expected APN_Address (or) Document (or) Owner  ";
            public const string InputBodyNotValid = "Input not in expected format - Read body failed, issue with datatype or fields or body";
            public const string FipsRecordingDateDocumentNumberFileTypeQuery = "Select * from c where c.Fips='{0}' and c.FNF_DocType='DOCUMENT' and c.FNF_CustomPartition= '{1}'  and c.DocumentNumber='{2}'  and c.FNF_FileType  in ('{3}') OFFSET 0 LIMIT 100";
            public const string FipsRecordingDateBookNumberPageNumberFileType = "Select * from c where c.Fips='{0}' and c.FNF_DocType='DOCUMENT' and c.FNF_CustomPartition= '{1}'  and c.BookNumber='{2}' and c.PageNumber='{3}' and c.FNF_FileType  in ('{4}') OFFSET 0 LIMIT 100";
            public const string OwnerSearchQuery = "SELECT * FROM c WHERE c.Fips= '{0}' AND c.FNF_DocType= '{1}' and c.FNF_FileType in('{2}') {3} OFFSET 0 LIMIT 100";
            public const string IndexSearchPropertyResponse = "IndexSearchPropertyResponse";
            public const string FipsInvalid = "Input not in expected format - Invalid Fips supplied";
            public const string InvalidFipsOwnerName = "Input not in expected format - Owner name (or) Fips is not supplied";
            public const string OwnerSearchQueryPrefix = "and ARRAY_CONTAINS(c.SplitedOwnerName, '";
            public const string OwnerSearchQuerySufix = "') ";
            public static readonly string InvalidMatchType;

            static IndexSearchMessages()
            {
                InvalidMatchType = "Match Type not Supported - Expected  " +
                string.Join("", Enum.GetNames(typeof(MatchType))) + "";
            }
         
        }
        public static class manageCosmosDB
        {
            public const string InputBodyinvalidInteger = "Input not in expected format -throughput should be integer ";
            public const string InputBodyinvalidAccountThroughtputInteger = "Input not in expected format -AccountTotalThroughputLimit should be integer ";
            public const string Enable = "true";
            public const string Disable = "false";
            public const string InvalidTimetoLive = "Input not in expected format - database (or) container (or)  TimeToLive (true / false) ";
            public const string Invaliddatabasecontainer = "Invalid database(or) container";
            public const string TimetoLive = "TimetoLive";


        }
        public static class CosmosDBValidationMessages
        {
            public const string IDisRequired = "Provide ID Value";
            public const string InvalidPartitionKey = "Provided Query Parameter combination is not supported, allowed Parameters are = '{0}' ";
            public const string InvalidDBorCONT = "Provided Database (or) Container is not supported";
            public const string InvalidDBorCONTorDOC = "Provided Database (or) Container (or) FNF_DocType is not supported";
            public const string InvalidDBorCONTorDOCorSearchType = "Provided Database (or) Container (or) FNF_DocType (or) Search_Type is not supported";
            public const string InvalidFnfDocType = "Provided FNF_DocType not valid";
            public const string FNFDocTypeRequired = "Provide FNF_DocType";
            public const string InvalidDBorCONTorDOCorPK = "Provided Database (or) Container (or) FNF_DocType (or) Partition Key is not supported";
            public const string InvalidNumberOfPartitionKey = "Invalid Number of Partition Keys Supplied, Minimum number of partitions = 1 and Minimum number of partitions = 3";
            public const string InvalidThroughputValue = "Minimum throughput should be 400";
            public const string InvalidContainerThroughputValue = "Minimum throughput for this container should be ";
            public const string MandatoryFiedsRequired_containercreation = "database, container, partitionkey, throughput are mandatory fields and must be provided";
            public const string MandatoryFiedsRequired_throughput = "database, container, throughput are mandatory fields and must be provided";
            public const string MandatoryFiedsRequired_indexing = "Indexing Policy is mandatory and IncludePath or ExcludePath fields must be provided";
            public const string MandatoryFiedsRequired_account = "Account throuput is mandatory and must be provided";
            public const string MandatoryFiedsRequired_OperationType = "OperationType is mandatory and must be provided, Valid Types are - CreateContainer/ChangeIndexingPolicy/SetContainerThroughputlimit/SetAccountThroughputlimit/ChangeTimeToLive";
            public const string CheckAccessstarted = "Check Access started -  Query:'{0}' . TransactionId:'{1}'  SubscriptionID:'{2}' ";

        }


        public static class ValidationAPISubscriptionMessages
        {
            public const string NotAllowedDocTypes = "Provided FNF_DocType(s) {0}  not allowed .Please enable valid subscription";

        }

        public static class QueryKeyword
        {
            public const string selectFrom = "SELECT * FROM c ";
            public const string where = " Where ";
            public const string singleQuote = "'";
            public const string and = " and ";
            public const string TableAliasC = " c";
            public const string Dot = ".";
            public const string Searchtype = "FNF_DocType = ";
            public const string PartitionKeyFips_Apn_DPID = "Fips_APN_DPID";
            public const string PartitionKeyFNF_DocType = "FNF_DocType";
            public const string equal = " = ";
            public const string In = " in ";
            public const string Limit100 = " OFFSET 0 LIMIT 100";
            public const string Space = " ";
            public const string Open = "{";
            public const string Close = "}";

        }


        public static class ResponseCodeDescription
        {
            public const string Success = "Success";
            public const string Failed = "Failed";
            public const string RecordNotFound = "No Results found";
            public const string MultipleRecordFound = "Multiple Records Found";
            public const string MalformedRequest = "Malformed Request";
            public const string ValidationError = "ValidationError";
            public const string InternalServerError = "InternalServerError";
            public const string SubscriptionKeyNotConfigured = "Subscription Key Not Configured";

        }
        public static class ResponseCode
        {
            public const string Success = "LSA_01";
            public const string Failed = "LSA_02";
            public const string NoResultFound = "LSA_03";
            public const string MultipleRecordFound = "LSA_04";
            public const string MalformedRequest = "LSA_05";
            public const string ValidationError = "LSA_06";
            public const string SubscriptionKeyNotConfigured = "LSA_07";
            public const string InternalServerError = "LSA_08";
        }
        public static class GeneralMessages
        {
            public const string InternalErrorOccurredPleasecontactSupport = "Internal Server Error,Please Contact Support";

        }

        public static Dictionary<int, string> ApnFipsSearchProperties = new Dictionary<int, string>()
        {
             {1, "FIPS"  },
             {2, "APN"  },
             {3, "Zip4" },
             {4,"UnitNumber" }
        };

        public static Dictionary<int, string> FipsFullStCityStateSearch_AND_FipsFullStZipSearchPropertiesProperties = new Dictionary<int, string>()
        {
             { 1,"FIPS"  },
             { 2, "FullStreetAddress"  },
             { 3, "City" },
             { 4, "State"  } ,
             { 5, "UnitNumber"  },
             { 6, "Zip4"  },
             {7, "Zip"  },
        };

        public static Dictionary<int, string> FipsRecordingDateDocumentNumberFileType = new Dictionary<int, string>()
        {
             { 1,"FIPS"  },
             { 2, "RecordingDate"  },
             { 3, "DocumentNumber" },

        };

        public static Dictionary<int, string> FipsRecordingDateBookNumberPageNumberFileType = new Dictionary<int, string>()
        {
             { 1,"FIPS"  },
             { 2, "RecordingDate"  },
             { 3, "BookNumber" },
             { 4, "PageNumber"  } 
        };
        public static Dictionary<int, string> OwnerSearchFileType = new Dictionary<int, string>()
        {
             { 1,"FIPS"  },
             { 2, "OwnerName"  }
        };

        //public static Dictionary<int, string> FipsFullStZipSearchProperties = new Dictionary<int, string>()
        //{
        //     {1, "FIPS"  },
        //     {2, "FullStreetAddress"  },
        //     {3, "APN"  },
        //     {4, "Zip"  },
        //     {5, "UnitNumber"  },
        //};

        public static class HttpRequestUrlParameters
        {
            public const string Database = "Database";
            public const string Container = "Container";
            public const string ContinuationToken = "continuationtoken";
            public const string SubscriptionKey = "SubscriptionKey";
            public const string ClientId = "ClientId";
            public const string MandatoryField = "id";
            public const string Parameter = "\"parameters\"";
            public const string Query = "\"query\"";
            public const string JsonParameter = "parameters";
            public const string JsonQuery = "query";
            public const string Where = " where ";

        };

        public static class AdditionalKeywords
        {
            public const string FNF_DocType = "FNF_DocType";
            public const string SearchKeywordcontainer = "_search";
            public const string SubscriptionName = "SubscriptionName";
        };
        public static class OpertaionType
        {
            public const string CreateContainer = "CreateContainer";
            public const string ChangeIndexingPolicy = "ChangeIndexingPolicy";
            public const string SetContainerThroughputlimit = "SetContainerThroughputlimit";
            public const string SetAccountThroughputlimit = "SetAccountThroughputlimit";
        }

        public static Dictionary<int, string> OperationType = new Dictionary<int, string>()
        {
             {1, OpertaionType.CreateContainer  },
             {2, OpertaionType.ChangeIndexingPolicy  },
             {3, OpertaionType.SetContainerThroughputlimit },
             {4,OpertaionType.SetAccountThroughputlimit }
        };

        public static class CosmosDBObjectAPIOperationType
        {
            public const string CreateContainer = "CreateContainer";
            public const string SetContainerThroughputlimit = "SetContainerThroughputlimit";
            public const string ChangeIndexingPolicy = "ChangeIndexingPolicy";
            public const string SetAccountThroughputlimit = "SetAccountThroughputlimit";
            public const string ChangeTimeToLive = "ChangeTimeToLive";
        }

        public static class  QueryAPIComplexQueryRestriction 
        {
            public const string RestrictedKeywordsRegPattern =  @"\b(JOIN|GROUP BY|ORDER BY|ORDER BY RANK|DISTINCT)\b";
            public const string SubQueryRegPattern = @"\bSELECT\b";
        };

        public static class ResponseOutputType
        {
            public const string PointedLookup_Response = "PointedLookupResponse"; 
            public const string PointeLookup_FunctionResponse = "FunctionResponse";
            public const string IndexSearch_IndexSearchPropertyResponse = "IndexSearchPropertyResponse";
            public const string IndexSearch_IndexSearchPropertySearchResponse = "IndexSearchPropertySearchResponse";
            
        }
        public static class SearchType
        {
            public const string AddressSearch = "APN_Address";
            public const string Document = "Document";
            public const string Owner = "Owner";
        }
        public static class DocType
        {
          public const string   APN_ADDRESS_OWNER = "APN_ADDRESS_OWNER";
          public const string Document = "DOCUMENT";
        }
       
        public enum MatchType
        {
            Exact
        }

        public enum FnfDocType
        {
            ASMT,
            Invalid
        }
        public enum FilterField
        {
            SplitedOwnerName,
            FNF_CustomPartition
        }
    }
} 

﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenerationLogic;
using SpokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.JavaScript;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Utils
{
    public static class CommonMethod
    {

        public static dynamic IndexSearchException(ILogger<SpokeAPI.Functions.IndexSearch> _logger, Exception ex, string SubscriptionKey, string TransactionID, string ResponseStatusDescription, string responseStatusCode,string responseMessage)
        {
            _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + Enums.QueryKeyword.Space + CommonModels.GlobalTransactionID.TransactionID);
            return FailedResponse(ResponseStatusDescription, responseStatusCode, responseMessage);
        }
        public static dynamic ManageSubscriptionException(ILogger<SpokeAPI.Functions.ManageSubscription> _logger, Exception ex, string SubscriptionKey, string TransactionID, string ResponseStatusDescription, string responseStatusCode, string? responseMessage)
        {
            _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + Enums.QueryKeyword.Space + CommonModels.GlobalTransactionID.TransactionID);
            return FailedResponse(ResponseStatusDescription, responseStatusCode, responseMessage ?? "");     
        }
        public static dynamic PointedLookupException(ILogger<SpokeAPI.Functions.PointLookup> _logger, Exception ex, string SubscriptionKey, string TransactionID, string ResponseStatusDescription, string responseStatusCode)
        {
            _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + Enums.QueryKeyword.Space + CommonModels.GlobalTransactionID.TransactionID);
            return FailedResponse(ResponseStatusDescription, responseStatusCode, GeneralMessages.InternalErrorOccurredPleasecontactSupport);
        }
        public static dynamic ManageCosmosDBObjectException(ILogger<SpokeAPI.Functions.ManageCosmosDBObject> _logger, Exception ex, string SubscriptionKey, string TransactionID, string ResponseStatusDescription, string responseStatusCode)
        {
            _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + Enums.QueryKeyword.Space + CommonModels.GlobalTransactionID.TransactionID);
            return FailedResponse(ResponseStatusDescription, responseStatusCode, GeneralMessages.InternalErrorOccurredPleasecontactSupport);
        }
        public static dynamic QueryAPIException(ILogger<SpokeAPI.Functions.QueryAPI> _logger, Exception ex, string SubscriptionKey, string TransactionID, string ResponseStatusDescription, string responseStatusCode)
        {
            _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + Enums.QueryKeyword.Space + CommonModels.GlobalTransactionID.TransactionID);
            return FailedResponse(ResponseStatusDescription, responseStatusCode, GeneralMessages.InternalErrorOccurredPleasecontactSupport);
        }
        public static dynamic QueryAPIException(ILogger<SpokeAPI.Functions.QueryAPI> _logger, Exception ex, string DatabasefailureMessage, string SubscriptionKey, string TransactionID, string ResponseStatusDescription, string responseStatusCode)
        {
            _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + Enums.QueryKeyword.Space + CommonModels.GlobalTransactionID.TransactionID);
            return FailedResponse(ResponseStatusDescription, responseStatusCode, DatabasefailureMessage);
        }


        public static dynamic FailedResponse(string ResponseStatusDescription, string responseStatusCode, string responseMessage)
        {
            FailedResponse failedResponse = new();
            failedResponse.responseCodeDescription = ResponseStatusDescription;
            failedResponse.responseCode = responseStatusCode;
            failedResponse.message = responseMessage;
            return failedResponse;
        }

        public static dynamic ValidationErrorReponse(string ResponseStatusDescription, string responseStatusCode, string responseMessage)
        {
            ValidationResponse? validationResponse = new();
            validationResponse.ResponseCode = ResponseStatusDescription;
            validationResponse.ResponseCodeDescription = responseStatusCode;
            validationResponse.Message = responseMessage;
            return validationResponse;
        }

        public static string? parseOwnername(string ownerName)
        {
            ownerName = CleanOwnerName(ownerName);
            List<string> splittedOwnerNameRefined = ownerName.Split(' ').ToList();

            splittedOwnerNameRefined.RemoveAll(str => string.IsNullOrWhiteSpace(str));

            if (splittedOwnerNameRefined.Count() ==0 )
            {
                return string.Empty;
            }
            var modifiedList = splittedOwnerNameRefined.Select(name => Enums.IndexSearchMessages.OwnerSearchQueryPrefix + name + Enums.IndexSearchMessages.OwnerSearchQuerySufix).ToList();
            // Join the modified list into a single string
            string result = string.Join("", modifiedList);
            return result;
        }


        public static string CleanOwnerName(string OwnerName)
        {
            string RegexPass1 = @"(\W|_)|\b\w\b";
            string RegexPass2 = @"\s+";

            RegexOptions regexOptions = RegexOptions.IgnoreCase;

            OwnerName = Regex.Replace(OwnerName, RegexPass1, " ", regexOptions).Trim();
            OwnerName = Regex.Replace(OwnerName, RegexPass2, " ", regexOptions).Trim();

            return OwnerName.ToUpper();
        }

 
    }
}

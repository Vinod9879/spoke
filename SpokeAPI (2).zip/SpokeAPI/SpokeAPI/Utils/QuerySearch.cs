﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Utils.Enums;


namespace SpokeAPI.Utils
{
    public static class QuerySearch
    {
        public static async Task<QuerySearchResult> ReadItemAsync(string query, IndexSearchRequest indexSearchRequest,IConnection _connection, Microsoft.Extensions.Logging.ILogger<Functions.IndexSearch> _logger)
        {
            CosmosClient client = _connection.GetReadCosmosClient();
            Container SearchContainer;
            List<dynamic> items = new List<dynamic>();
            QuerySearchResult querySearchResult = new();
            bool isProperyContainerSearch = true;
            int intSearch = 0;

            //Get Current version of database and container from config
          indexSearchRequest.Database = DBVersionTranslator.GetCurrentDBVersion(indexSearchRequest.Database, _connection);

            //Order of assignment should be maintained in the same way to get _search appedend to the end of container name
           string searchContainer = DBVersionTranslator.GetCurrentContainerVersion(string.Concat(indexSearchRequest.Container, Enums.AdditionalKeywords.SearchKeywordcontainer),_connection);
           indexSearchRequest.Container = DBVersionTranslator.GetCurrentContainerVersion(indexSearchRequest.Container,_connection);


            if (indexSearchRequest.searchInfo?.APN == null || indexSearchRequest.searchInfo?.APN == "")
            {
                isProperyContainerSearch = false;
            }
            if (isProperyContainerSearch)
            {
              
                List<string>? listFNF_DocType = indexSearchRequest.FNF_DocType?.ToList();
                JObject responsejson = new JObject();
                SearchContainer = client.GetContainer(indexSearchRequest.Database, indexSearchRequest.Container);
                _logger.LogInformation(EnumsLog.IndexSearch.Intiatedthe_Query_in_Propery_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                QueryDefinition queryDefinition = new QueryDefinition(query);
                FeedIterator<dynamic> queryResultSetIterator = SearchContainer.GetItemQueryIterator<dynamic>(queryDefinition);
                var TotalTimeProperyContainerSearch = 0;
                double ProperyRequestCharge = 0.00;
                try
                {
                    while (queryResultSetIterator.HasMoreResults)
                    {
                        FeedResponse<dynamic> currentResultSet = await queryResultSetIterator.ReadNextAsync();
#pragma warning disable
                        foreach (var item in currentResultSet)
                        {

                            JToken jToken = item[Enums.AdditionalKeywords.FNF_DocType];
                            string? strfNF_DocType = ((JValue)jToken).Value.ToString();
                            if ((bool)(listFNF_DocType?.Contains(strfNF_DocType, StringComparer.OrdinalIgnoreCase)))
                            {
                                intSearch++;
                                JArray nameTokenArray = (JArray)responsejson[strfNF_DocType];
                                if (nameTokenArray == null)
                                {
                                    JArray jArray = new JArray();
                                    responsejson.Add(strfNF_DocType?.ToUpper(), jArray);
                                    nameTokenArray = (JArray)responsejson[strfNF_DocType];
                                }
                                // Append the new object to the JArray
                                nameTokenArray?.Add(item);
                            }
                        }
#pragma warning restore
                        ProperyRequestCharge = ProperyRequestCharge + currentResultSet.RequestCharge;
                        TotalTimeProperyContainerSearch = TotalTimeProperyContainerSearch + currentResultSet.Diagnostics.GetClientElapsedTime().Milliseconds;
                    }
                }
                catch (Exception ex) {
                    _logger.LogInformation(EnumsLog.IndexSearch.InternalSeverError, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID,ex.Message);
                    return querySearchResult;
                }

                querySearchResult.TotalTimeProperyContainerSearch = TotalTimeProperyContainerSearch;
                querySearchResult.TotalTimeProperyContainerRequestCharge = ProperyRequestCharge;
                querySearchResult.CountResult = intSearch;
                querySearchResult.JObjectResult = responsejson;
                _logger.LogInformation(EnumsLog.IndexSearch.Endthe_Query_in_Propery_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                return querySearchResult;
            }
            else
            {
                var TotalTimeProperySearchContainerSearch = 0;
                var ProperySearchRequestCharge = 0.00;
                SearchContainer = client.GetContainer(indexSearchRequest.Database, searchContainer);
                QueryDefinition queryDefinition = new QueryDefinition(query);
                FeedIterator<dynamic> queryResultSetIterator = SearchContainer.GetItemQueryIterator<dynamic>(queryDefinition);
                _logger.LogInformation(EnumsLog.IndexSearch.Intiated_in_Property_Search_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                while (queryResultSetIterator.HasMoreResults)
                {
                    FeedResponse<dynamic> currentResultSet = await queryResultSetIterator.ReadNextAsync();
                    foreach (var item in currentResultSet)
                    {
                        intSearch++;
                        items.Add(item);
                    }
                    ProperySearchRequestCharge = ProperySearchRequestCharge + currentResultSet.RequestCharge;
                    TotalTimeProperySearchContainerSearch = TotalTimeProperySearchContainerSearch + currentResultSet.Diagnostics.GetClientElapsedTime().Milliseconds;

                }
                _logger.LogInformation(EnumsLog.IndexSearch.Ended_in_Property_Search_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                querySearchResult.TotalPropertySearchContainerRequestCharge = ProperySearchRequestCharge;
                querySearchResult.TotalTimePropertySearchContainerSearch = TotalTimeProperySearchContainerSearch;

            }

            querySearchResult.CountResult = intSearch;
            querySearchResult.CountResult = intSearch;
            querySearchResult.dynamicListResult = items;
            return querySearchResult;
        }
    }
}

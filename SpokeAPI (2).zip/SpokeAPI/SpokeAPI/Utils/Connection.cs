﻿using Azure.Core;
using Azure.Identity;
using Azure.ResourceManager;
using Azure.ResourceManager.CosmosDB;
using Google.Protobuf.WellKnownTypes;
using Microsoft.Azure.Cosmos;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using System.Data.Common;
using System.Resources;
using System.Text.Json;
using System.Threading.Tasks;

namespace SpokeAPI.Utils
{



    public class Connections : IConnection
    {
#pragma warning disable
        private readonly CosmosClient ReadClient;
        private readonly CosmosClient ReadWriteClient;
        private readonly List<ConfigPartitionKeys>? ConfigPartitionKeys;
        private readonly List<CosmosDBConfig>? CosmosDBConfig;

        private  ArmClient? _armClient;
        private ResourceIdentifier? _resourceIdentifier;
        private CosmosDBAccountResource _cosmosDBAccountResource;
        private CosmosDBSqlDatabaseCollection _cosmosDBSqlDatabaseCollection;
        public string MaxItemCount { get; set; } = Environment.GetEnvironmentVariable("ResponseMaxItemCount", EnvironmentVariableTarget.Process)??"";
        public string CosmosEndpoint { get ; set ; } = Environment.GetEnvironmentVariable("CosmosEndpoint", EnvironmentVariableTarget.Process) ?? "";
        public string SubscriptionDatabase { get ; set ; } = Environment.GetEnvironmentVariable("SubscriptionDatabase", EnvironmentVariableTarget.Process) ?? "";
        public string SubscriptionContainer { get; set; } = Environment.GetEnvironmentVariable("SubscriptionContainer", EnvironmentVariableTarget.Process) ?? "";
        public string subscriptionId { get; set; } = Environment.GetEnvironmentVariable("subscriptionId", EnvironmentVariableTarget.Process) ?? "";
        public string resourceGroupName { get; set; } = Environment.GetEnvironmentVariable("resourceGroupName", EnvironmentVariableTarget.Process) ?? "";
        public string ReadWriteClientID { get; set; } = Environment.GetEnvironmentVariable("ReadWriteClientID", EnvironmentVariableTarget.Process) ?? "";
        public string ReadClientID { get; set; } = Environment.GetEnvironmentVariable("ReadClientID", EnvironmentVariableTarget.Process) ?? "";
        public string DatabaseVersionConfig { get; set; } = Environment.GetEnvironmentVariable("DatabaseVersionConfig", EnvironmentVariableTarget.Process) ?? "";

        public Connections()
        {
            string? cosmosdb_config = Environment.GetEnvironmentVariable("cosmosdb_config", EnvironmentVariableTarget.Process);
            string? configPartitionKeys = Environment.GetEnvironmentVariable("cosmosdb_config", EnvironmentVariableTarget.Process);
            string? DatabaseVersionConfig = Environment.GetEnvironmentVariable("DatabaseVersionConfig", EnvironmentVariableTarget.Process);
            var readCredential = new DefaultAzureCredential(new DefaultAzureCredentialOptions

            {
                ManagedIdentityClientId = ReadClientID
            });
            ReadClient = new CosmosClient(CosmosEndpoint, readCredential);
            var readWriteCredential = new DefaultAzureCredential(new DefaultAzureCredentialOptions
            {
                ManagedIdentityClientId = ReadWriteClientID
            });
            ReadWriteClient = new CosmosClient(CosmosEndpoint, readWriteCredential);
            ConfigPartitionKeys = JsonSerializer.Deserialize<List<ConfigPartitionKeys>>(configPartitionKeys);
            CosmosDBConfig = JsonSerializer.Deserialize<List<CosmosDBConfig>>(cosmosdb_config.ToLower());
           // Processing partition key names in CosmosDB and their aliases (PartitionKey with hypen)
            ProcessingPartitionsnKeyHypen(CosmosDBConfig, ConfigPartitionKeys);
        }
        public CosmosClient GetReadCosmosClient() => ReadClient;
        public CosmosClient GetReadWriteCosmosClient() => ReadWriteClient;

        public List<ConfigPartitionKeys>? GetConfigPartitionKeys() => ConfigPartitionKeys;
        public List<CosmosDBConfig>? Getcosmosdb_config() => CosmosDBConfig;

        public ArmClient? GetArmClient()
        {
             _armClient = new  ArmClient(new DefaultAzureCredential(new DefaultAzureCredentialOptions { ManagedIdentityClientId = ReadWriteClientID }), subscriptionId);
            return _armClient;
        }

        public ResourceIdentifier GetResourceIdentifier()
        {
            _resourceIdentifier = CosmosDBAccountResource.CreateResourceIdentifier(subscriptionId, resourceGroupName, CosmosEndpoint.Split('.')[0].Replace("https://", string.Empty));
            return _resourceIdentifier;
        }

        public CosmosDBAccountResource GetCosmosDBAccountResource(ArmClient armclient,ResourceIdentifier resourceIdentifier)
        {
            _cosmosDBAccountResource = armclient.GetCosmosDBAccountResource(resourceIdentifier);
            return _cosmosDBAccountResource;
        }

        
        public async Task<(bool, CosmosDBSqlDatabaseCollection)> GetCheckIfdatabaseExistsAsync(CosmosDBAccountResource cosmosAccount, string databaseName)
        {
            _cosmosDBSqlDatabaseCollection = cosmosAccount.GetCosmosDBSqlDatabases();
            bool isexists = await _cosmosDBSqlDatabaseCollection.ExistsAsync(databaseName);
            return (isexists, _cosmosDBSqlDatabaseCollection);
        }

        public static  void ProcessingPartitionsnKeyHypen(List<CosmosDBConfig> CosmosDBConfigs, List<ConfigPartitionKeys> ConfigPartitionKeys)
        {

            // Iterating through each CosmosDBConfig to process partition key names and their aliases
            foreach (CosmosDBConfig CosmosDBConfig in CosmosDBConfigs)
            {
                int i = 0;
                Dictionary<int, string> actualCosmosPartitionKeyName = new Dictionary<int, string>();
                foreach (string query_params in CosmosDBConfig.query_params)
                {
                    string[] parts = query_params.Split('|');
                    // Adding partition key name and its alias in case any partitionkey alias name exists
                    if (parts.Length == 2)
                    {
                        actualCosmosPartitionKeyName.Add(i, parts[0].ToString());
                    }
                    i++;
                }
                // Updating the query_params with actual partition key names 
                foreach (var keyValuePairs in actualCosmosPartitionKeyName)
                {
                    CosmosDBConfig.query_params[keyValuePairs.Key] = keyValuePairs.Value.ToString();

                }
                // Iterating through ConfigPartitionKeys to update partition key names and their aliases. since 2 different deserialized objects are created
                foreach (var item in ConfigPartitionKeys)
                {
                    int x = 0;
                    Dictionary<int, string> actualCosmosPartitionKeyNameQueryAPI = new Dictionary<int, string>();
                    // Initializing the dictionary to store partition key name and its alias
                    foreach (string query_params in item.query_params)
                    {
                        if (item.query_params != null)
                        {

                            string[] parts = query_params.Split('|');
                            if (parts.Length == 2)
                            {
                                item.partitionsKeyHypenAlias.Add(parts[0], parts[1]);

                                // Adding partition key name and its alias in case any partitionkey alias name exists
                                actualCosmosPartitionKeyNameQueryAPI.Add(x, parts[0].ToString());
                            }
                            x++;
                        }
                    }
                    // Updating the query_params with actual partition key names
                    foreach (var keyValuePairs in actualCosmosPartitionKeyNameQueryAPI)
                    {
                        item.query_params[keyValuePairs.Key] = keyValuePairs.Value.ToString();

                    }
                }

            }
        }
        
    }
}

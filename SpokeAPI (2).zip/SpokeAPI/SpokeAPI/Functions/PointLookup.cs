


using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Functions
{
    public class PointLookup
    {
        private readonly ILogger<PointLookup> _logger;
        private readonly IPointedLookup _pointedLookup;
        private readonly IConnection _connection;


        public PointLookup(ILogger<PointLookup> logger, IPointedLookup pointedLookup , IConnection connection)
        {
            _logger = logger;
            _pointedLookup = pointedLookup;
            _connection = connection;
        }

        [Function("PointLookup")]
        public async Task<IActionResult> RunAsync([HttpTrigger(AuthorizationLevel.Function, "get", Route = "PointLookup/{Database}/{Container}")] HttpRequest req)
        {
            CommonModels.GlobalTransactionID.TransactionID = "";
            CommonModels.GlobalTransactionID.TransactionID = Guid.NewGuid().ToString();
            try
            {
          
                req.HttpContext.Response.Headers.Append("TransactionId", CommonModels.GlobalTransactionID.TransactionID);
                _logger.LogInformation(EnumsLog.PointedLookup.TriggeredPointedLookupfunction, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                dynamic pointedLookup = await _pointedLookup.LookupAsync(req, _logger, _connection);
                _logger.LogInformation(EnumsLog.PointedLookup.CompletedPointedLookupfunction, pointedLookup.GetType().FullName.Contains(Enums.ResponseOutputType.PointedLookup_Response) ? (((PointedLookupResponse)pointedLookup).responseCodeDescription) : pointedLookup.GetType().FullName.Contains("Response") ? (((SpokeAPI.Models.CommonModels.FunctionResponse.Response)pointedLookup).ResponseCodeDescription) : "N/A", req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                CommonModels.GlobalTransactionID.TransactionID = "";
                if(pointedLookup.GetType().FullName.Contains(Enums.ResponseOutputType.PointedLookup_Response))
                return new OkObjectResult(pointedLookup);
                else if (pointedLookup.GetType().FullName.Contains(Enums.ResponseOutputType.PointeLookup_FunctionResponse))
                    return new OkObjectResult(pointedLookup) { StatusCode = 400 };
                else return new OkObjectResult(pointedLookup) { StatusCode =500 };
            }
            catch (Exception ex)
            {
                return new ObjectResult(CommonMethod.PointedLookupException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID,Enums.ResponseCodeDescription.InternalServerError,Enums.ResponseCode.InternalServerError))
                {
                    StatusCode = 500
                };

            }
        }
    }
}

#nullable disable

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using SpokeAPI.Utils;
using SpokeAPI.Models;
using SpokeAPI.Interface.Functions;
using static SpokeAPI.Utils.Enums;
using SpokeAPI.Interface.Connection;

namespace SpokeAPI.Functions
{
    public class ManageCosmosDBObject
    {
        private readonly ILogger<ManageCosmosDBObject> _logger;
        private readonly IManageCosmosDBObject _manageCosmosDBObject;
        private readonly IConnection _connection;

        public ManageCosmosDBObject(IManageCosmosDBObject manageCosmosDBObject, ILogger<ManageCosmosDBObject> logger, IConnection connection)
        {
            _manageCosmosDBObject = manageCosmosDBObject;
            _logger = logger;
            _connection = connection;
        }

        [Function("ManageCosmosDBObject")]
        public async Task<IActionResult> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req, ExecutionContext execution)
        {
            CommonModels.GlobalTransactionID.TransactionID = "";
            CommonModels.GlobalTransactionID.TransactionID = Guid.NewGuid().ToString();
            try
            {
                req.HttpContext.Response.Headers.Append("TransactionId", CommonModels.GlobalTransactionID.TransactionID);
                _logger.LogInformation(EnumsLog.ManageCosmosDB.TriggeredManageCosmosDBfunction, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                dynamic manageCosmosResponse = await _manageCosmosDBObject.ManageCosmosDB(req, _connection, _logger);
                _logger.LogInformation(EnumsLog.ManageCosmosDB.CompletedManageCosmosDBfunction, ((SpokeAPI.Models.CommonModels.FunctionResponse.Response)((Microsoft.AspNetCore.Mvc.ObjectResult)manageCosmosResponse).Value).ResponseCodeDescription, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                CommonModels.GlobalTransactionID.TransactionID = "";
                return manageCosmosResponse;
            }
            catch (Exception ex)
            {
                return new ObjectResult(CommonMethod.ManageCosmosDBObjectException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID,ResponseCodeDescription.InternalServerError ,ResponseCode.InternalServerError))
                {
                    StatusCode = 500
                };
            }
        }
    }
}

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System.Transactions;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;
using static SpokeAPI.Utils.EnumsLog;


namespace SpokeAPI.Functions
{
    public class IndexSearch
    {
        private readonly ILogger<IndexSearch> _logger;
        private readonly IIndexSearch _indexSearch;
        private readonly IConnection _connection;
     
        public IndexSearch(ILogger<IndexSearch> logger, IIndexSearch indexSearch, IConnection connection)
        {
            _logger = logger;
            _indexSearch = indexSearch;
            _connection = connection;
         }

        [Function("IndexSearch")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = "IndexSearch/{Database}/{Container}")] HttpRequest req)
        {
            CommonModels.GlobalTransactionID.TransactionID = "";
            CommonModels.GlobalTransactionID.TransactionID = Guid.NewGuid().ToString();
            try
            {
                 req.HttpContext.Response.Headers.Append("TransactionId", CommonModels.GlobalTransactionID.TransactionID);
                _logger.LogInformation(EnumsLog.IndexSearch.TriggeredIndexSearchfunction, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                //Entry Point Index Search. IndexSearchAsyc is common interface  method for all type Search
                dynamic? indexSearchResponse = await _indexSearch.IndexSearchAsyc(req, _connection, _logger );

                if (indexSearchResponse?.GetType().FullName.Contains("IndexSearchValidationResponse")) { return new OkObjectResult(indexSearchResponse) { StatusCode = 400 }; }
                else if (indexSearchResponse?.GetType().FullName.Contains("FailedResponse"))
                {
                    return new OkObjectResult(indexSearchResponse) { StatusCode = 500 };
                }
                else
                {
                    _logger.LogInformation(EnumsLog.IndexSearch.CompletedIndexSearchfunction,
                   indexSearchResponse?.GetType().FullName.Contains(Enums.ResponseOutputType.IndexSearch_IndexSearchPropertyResponse) ?
                    (((IndexSearchPropertyResponse?)indexSearchResponse)?.responseCodeDescription) :
                    indexSearchResponse?.GetType().FullName.Contains(Enums.ResponseOutputType.IndexSearch_IndexSearchPropertySearchResponse) ?
                     (((IndexSearchPropertySearchResponse?)indexSearchResponse)?.responseCodeDescription) :
                     "N/A",
                   req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(indexSearchResponse);
                }
            }
            catch (Exception ex)
            {
                return new ObjectResult(CommonMethod.IndexSearchException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID, ResponseCodeDescription.InternalServerError, ResponseCode.InternalServerError,  GeneralMessages.InternalErrorOccurredPleasecontactSupport))
                {
                    StatusCode = 500
                };
            }
        }
    }
}

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Functions
{
    public class ManageSubscription
    {
        private readonly ILogger<ManageSubscription> _logger;
        private readonly IManageSubscriptions _manageSubscriptions;
        private readonly IConnection _connection;

        public ManageSubscription(ILogger<ManageSubscription> logger,IManageSubscriptions manageSubscriptions,IConnection connection)
        {
            _logger = logger;
            _manageSubscriptions = manageSubscriptions;
            _connection = connection;
        }

        [Function("ManageSubscription")]
        public  async Task<IActionResult> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req,InvocationResult invocationResult)
        {
           
            try
            {
#pragma warning disable
                CommonModels.GlobalTransactionID.TransactionID = Guid.NewGuid().ToString();
                req.HttpContext.Response.Headers.Append("TransactionId", CommonModels.GlobalTransactionID.TransactionID);
                _logger.LogInformation(EnumsLog.ManageSubscription.TriggeredManageSubscriptionfunction, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                var Response = await _manageSubscriptions.UpsertSubscription(req, _connection, _logger);
                if(((Microsoft.AspNetCore.Mvc.ObjectResult)Response).Value.GetType().FullName.Contains("Failed"))
                    _logger.LogInformation(EnumsLog.ManageSubscription.CompletedManageSubscriptionfunction,  ((SpokeAPI.Models.CommonModels.FailedResponse)((Microsoft.AspNetCore.Mvc.ObjectResult)Response).Value).responseCodeDescription ?? "", req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                else
                    _logger.LogInformation(EnumsLog.ManageSubscription.CompletedManageSubscriptionfunction, ((SpokeAPI.Models.CommonModels.FunctionResponse.Response)((Microsoft.AspNetCore.Mvc.ObjectResult)Response).Value).ResponseCodeDescription ?? ((SpokeAPI.Models.CommonModels.FailedResponse)((Microsoft.AspNetCore.Mvc.ObjectResult)Response).Value).responseCodeDescription ?? ((SpokeAPI.Models.CommonModels.FailedResponse)((Microsoft.AspNetCore.Mvc.ObjectResult)Response).Value).responseCodeDescription, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                    return Response;
#pragma warning restore
            }
            catch (Exception ex)
            {
                return new ObjectResult(CommonMethod.ManageSubscriptionException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID ?? "", Enums.ResponseCodeDescription.InternalServerError, Enums.ResponseCode.InternalServerError,GeneralMessages.InternalErrorOccurredPleasecontactSupport))
                {
                    StatusCode = 500
                };
            }
        }

    }
}

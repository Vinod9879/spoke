using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Models.QueryAPIModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Functions
{
    public class QueryAPI
    {
        private readonly ILogger<QueryAPI> _logger;
        private readonly IQueryAPI _queryAPI;
        private readonly IConnection _connection;
        public QueryAPI(ILogger<QueryAPI> logger , IQueryAPI QueryAPI ,IConnection connection)
        {
            _logger = logger;
            _queryAPI = QueryAPI;
            _connection = connection;
        }

        [Function("QuerySearch")]
        public async Task<IActionResult> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post" ,Route = "QuerySearch/{Database}/{Container}")] HttpRequest req)
        {
            try
            {
                CommonModels.GlobalTransactionID.TransactionID = "";
                CommonModels.GlobalTransactionID.TransactionID = Guid.NewGuid().ToString();
                _logger.LogInformation(EnumsLog.QueryAPI.TriggeredQueryAPIfunction, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                var queryesult = await _queryAPI.GetQueryResult(req, _logger, _connection);
                 #pragma warning disable
                _logger.LogInformation(EnumsLog.QueryAPI.CompletedQueryAPIfunction, queryesult.GetType().Name.Contains("OkObjectResult") ? Enums.ResponseCodeDescription.Success : ((ObjectResult)queryesult).Value.GetType().Name.Contains("ValidationResponse") ? ((CommonModels.ValidationResponse)((ObjectResult)queryesult).Value).ResponseCodeDescription : ((ObjectResult)queryesult).Value.GetType().Name.Contains("FailedResponse") ? ((CommonModels.FailedResponse)((ObjectResult)queryesult).Value).responseCode : "N?A", req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                #pragma warning restore
                CommonModels.GlobalTransactionID.TransactionID = "";
                return queryesult;
            }
            catch (Exception ex)
            {

                return new ObjectResult(CommonMethod.QueryAPIException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID??"", Enums.ResponseCodeDescription.InternalServerError, Enums.ResponseCode.InternalServerError))
                {
                    StatusCode = 500
                };
            }
        }
    }
}

﻿using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Models.PointedLookupModel;


namespace SpokeAPI.Validations
{
    public static class ValidationCosmosDBConfig
    {
#pragma warning disable

        private static List<CosmosDBConfig>? _cosmosDBConfig = new List<CosmosDBConfig>();

        //public static CosmosDBConfigValidation ValidateCosmosDBObject(string database, string container)
        //{
        //    CosmosDBConfigValidation cosmosDBConfigValidation = new CosmosDBConfigValidation();
        //    IEnumerable<CosmosDBConfig> item = _cosmosDBConfig.Where(a => string.Equals(a.database, database) && string.Equals(a.container, container));
        //    if (item.Count() == 0) { cosmosDBConfigValidation.Success = false; cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.InvalidDBorCONT; }
        //    return cosmosDBConfigValidation;
        //}
        public static CosmosDBConfigValidation ValidateCosmosDBObject(string database, string container, string fnf_doctype ,IConnection _connection)
        {
            CosmosDBConfigValidation cosmosDBConfigValidation = new CosmosDBConfigValidation();
            _cosmosDBConfig = _connection.Getcosmosdb_config();
            IEnumerable<CosmosDBConfig> item = _cosmosDBConfig?.Where(a => string.Equals(a.database, database) && string.Equals(a.container, container) && a.fnf_doctype.Any(x => x.Contains(fnf_doctype.ToLower())));
            if (item.Count() == 0) { cosmosDBConfigValidation.Success = false; cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.InvalidDBorCONTorDOC; }
            return cosmosDBConfigValidation;
        }

        //public static CosmosDBConfigValidation ValidateCosmosDBObject(string database, string container, string fnf_doctype, string search_type)
        //{
        //    CosmosDBConfigValidation cosmosDBConfigValidation = new CosmosDBConfigValidation();
        //    IEnumerable<CosmosDBConfig> item = _cosmosDBConfig.Where(a => string.Equals(a.database, database) && string.Equals(a.container, container) && a.fnf_doctype.Any(x => x.Contains(fnf_doctype.ToLower())) && a.search_type.Any(x => x.Contains(search_type.ToLower())));
        //    if (item.Count() == 0) { cosmosDBConfigValidation.Success = false; cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.InvalidDBorCONTorDOCorSearchType; }
        //    return cosmosDBConfigValidation;
        //}

        public static CosmosDBConfigValidation ValidateCosmosDBObject(string? database, string? container, string? search_type, List<string>? FNF_DocType,IConnection _connection)
        {
            CosmosDBConfigValidation cosmosDBConfigValidation = new CosmosDBConfigValidation();
            _cosmosDBConfig = _connection.Getcosmosdb_config();
            List<CosmosDBConfig> item = _cosmosDBConfig.Where(a => a.database == database?.ToLower() && a.container == container.ToLower() && a.search_type.Any(x => x.Contains(search_type.ToLower()))).ToList();

            if (FNF_DocType is null)
            {
                cosmosDBConfigValidation.Success = false; cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.FNFDocTypeRequired;
                return cosmosDBConfigValidation;
            }
            else
            {
                foreach (var v in FNF_DocType)
                {
                    if (!item[0].fnf_doctype.Contains(v.ToString(), StringComparer.OrdinalIgnoreCase))
                    {
                        cosmosDBConfigValidation.Success = false; cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.InvalidFnfDocType;
                        return cosmosDBConfigValidation;
                    }
                }
            }
       
            return cosmosDBConfigValidation;
        }

        public static CosmosDBConfigValidation ValidateCosmosDBObject(PointedLookupRequest? pointedLookupRequest, IConnection connection)
        {
            CosmosDBConfigValidation cosmosDBConfigValidation = new CosmosDBConfigValidation();
            IEnumerable<CosmosDBConfig> item = new List<CosmosDBConfig>();
            _cosmosDBConfig = connection.Getcosmosdb_config();
            List<string> QueryParam = _cosmosDBConfig.Where(a => string.Equals(a.database, pointedLookupRequest.Database, StringComparison.OrdinalIgnoreCase) && string.Equals(a.container, pointedLookupRequest.Container, StringComparison.OrdinalIgnoreCase)).Select(x => x.query_params).FirstOrDefault();
            if (QueryParam == null)
            {
                cosmosDBConfigValidation.Success = false;
                cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.InvalidDBorCONT;
                return cosmosDBConfigValidation;

            }
            if (pointedLookupRequest?.ReqParameter?.Where(x => String.Equals(x.Key, Enums.HttpRequestUrlParameters.MandatoryField, StringComparison.OrdinalIgnoreCase)).Count() <= 0)

            {
                cosmosDBConfigValidation.Success = false;
                cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.IDisRequired;
                return cosmosDBConfigValidation;
            }

            foreach (var v in QueryParam)
            {
                if (pointedLookupRequest?.ReqParameter?.Where(x => String.Equals(x.Key, v, StringComparison.OrdinalIgnoreCase)).Count() != 1)
                {
                    cosmosDBConfigValidation.Success = false;
                    cosmosDBConfigValidation.Message = string.Format(Enums.CosmosDBValidationMessages.InvalidPartitionKey, string.Join(',', QueryParam));
                    return cosmosDBConfigValidation;

                }
            }

            int partitionKeycount = QueryParam.Count() - 1;
            if (pointedLookupRequest?.NumberofPartitionKey != partitionKeycount)
            {
                cosmosDBConfigValidation.Success = false;
                cosmosDBConfigValidation.Message = Enums.CosmosDBValidationMessages.InvalidDBorCONTorDOCorPK;
                return cosmosDBConfigValidation;
            }
            return cosmosDBConfigValidation;
        }
    }
#pragma warning restore
}

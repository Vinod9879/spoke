﻿
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Utils.Enums;
using static SpokeAPI.Utils.EnumsLog;
using static System.Net.Mime.MediaTypeNames;

namespace SpokeAPI.Validations
{
    public static class ValidationManageSubscription
    {
        public static FunctionValidation Validateinput(ManageSubscriptionRequest data, string requestBody, IConnection _connection, Microsoft.Extensions.Logging.ILogger<Functions.ManageSubscription> _logger)
        {
          
            string[] _OperationType = new string[] { "TRUE", "FALSE" };
            FunctionValidation? functionValidation = new FunctionValidation();
            FunctionResponse? _functionResponseResponse = new();
            requestBody = requestBody.Replace("\n", "").Replace("\r", "").Replace(" ", "");
        
            if (requestBody is null || requestBody == string.Empty || requestBody == "")
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.MalformedRequest;
                functionValidation.ResponseCode= Enums.ResponseCode.MalformedRequest;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformat;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformat + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);
                return functionValidation;
            }
            bool val;
            if ((!bool.TryParse(data.IsEnabled.ToString(), out val)))
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatOperationTypeisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatOperationTypeisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);
                return functionValidation;
            }
#pragma warning disable
            if ((string.IsNullOrWhiteSpace( JObject.Parse(requestBody)["IsEnabled"]?.ToString())) || !_OperationType.Any(x=>x.Contains(JObject.Parse(requestBody)["IsEnabled"].ToString().ToUpper())))
                {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatOperationTypeisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatOperationTypeisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);
                return functionValidation;
                
            }
#pragma warning restore
            if (string.IsNullOrWhiteSpace(data.SubscriptionName) || string.IsNullOrWhiteSpace(data.SubscriptionName))
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatSubscriptionNameisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatSubscriptionNameisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);
                return functionValidation;
            }
            if (string.IsNullOrWhiteSpace(data.SubscriptionId) || string.IsNullOrWhiteSpace(data.SubscriptionId))
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatSubscriptionIdisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatSubscriptionIdisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);

                return functionValidation;
            }
            if (string.IsNullOrWhiteSpace(data.Clientid) || string.IsNullOrWhiteSpace(data.Clientid))
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatClientIDisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatClientIDisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);

                return functionValidation;
            }
            if (string.IsNullOrWhiteSpace(data.Database) || string.IsNullOrWhiteSpace(data.Database))
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatDatabaseisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatDatabaseisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);

                return functionValidation;
            }
            if (string.IsNullOrWhiteSpace(data.Container) || string.IsNullOrWhiteSpace(data.Container))
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatContainerisnotsupplied;
                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatContainerisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);

                return functionValidation;
            }
            if (string.IsNullOrWhiteSpace(data.FNF_DocType) || string.IsNullOrWhiteSpace(data.FNF_DocType))
            {
                functionValidation.Success = false;
                functionValidation.Message = ManageSubscriptionMessages.InputNotinExpectedformatDocumenttypeisnotsupplied;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;

                _logger.LogInformation(ManageSubscriptionMessages.InputNotinExpectedformatDocumenttypeisnotsupplied + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);

                return functionValidation;
            }
           

            CosmosDBConfigValidation cosmosDBConfigValidation = ValidationCosmosDBConfig.ValidateCosmosDBObject(data.Database, data.Container, data.FNF_DocType, _connection);
          
            if (cosmosDBConfigValidation.Message != null || cosmosDBConfigValidation.Success == false)
            {
                functionValidation.Success = false;
                functionValidation.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                functionValidation.ResponseCode = Enums.ResponseCode.ValidationError;
                functionValidation.Message = cosmosDBConfigValidation.Message;
                _logger.LogInformation(cosmosDBConfigValidation.Message + General.SubscriptionID + data.SubscriptionId + General.TransactionId + data.TransactionID);
                return functionValidation;
            }

                return functionValidation;
        }
    }
}

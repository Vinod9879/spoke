﻿using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Validations
{
    public static class ValidationCosmosDBObject
    {      
        public static FunctionValidation ValidateCosmosDBObjectInput(CosmosDBObject_Request cosmosDBObject, string requestBody)
        {
            FunctionValidation functionValidation = new FunctionValidation();

            if (cosmosDBObject != null)
            {
                if (cosmosDBObject.OperationType != null)

                {
                    if (cosmosDBObject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.CreateContainer.ToLower())
                    {
                        if (cosmosDBObject.database == null || cosmosDBObject.container == null || cosmosDBObject.scaleandSettings == null || cosmosDBObject.scaleandSettings.partitionkey == null || cosmosDBObject.scaleandSettings.throughput == null)
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_containercreation;
                            return functionValidation;
                        }
                        if (!ValidationQueryAPI.IsvalidInt(cosmosDBObject.scaleandSettings?.throughput?.ToString() ?? ""))
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = Enums.manageCosmosDB.InputBodyinvalidInteger;
                        }
                   

                        if (  !(string.Equals(cosmosDBObject.TimeToLive,Enums.manageCosmosDB.Enable,StringComparison.OrdinalIgnoreCase) || string.Equals(cosmosDBObject.TimeToLive, Enums.manageCosmosDB.Disable,StringComparison.OrdinalIgnoreCase)))
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = Enums.manageCosmosDB.InvalidTimetoLive;
                            return functionValidation;
                        }
                       
                    }
                    else if (cosmosDBObject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.SetContainerThroughputlimit.ToLower())
                    {
                        if (cosmosDBObject.database == null || cosmosDBObject.container == null || cosmosDBObject.scaleandSettings == null || cosmosDBObject.scaleandSettings.throughput == null)
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_throughput;
                        }
                        if(!ValidationQueryAPI.IsvalidInt(cosmosDBObject.scaleandSettings?.throughput?.ToString()??""))
                        { functionValidation.Success = false;
                            functionValidation.Message = Enums.manageCosmosDB.InputBodyinvalidInteger;
                        }
                        //if (cosmosDBObject.scaleandSettings != null && cosmosDBObject.scaleandSettings.throughput < 400)
                        //{
                        //    functionValidation.Success = false;
                        //    functionValidation.Message = CosmosDBValidationMessages.InvalidThroughputValue;
                        //}
                    }
                    else if (cosmosDBObject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.ChangeIndexingPolicy.ToLower())
                    {
                        if (cosmosDBObject.database == null || cosmosDBObject.container == null || cosmosDBObject.scaleandSettings == null || cosmosDBObject.scaleandSettings.indexingPolicy == null)
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_indexing;
                        }
                    }
                    else if (cosmosDBObject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.SetAccountThroughputlimit.ToLower())
                    {
                        if (cosmosDBObject.AccountTotalThroughputLimit == null)
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_account;
                        }
                        if (!ValidationQueryAPI.IsvalidInt(cosmosDBObject.AccountTotalThroughputLimit?.ToString() ?? ""))
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = Enums.manageCosmosDB.InputBodyinvalidAccountThroughtputInteger;
                        }
                    }
                    else if (cosmosDBObject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.ChangeTimeToLive.ToLower())
                    {
                      if (string.IsNullOrWhiteSpace(cosmosDBObject.TimeToLive)|| string.IsNullOrWhiteSpace(cosmosDBObject.database) || string.IsNullOrWhiteSpace(cosmosDBObject.container))
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = Enums.manageCosmosDB.InvalidTimetoLive;
                        }
                        if (!string.IsNullOrWhiteSpace(cosmosDBObject.TimeToLive))
                        {
                            if (!cosmosDBObject.TimeToLive.Equals(Enums.manageCosmosDB.Enable, StringComparison.OrdinalIgnoreCase)
                            &&
                             !cosmosDBObject.TimeToLive.Equals(Enums.manageCosmosDB.Disable, StringComparison.OrdinalIgnoreCase))
                            {
                                functionValidation.Success = false;
                                functionValidation.Message = Enums.manageCosmosDB.InvalidTimetoLive;
                            }
                        }
                        
                    }
                    else 
                    {
                        if (cosmosDBObject.AccountTotalThroughputLimit == null)
                        {
                            functionValidation.Success = false;
                            functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_OperationType;
                        }
                    }

                }
                else
                {
                    functionValidation.Success = false;
                    functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_OperationType;
                }

            }
            else
            {
                functionValidation.Success = false;
                functionValidation.Message = CosmosDBValidationMessages.MandatoryFiedsRequired_containercreation;
            }

            return functionValidation;

        }
      
    }
}

﻿using Microsoft.Azure.Cosmos;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Utils;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Utils.Enums;
using static SpokeAPI.Utils.EnumsLog;

namespace SpokeAPI.Validations
{
    public static class ValidationAPISubscription
    {

        public static async Task<FunctionValidation> CheckAccess(string? SubscriptionId, string? ClientId, string? Database, string? Container, List<string>? FNF_DocType,IConnection _connection)
        {
            FunctionValidation indexSearchValidation = new FunctionValidation { Success = true, Message = string.Empty};

            List<string> permitted_DocTypes = new List<string>();   
            CosmosClient client = _connection.GetReadCosmosClient();
            Container subscriptionContainer = client.GetContainer(_connection.SubscriptionDatabase, _connection.SubscriptionContainer);

#pragma warning disable
            var docTypeParams = new List<string>();
            for (int i = 0; i < FNF_DocType.Count; i++)
            {
                docTypeParams.Add($"@docType{i}");
            }
            var query = new QueryDefinition(
            "SELECT VALUE { FNF_DocType: c.FNF_DocType, SubscriptionName: c.SubscriptionName } " +
            "FROM c " +
            "WHERE c.SubscriptionId = @subscriptionId " +
            "AND c.ClientId = @clientId " +
           $"AND c.FNF_DocType IN ({string.Join(",", docTypeParams)}) " +

            "AND c.Database = @database " +
            "AND c.Container = @container " +
            "AND c.IsEnabled = true")
            .WithParameter("@subscriptionId", SubscriptionId?.ToUpper())
            .WithParameter("@clientId", ClientId?.ToUpper())
            .WithParameter("@database", Database?.ToLower())
            .WithParameter("@container", Container?.ToLower());
            for (int i = 0; i < FNF_DocType.Count; i++)
            {
                query = query.WithParameter($"@docType{i}", FNF_DocType[i].ToUpper());
            }
#pragma warning restore

            indexSearchValidation.CheckAccesQuery = query.QueryText;
            QueryDefinition queryDefinition = query;
            var queryResultSetIterator = subscriptionContainer.GetItemQueryIterator<dynamic>(queryDefinition);
           
            while (queryResultSetIterator.HasMoreResults)
            {
                var currentResultSet = await queryResultSetIterator.ReadNextAsync();
#pragma warning disable
                foreach (var item in currentResultSet)
                {
                    string? strFNF_DocType = "";
                    string? strSubscriptionName = "";
                    JToken jTokenFNF_DocType = item[Enums.AdditionalKeywords.FNF_DocType];
                    strFNF_DocType = ((JValue)jTokenFNF_DocType).Value.ToString();
                    JToken jTokenSubscriptionName = item[Enums.AdditionalKeywords.SubscriptionName];
                    strSubscriptionName = ((JValue)jTokenSubscriptionName).Value.ToString();
                    permitted_DocTypes.Add(strFNF_DocType);
                    indexSearchValidation.SubscriptionDetails =   General.SubscriptionName + strSubscriptionName;
                }
#pragma warning restore
                indexSearchValidation.TotalRequestChargeCheckAccess =  currentResultSet.RequestCharge;
                indexSearchValidation.TotalTimeCheckAccess =  currentResultSet.Diagnostics.GetClientElapsedTime().Milliseconds;
            }

            List<string> notpermitted_DocTypes = FNF_DocType.Except(permitted_DocTypes, StringComparer.OrdinalIgnoreCase).ToList();

            if (notpermitted_DocTypes.Count > 0)
            {
                indexSearchValidation.Success = false;
                indexSearchValidation.Message = string.Format(ValidationAPISubscriptionMessages.NotAllowedDocTypes,string.Join(", ", notpermitted_DocTypes));
            }

            return indexSearchValidation;
        }
    }
}

﻿
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Validations
{
    public static class ValidationPointedLookup
    {
        public static async Task<FunctionValidation> ValidatePointedSearchInput(PointedLookupRequest? pointedLookupRequest, Microsoft.Extensions.Logging.ILogger<Functions.PointLookup> _logger, IConnection connection)
        {
            FunctionValidation functionValidation = new FunctionValidation();
            CosmosDBConfigValidation cosmosDBConfigValidation =  ValidationCosmosDBConfig.ValidateCosmosDBObject(pointedLookupRequest,connection);
            functionValidation.Message = cosmosDBConfigValidation.Message;
            functionValidation.Success = cosmosDBConfigValidation.Success;
            if (functionValidation.Success == false) {
                return functionValidation;
            }
            functionValidation = new();
            List<string> FnF_doctype = new List<string>();
            if (pointedLookupRequest?.FNF_DocType != null)
              FnF_doctype = pointedLookupRequest.FNF_DocType.Split(',').ToList();
            functionValidation = await ValidationAPISubscription.CheckAccess(pointedLookupRequest?.SubscriptionKey, pointedLookupRequest?.ClientId, pointedLookupRequest?.Database, pointedLookupRequest?.Container, FnF_doctype,connection);
            _logger.LogInformation(CosmosDBValidationMessages.CheckAccessstarted,  functionValidation.CheckAccesQuery, CommonModels.GlobalTransactionID.TransactionID, pointedLookupRequest?.SubscriptionKey);
            return functionValidation;
        }
    }
    }

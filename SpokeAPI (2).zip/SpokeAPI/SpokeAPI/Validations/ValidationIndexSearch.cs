﻿using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;
using static SpokeAPI.Utils.EnumsLog;

namespace SpokeAPI.Validations
{
    public static class ValidationIndexSearch
    {
        public static async Task<FunctionValidation> ValidateIndexSearchInput(IndexSearchRequest? indexSearchRequest,IConnection _connection, Microsoft.Extensions.Logging.ILogger<Functions.IndexSearch> _logger)
        {
            FunctionValidation functionValidation = new FunctionValidation();
            if (string.IsNullOrWhiteSpace(indexSearchRequest?.Search_Type) || !IsValidSearchType(indexSearchRequest?.Search_Type?.ToString()))
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.InvalidsearchType;
                return functionValidation;
            }
            CosmosDBConfigValidation? cosmosDBConfigValidation = ValidationCosmosDBConfig.ValidateCosmosDBObject(indexSearchRequest?.Database?.ToString(), indexSearchRequest?.Container?.ToString(), indexSearchRequest?.Search_Type , indexSearchRequest?.FNF_DocType, _connection);
            if (cosmosDBConfigValidation.Message != null || cosmosDBConfigValidation.Success == false)
            {
                functionValidation.Success = false;
                functionValidation.Message = cosmosDBConfigValidation.Message;
                return functionValidation;
            }
            
          
            if(string.Equals(indexSearchRequest?.Search_Type, Enums.SearchType.AddressSearch,StringComparison.OrdinalIgnoreCase))
            {
                functionValidation = AddressSearchValidation(indexSearchRequest, functionValidation);
                if (functionValidation.Success == false) return functionValidation;
            }
            if ( string.Equals( indexSearchRequest?.Search_Type, Enums.SearchType.Document,StringComparison.OrdinalIgnoreCase))
            {
                functionValidation = DocumentSearchValidation(indexSearchRequest, functionValidation);
                if (functionValidation.Success == false) return functionValidation;
            }
            if (string.Equals(indexSearchRequest?.Search_Type, Enums.SearchType.Owner, StringComparison.OrdinalIgnoreCase))
            {
                List<string> FnfDocType = new List<string>();
                FnfDocType.Add(Enums.FnfDocType.ASMT.ToString());
                if(indexSearchRequest!=null) 
                indexSearchRequest.FNF_DocType = FnfDocType;
                functionValidation = OwnerSearchValidation(indexSearchRequest, functionValidation);
                if (functionValidation.Success == false) return functionValidation;
            }

            if (indexSearchRequest?.searchInfo?.FIPS?.Length !=5)
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.FipsInvalid;
                return functionValidation;
            }
            if (!string.Equals( indexSearchRequest?.Match_Type, Enums.MatchType.Exact.ToString(),StringComparison.OrdinalIgnoreCase ))
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.InvalidMatchType;
                return functionValidation;
            }

            functionValidation = await ValidationAPISubscription.CheckAccess(indexSearchRequest?.SubscriptionKey, indexSearchRequest?.ClientId, indexSearchRequest?.Database, indexSearchRequest?.Container, indexSearchRequest?.FNF_DocType,_connection);
            _logger.LogInformation(CosmosDBValidationMessages.CheckAccessstarted, functionValidation.CheckAccesQuery, CommonModels.GlobalTransactionID.TransactionID, indexSearchRequest?.SubscriptionKey);
            if (!string.IsNullOrWhiteSpace(functionValidation.SubscriptionDetails))
            _logger.LogInformation(General.Checkaccesscomplete + functionValidation.SubscriptionDetails + General.TransactionId + indexSearchRequest?.TransactionId + General.SubscriptionID + indexSearchRequest?.SubscriptionKey );
            return functionValidation;
        }

        public static bool IsValidSearchType(string? searchType)
        {
            return string.Equals(searchType, SearchType.AddressSearch, StringComparison.OrdinalIgnoreCase)||
                string.Equals(searchType, SearchType.Document, StringComparison.OrdinalIgnoreCase)
           || string.Equals(searchType, SearchType.Owner, StringComparison.OrdinalIgnoreCase);
           
        }


        public static FunctionValidation AddressSearchValidation(IndexSearchRequest? indexSearchRequest,FunctionValidation functionValidation)
        {
            if (indexSearchRequest?.isFipsApnDipdSearch() == false && indexSearchRequest.isFipsFullStCityState() == false && indexSearchRequest.isFipsFullStZip() == false)
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.Invalidsearchcombination;
                return functionValidation;
            }
            return functionValidation;
        }
        public static FunctionValidation DocumentSearchValidation(IndexSearchRequest? indexSearchRequest, FunctionValidation functionValidation)
        {
            if (string.IsNullOrWhiteSpace(indexSearchRequest?.searchInfo?.FIPS?.ToString()) || string.IsNullOrWhiteSpace(indexSearchRequest?.searchInfo?.RecordingDate?.ToString()) || indexSearchRequest?.FNF_DocType?.Count ==0)
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.InvalidFipsRecordingdate;
                return functionValidation;
            }
            if (indexSearchRequest?.isFipsRecordingDateBookNumberPageNumberFileType() == false && indexSearchRequest.isFipsRecordingDateDocumentNumberFileType() == false)
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.Invalidsearchcombination;
                return functionValidation;
            }
            return functionValidation;
        }

        public static FunctionValidation OwnerSearchValidation(IndexSearchRequest? indexSearchRequest, FunctionValidation functionValidation)
        {
            if (string.IsNullOrWhiteSpace(indexSearchRequest?.searchInfo?.OwnerName?.ToString()) || string.IsNullOrWhiteSpace(indexSearchRequest?.searchInfo?.FIPS?.ToString()))
            {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.InvalidFipsOwnerName;
                return functionValidation;
            }

            if (string.IsNullOrWhiteSpace(CommonMethod.parseOwnername(indexSearchRequest?.searchInfo?.OwnerName?.ToString()??""))) {
                functionValidation.Success = false;
                functionValidation.Message = IndexSearchMessages.InvalidFipsOwnerName;
                return functionValidation;
            }
            return functionValidation;
        }
    }
}

﻿using Azure.ResourceManager.CosmosDB.Models;
using Google.Protobuf.WellKnownTypes;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.FileSystemGlobbing.Internal;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interfaceimplementation.Functions.QueryAPILogic;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Models.QueryAPIModel;
using static SpokeAPI.Utils.Enums;
using static System.Net.Mime.MediaTypeNames;

namespace SpokeAPI.Validations
{
    public static class ValidationQueryAPI
    {
        private static FunctionValidation _functionResponse = new FunctionValidation();

        public static FunctionValidation? ValidateQueryAPI(string requestbody)
        {
            _functionResponse.Success = true;
            if (string.IsNullOrWhiteSpace(requestbody))
            {
                _functionResponse.Success = false;
                _functionResponse.ResponseCode = Enums.ResponseCode.MalformedRequest;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.MalformedRequest;
                _functionResponse.Message = QueryAPIMessages.InputNotinExpectedformatBodycannotBeEmpty;
                return _functionResponse;
            }
            if (!IsvalidJson(requestbody, _functionResponse))
            {
                _functionResponse.Success = false;
                _functionResponse.ResponseCode = Enums.ResponseCode.MalformedRequest;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.MalformedRequest;
                _functionResponse.Message = QueryAPIMessages.InputJsonBodyNotValid;
                return _functionResponse;
            };
            if (!CheckifQueryParameterExists(requestbody))
            {
                _functionResponse.ResponseCode = Enums.ResponseCode.MalformedRequest;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.MalformedRequest;
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.InputInvalidQueryParameter;
                return _functionResponse;
            }
            if (!CheckifQueryParameterExists(requestbody))
            {
                _functionResponse.ResponseCode = Enums.ResponseCode.ValidationError;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.InputNotinExpectedformatKeywordNotMatching;
            }
           

            return _functionResponse;
        }

        public static ParseQueryAPIRequest? ValidatePartitionKeyFilterApplied(ParseQueryAPIRequest? parseQueryAPIRequest, HttpRequest req, IConnection connection)
        {
           
            List<ConfigPartitionKeys>? _configPartitionKeys = connection.GetConfigPartitionKeys();
            ParseQueryAPIRequest? parseQueryAPIRequestReturn = OrderPartitionKeyQueryAPI.FuncOrderPartitionKeyQueryAPI(req, parseQueryAPIRequest, _configPartitionKeys, connection);
         
            List<CosmosDBConfig>? _cosmosDBConfig = connection.Getcosmosdb_config();
            List<string>? QueryParam = _cosmosDBConfig?
                .Where(a => string.Equals(a.database, parseQueryAPIRequest?.queryAPIRequest?.Database ?? "", StringComparison.OrdinalIgnoreCase)
                         && string.Equals(a.container, parseQueryAPIRequest?.queryAPIRequest?.Container ?? "", StringComparison.OrdinalIgnoreCase))
                .Select(x => x.query_params)
                .FirstOrDefault();

            if (QueryParam == null)
            {
                _functionResponse.Success = false;
                _functionResponse.Message = Enums.CosmosDBValidationMessages.InvalidDBorCONT;
                parseQueryAPIRequestReturn ??= new ParseQueryAPIRequest();
                parseQueryAPIRequestReturn.functionValidation = _functionResponse;
                return parseQueryAPIRequestReturn;
            }

            if (parseQueryAPIRequestReturn?.queryAPIRequest?.QueryParameter?.Count == 0)
            {
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.FilterParameterCannotBeEmpty;
                _functionResponse.ResponseCode = Enums.ResponseCode.ValidationError;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                parseQueryAPIRequestReturn.functionValidation = _functionResponse;
                return parseQueryAPIRequestReturn;
            }
            if (CheckIfComplexQueriesApplied(parseQueryAPIRequestReturn?.queryAPIRequest?.query))
            {
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.SubqueryAggregationFunctionsNotAllowed;
                _functionResponse.ResponseCode = Enums.ResponseCode.ValidationError;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                if (parseQueryAPIRequestReturn != null)
                {
                    parseQueryAPIRequestReturn.functionValidation = _functionResponse;
                    return parseQueryAPIRequestReturn;
                }
            }
            if (!CheckIfPartitionKeyStringExists(parseQueryAPIRequest?.queryAPIRequest?.PartitionKeys, parseQueryAPIRequestReturn?.queryAPIRequest?.query))
            {
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.InvalidPartitionKey;
                _functionResponse.ResponseCode = Enums.ResponseCode.ValidationError;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                if (parseQueryAPIRequestReturn != null)
                {
                    parseQueryAPIRequestReturn.functionValidation = _functionResponse;
                    return parseQueryAPIRequestReturn;
                }
            }
            if (!CheckIfFilterApplied(parseQueryAPIRequestReturn?.queryAPIRequest?.query ))
            {
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.FilterWhereClauseNotAppiled;
                _functionResponse.ResponseCode = Enums.ResponseCode.ValidationError;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                if (parseQueryAPIRequestReturn != null)
                {
                    parseQueryAPIRequestReturn.functionValidation = _functionResponse;
                    return parseQueryAPIRequestReturn;
                }
            }


            if (ValidateContinuationToken(parseQueryAPIRequestReturn?.queryAPIRequest?.req))
            {
                _functionResponse.Success = false;
                _functionResponse.Message = QueryAPIMessages.InputInvalidQueryParameterInvalid;
                _functionResponse.ResponseCode = Enums.ResponseCode.ValidationError;
                _functionResponse.ResponseCodeDescription = Enums.ResponseCodeDescription.ValidationError;
                if (parseQueryAPIRequestReturn != null)
                { 
                parseQueryAPIRequestReturn.functionValidation = _functionResponse;
                return parseQueryAPIRequestReturn;
                }
            }
    
                return parseQueryAPIRequestReturn;
        }

        private static bool ValidateContinuationToken(HttpRequest? httpRequest)
        {
            if (httpRequest == null) { return false; }
            if(httpRequest.Query.Count == 0) { return false; }
            if (!httpRequest.Query.Keys.Contains(Enums.HttpRequestUrlParameters.ContinuationToken, StringComparer.OrdinalIgnoreCase))
            { 
            return true;
            }
 
           return false;
        }

        static bool CheckIfFilterApplied(string? query)
        {
            if (query == null) { return false; }
            if (query.Contains(Enums.HttpRequestUrlParameters.Where))
            { return true; }
            else { return false; }
        }

      public  static bool IsvalidJson(string requestBody, FunctionValidation? functionValidation)
        {
            try
            {
                var v = JsonDocument.Parse(requestBody);
                return true;
            }
            catch (Exception)
            {
                _functionResponse.Success = false;
                _functionResponse.Message = Enums.QueryAPIMessages.invalidJsonBody;
                return false;
            }
        }

        public static bool IsvalidInt(string Intvalue)
        {
            try
            {
                int.Parse(Intvalue);
                return true;
            }
            catch (Exception)
            {
               
                return false;
            }
        }

        static bool CheckifQueryParameterExists(string reqestBody)
        {
            JObject jsonObject = JObject.Parse(reqestBody);
            if(jsonObject.Count != 2)
            { return false; }
            if (!Regex.IsMatch(reqestBody,Enums.HttpRequestUrlParameters.Query, RegexOptions.IgnoreCase))
            { return false; }
            else if (jsonObject.Count == 2 && !Regex.IsMatch(reqestBody,Enums.HttpRequestUrlParameters.Parameter,RegexOptions.IgnoreCase))
            { return false; }
            else { return true; }
        }
        static bool CheckIfComplexQueriesApplied(string? query)
        {
            if (query == null) { return true; }
           
            RegexOptions regexOptions = RegexOptions.IgnoreCase;
            if (Regex.IsMatch(query, QueryAPIComplexQueryRestriction.RestrictedKeywordsRegPattern, regexOptions))
            {
                { return true; }
            }
            Regex regex = new Regex(QueryAPIComplexQueryRestriction.SubQueryRegPattern, RegexOptions.IgnoreCase);
            MatchCollection matches = regex.Matches(query);
            if (matches.Count >= 2) { return true; }
            { return false; }
            
        }

        static bool CheckIfPartitionKeyStringExists(IEnumerable<List<string>>? listOfLists, string? sample)
        {
            if (listOfLists == null || sample == null) { return false; }
            sample = "." + sample.Trim() + "=";
            var partitionKeylist = listOfLists.Skip(0).FirstOrDefault();
            if (partitionKeylist == null) { return false; }  
            if (partitionKeylist != null)
            {
                foreach (var v in partitionKeylist.Skip(1))
                {
                    if (!sample.Contains("." + v.ToString() + "=", StringComparison.Ordinal))
                        { return false; }
                    
                }
               
                    return true;
            }
            return false;
        }
    }


}

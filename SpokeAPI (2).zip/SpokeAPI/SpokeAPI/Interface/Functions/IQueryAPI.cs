﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;

namespace SpokeAPI.Interface.Functions
{
    public interface IQueryAPI
    {
        Task<IActionResult> GetQueryResult(HttpRequest req, ILogger<QueryAPI> _logger, IConnection connection);
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpokeAPI.Interface.Functions
{
  public  interface IManageSubscriptions
    {
     Task<dynamic>  UpsertSubscription(HttpRequest req, IConnection _connection, ILogger<ManageSubscription> _logger);
      
    }
}

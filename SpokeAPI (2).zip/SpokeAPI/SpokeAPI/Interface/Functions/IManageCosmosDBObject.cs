﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpokeAPI.Interface.Functions
{
    public interface  IManageCosmosDBObject
    {
        Task<IActionResult> ManageCosmosDB(HttpRequest req,IConnection connection, ILogger<ManageCosmosDBObject> _logger);
    }
}

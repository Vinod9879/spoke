﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interfaceimplementation.Functions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.PointedLookupModel;

namespace SpokeAPI.Interface.Functions
{
    public interface   IPointedLookup
    {
        Task<dynamic> LookupAsync(HttpRequest req , ILogger<PointLookup> logger, IConnection connection);
    }
}

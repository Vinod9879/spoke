﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interface.Functions
{
    public interface IIndexSearch
    {
        Task<dynamic?> IndexSearchAsyc(HttpRequest httpRequest,IConnection _connection, ILogger<IndexSearch> _logger);
        public string BuildQuery(IndexSearchRequest indexSearchRequest);

    }

    public interface IIndexSearchCommonEngine
    {
        public Task< (IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?, QuerySearchResult?)> IndexSearchCommonEngine(IndexSearchRequest indexSearchRequest,IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger);
    }


    public interface IIndexSearchDocumentGetPropertyEngine
    {
        public Task<(IndexSearchPropertyResponse?,  QuerySearchResult?)> IndexSearchDocumentGetPropertyEngine(IndexSearchRequest indexSearchRequest, IndexSearchPropertySearchResponse indexSearchPropertySearchResponse, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger);
    }

    public interface IDocumentProperytSearchHandler
    {
        public Task<IndexSearchPropertyResponse> IndexSearchDocumentEngine(IndexSearchRequest indexSearchRequest, IndexSearchPropertySearchResponse indexSearchPropertySearchResponse, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger);

    }



    public interface IIndexSearchEngineHandler
    {
        public Task<dynamic?> IndexSearchEngineHandler(IndexSearchRequest indexSearchRequest, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger);
    }


}

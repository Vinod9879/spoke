﻿using Azure.Core;
using Azure.ResourceManager;
using Azure.ResourceManager.CosmosDB;
using Microsoft.Azure.Cosmos;
using SpokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpokeAPI.Interface.Connection
{
    public interface IConnection
    {
        CosmosClient GetReadWriteCosmosClient();
        CosmosClient GetReadCosmosClient();
        List<ConfigPartitionKeys>? GetConfigPartitionKeys();
        List<CosmosDBConfig>? Getcosmosdb_config();
        ArmClient? GetArmClient();
        ResourceIdentifier GetResourceIdentifier();
        CosmosDBAccountResource GetCosmosDBAccountResource(ArmClient armclient, ResourceIdentifier resourceIdentifier);
         Task<(bool, CosmosDBSqlDatabaseCollection)> GetCheckIfdatabaseExistsAsync(CosmosDBAccountResource cosmosAccount, string databaseName);
        public string MaxItemCount { get; set; }
        public string CosmosEndpoint { get; set; }
        public string SubscriptionDatabase {  get; set; }
        public string SubscriptionContainer { get; set; }
        public string subscriptionId { get; set; }
        public string resourceGroupName { get; set; }
        public string ReadWriteClientID { get; set; }
        public string ReadClientID { get; set; }
        public string DatabaseVersionConfig { get; set; }

    }
}

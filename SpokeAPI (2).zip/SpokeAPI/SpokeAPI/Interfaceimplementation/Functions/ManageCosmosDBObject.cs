﻿#nullable disable

using Azure.Core;
using Azure.Identity;
using Azure.ResourceManager.CosmosDB.Models;
using Azure.ResourceManager.CosmosDB;
using Azure.ResourceManager;
using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using SpokeAPI.Validations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Utils.Enums;
using Azure.ResourceManager.Resources;
using Microsoft.Azure.Cosmos;
using System.Text.Json;
using SpokeAPI.Interface.Connection;
using static SpokeAPI.Models.IndexSearchModel;
using System.Data.Common;
using System.ComponentModel;

namespace SpokeAPI.Interfaceimplementation.Functions
{
    public class ManageCosmosDBObject : IManageCosmosDBObject
    {
        //private CosmosDBObject_Request databaseobject = new();
        public async Task<IActionResult> ManageCosmosDB(HttpRequest req, IConnection _connection, ILogger<SpokeAPI.Functions.ManageCosmosDBObject> _logger)
        {
            try
            {
                string subscriptionId = _connection.subscriptionId;
                string resourceGroupName = _connection.resourceGroupName;
                string accountName = _connection.CosmosEndpoint;
                accountName = accountName.Split('.')[0].Replace("https://", string.Empty);

                string _callerSubscription_Key = req.Headers["SubscriptionKey"].ToString();

                FunctionResponse _functionResponse = new();
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                bool isvalidJson = ValidationQueryAPI.IsvalidJson(requestBody, null);
                if (!isvalidJson)
                {

                    _logger.LogError("SubscriptionId = " + req.Headers["SubscriptionKey"].ToString() + " " + Enums.ManageSubscriptionMessages.InputBodyNotValid + " " + CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(_functionResponse.Create(ResponseCode.MalformedRequest, ResponseCodeDescription.MalformedRequest, Enums.IndexSearchMessages.InputBodyNotValid)) { StatusCode = 400 };

                }

                var databaseobject = JsonConvert.DeserializeObject<CosmosDBObject_Request>(requestBody);


                _logger.LogInformation(EnumsLog.General.Readbodyissuccessfull, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                _logger.LogInformation(EnumsLog.General.Validating_user_input, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                FunctionValidation validationCosmosDBObject = ValidationCosmosDBObject.ValidateCosmosDBObjectInput(databaseobject, requestBody);
                _logger.LogInformation(EnumsLog.General.Validation_success, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);

                if (validationCosmosDBObject.Message != null && validationCosmosDBObject.Success == false)
                {
                    _logger.LogError("SubscriptionId = " + req.Headers["SubscriptionKey"].ToString() + " " + Enums.ManageSubscriptionMessages.InputBodyNotValid + " " + CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(_functionResponse.Create(ResponseCode.ValidationError, ResponseCodeDescription.ValidationError, validationCosmosDBObject.Message)) { StatusCode = 400 };
                }


                ArmClient armClient = _connection.GetArmClient();
                ResourceIdentifier resourceId = _connection.GetResourceIdentifier();
                CosmosDBAccountResource cosmosAccount = _connection.GetCosmosDBAccountResource(armClient, resourceId);

                if (databaseobject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.SetAccountThroughputlimit.ToLower())
                {
                    CosmosDBAccountPatch a = new CosmosDBAccountPatch();
                    a.CapacityTotalThroughputLimit = int.Parse(databaseobject.AccountTotalThroughputLimit.ToString());

                    var x = cosmosAccount.UpdateAsync(WaitUntil.Completed, a);

                    return new OkObjectResult(_functionResponse.Create(ResponseCode.Success, ResponseCodeDescription.Success, "Request Processed Successfully"));

                }

                string databaseName = databaseobject.database.ToLower();
                string containerName = databaseobject.container.ToLower();


                (bool databaseExists, var databases) = await _connection.GetCheckIfdatabaseExistsAsync(cosmosAccount, databaseName);

                if (databaseobject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.SetContainerThroughputlimit.ToLower())
                {
                    if (databaseExists)
                    {
                        _logger.LogInformation(EnumsLog.ManageCosmosDB.StartedUpdateThroughput, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                        validationCosmosDBObject = await UpdateThroughputAsync(databaseobject, subscriptionId, resourceGroupName, accountName, _connection, _logger);
                        if (validationCosmosDBObject.Success == false)
                        {
                            return new OkObjectResult(_functionResponse.Create(ResponseCode.ValidationError, ResponseCodeDescription.ValidationError, validationCosmosDBObject.Message)) { StatusCode = 400 };
                        }
                        _logger.LogInformation(EnumsLog.ManageCosmosDB.CompletedUpdateThroughputUpdate, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                    }

                    return new OkObjectResult(_functionResponse.Create(ResponseCode.Success, ResponseCodeDescription.Success, "Request Processed Successfully"));

                }

                var containerPartitionKey = new CosmosDBContainerPartitionKey();
                var indexingpolicy = new CosmosDBIndexingPolicy();
                CosmosDBIndexingMode index = CosmosDBIndexingMode.Consistent;
                indexingpolicy.IndexingMode = index;


                containerPartitionKey.Kind = CosmosDBPartitionKind.MultiHash;
                containerPartitionKey.Version = 2;
                if (databaseobject.scaleandSettings != null)
                {
                    for (int i = 0; i < databaseobject.scaleandSettings.partitionkey.Count; i++)
                    {
                        containerPartitionKey.Paths.Add(databaseobject.scaleandSettings.partitionkey[i]);
                    }


                    if (databaseobject.scaleandSettings.indexingPolicy != null && databaseobject.scaleandSettings.indexingPolicy.IncludePath != null)
                        for (int i = 0; i < databaseobject.scaleandSettings.indexingPolicy.IncludePath.Count; i++)
                            indexingpolicy.IncludedPaths.Add(new CosmosDBIncludedPath { Path = databaseobject.scaleandSettings.indexingPolicy.IncludePath[i] });

                    if (databaseobject.scaleandSettings.indexingPolicy != null && databaseobject.scaleandSettings.indexingPolicy.ExcludePath != null)
                        for (int i = 0; i < databaseobject.scaleandSettings.indexingPolicy.ExcludePath.Count; i++)
                            indexingpolicy.ExcludedPaths.Add(new CosmosDBExcludedPath { Path = databaseobject.scaleandSettings.indexingPolicy.ExcludePath[i] });
                }
                if (databaseobject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.ChangeIndexingPolicy.ToLower())
                {
                    var resource = new CosmosDBSqlContainerResourceInfo(containerName)
                    {
                        PartitionKey = containerPartitionKey,
                        IndexingPolicy = indexingpolicy,
                    };
                    var database = await databases.GetAsync(databaseName);

                    var containers = database.Value.GetCosmosDBSqlContainers();
                    bool containerExists = await containers.ExistsAsync(containerName);

                    var container = await containers.GetAsync(containerName);
                    var containerData = container.Value.Data;

                    var requestContent = new CosmosDBSqlContainerCreateOrUpdateContent(new AzureLocation(), resource);
                    var response = await containers.CreateOrUpdateAsync(WaitUntil.Completed, containerName, requestContent);
                }

                if (databaseobject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.CreateContainer.ToLower())

                {
                    if (!databaseExists)
                    {
                        var requestContent = new CosmosDBSqlDatabaseCreateOrUpdateContent(new AzureLocation(), new CosmosDBSqlDatabaseResourceInfo(databaseName));

                        _logger.LogInformation(EnumsLog.ManageCosmosDB.CreatingNewdatabase, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                        var response = await databases.CreateOrUpdateAsync(WaitUntil.Completed, databaseName, requestContent);
                        _logger.LogInformation(EnumsLog.ManageCosmosDB.CreatingNewdatabaseSuccessful, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                        var createdDatabase = response.Value;
                    }
                    var database = await databases.GetAsync(databaseName);

                    var containers = database.Value.GetCosmosDBSqlContainers();
                    bool containerExists = await containers.ExistsAsync(containerName);

                    if (!containerExists)
                    {

                        var resource = new CosmosDBSqlContainerResourceInfo(containerName)
                        {
                            PartitionKey = containerPartitionKey,
                            IndexingPolicy = indexingpolicy,
                        };
                        if (string.Equals(databaseobject.TimeToLive.ToString(), Enums.manageCosmosDB.Enable, StringComparison.OrdinalIgnoreCase))
                        {
                            resource.DefaultTtl = -1;
                        }
                        else { resource.DefaultTtl = null; }

                        var requestContent = new CosmosDBSqlContainerCreateOrUpdateContent(new AzureLocation(), resource);
                        requestContent.Options = new CosmosDBCreateUpdateConfig();

                        requestContent.Options.Throughput = int.Parse(databaseobject.scaleandSettings.throughput);
                        _logger.LogInformation(EnumsLog.ManageCosmosDB.CreatingContainerStarted, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                        var response = await containers.CreateOrUpdateAsync(WaitUntil.Completed, containerName, requestContent);
                        _logger.LogInformation(EnumsLog.ManageCosmosDB.CreatingContainerSuccess, _callerSubscription_Key, CommonModels.GlobalTransactionID.TransactionID);
                        var createdContainer = response.Value;
                    }
                }



                if (databaseobject.OperationType.ToLower() == CosmosDBObjectAPIOperationType.ChangeTimeToLive.ToLower())
                {
                    int? DefaultTtl = null;
                    if (string.Equals(databaseobject.TimeToLive.ToString(), Enums.manageCosmosDB.Enable, StringComparison.OrdinalIgnoreCase))
                    {
                        DefaultTtl = -1;
                    }
                    else { DefaultTtl = null; }

                    if (!databaseExists)
                        return new OkObjectResult(_functionResponse.Create(ResponseCode.ValidationError, ResponseCodeDescription.ValidationError, Enums.manageCosmosDB.Invaliddatabasecontainer));
                    var database = await databases.GetAsync(databaseName);

                    var containers = database.Value.GetCosmosDBSqlContainers();
                    bool containerExists = await containers.ExistsAsync(containerName);
                    if (containerExists)
                    {
                        Azure.Response<CosmosDBSqlContainerResource> container = await containers.GetAsync(containerName);

                        var containerData = container.Value.Data;


                        var resource = new CosmosDBSqlContainerResourceInfo(containerName)
                        {
                            DefaultTtl = DefaultTtl,
                            PartitionKey = containerData.Resource.PartitionKey,
                            IndexingPolicy = containerData.Resource.IndexingPolicy

                        };

                        var requestContent = new CosmosDBSqlContainerCreateOrUpdateContent(new AzureLocation(), resource);
                        var response = await containers.CreateOrUpdateAsync(WaitUntil.Completed, containerName, requestContent);
                    }
                    else
                        return new OkObjectResult(_functionResponse.Create(ResponseCode.ValidationError, ResponseCodeDescription.ValidationError, Enums.manageCosmosDB.Invaliddatabasecontainer));
                }
                return new OkObjectResult(_functionResponse.Create(ResponseCode.Success, ResponseCodeDescription.Success, "Request Processed Successfully"));
            }
            catch (Exception ex)
            {
                FunctionResponse _functionResponse = new(); _logger.LogError(ex.Message.ToString());
                return new ObjectResult(CommonMethod.ManageCosmosDBObjectException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID, ResponseCodeDescription.InternalServerError, ResponseCode.InternalServerError))
                {
                    StatusCode = 500
                };
            }
        }

        public async Task<FunctionValidation> UpdateThroughputAsync(CosmosDBObject_Request databaseobject, string subscriptionId, string resourceGroupName, string accountName, IConnection _connection, ILogger<SpokeAPI.Functions.ManageCosmosDBObject> _logger)
        {
            FunctionValidation functionValidation = new FunctionValidation();
            var armClient = _connection.GetArmClient();
            SubscriptionResource subscription = armClient.GetSubscriptionResource(new ResourceIdentifier($"/subscriptions/{subscriptionId}"));
            ResourceGroupResource resourceGroup = await subscription.GetResourceGroups().GetAsync(resourceGroupName);
            CosmosDBAccountResource cosmosAccount = await resourceGroup.GetCosmosDBAccounts().GetAsync(accountName);
            CosmosDBSqlDatabaseResource database = await cosmosAccount.GetCosmosDBSqlDatabases().GetAsync(databaseobject.database);
            CosmosDBSqlContainerResource container = await database.GetCosmosDBSqlContainers().GetAsync(databaseobject.container);
            CosmosDBSqlContainerThroughputSettingResource throughputSetting = await container.GetCosmosDBSqlContainerThroughputSetting().GetAsync();
            if (int.Parse(throughputSetting.Data.Resource.MinimumThroughput) > int.Parse(databaseobject.scaleandSettings.throughput))
            {
                functionValidation.Success = false;
                functionValidation.Message = CosmosDBValidationMessages.InvalidContainerThroughputValue + throughputSetting.Data.Resource.MinimumThroughput;
                return functionValidation;
            }
            if (throughputSetting.Data.Resource.Throughput != int.Parse(databaseobject.scaleandSettings.throughput))
            {
                throughputSetting.Data.Resource.Throughput = int.Parse(databaseobject.scaleandSettings.throughput);
                string location = cosmosAccount.Data.Location;
                AzureLocation azureLocation = new AzureLocation(location);
                ThroughputSettingsUpdateData throughputSettingsUpdateData = new ThroughputSettingsUpdateData(azureLocation, throughputSetting.Data.Resource);
                try
                {
                    var Result = await container.GetCosmosDBSqlContainerThroughputSetting().CreateOrUpdateAsync(WaitUntil.Completed, throughputSettingsUpdateData);
                }
                catch (Exception e)
                {
                    string extractedMessage = "";
                    string message = e.Message.ToString();
                    int startIndex = message.IndexOf("Errors") + "Message: ".Length;
                    int endIndex = message.IndexOf("ActivityId:");
                    if (startIndex >= 0 && endIndex > startIndex)
                    {
                        extractedMessage = message.Substring(startIndex, endIndex - startIndex).Replace("[\"", " ");
                        Console.WriteLine(extractedMessage);
                    }


                    FunctionResponse _functionResponse = new();
                    _logger.LogError(e.Message.ToString());
                    functionValidation.Success = false;
                    functionValidation.Message = extractedMessage.Substring(3, extractedMessage.Length - 11);
                }
            }
            return functionValidation;
        }
    }
}

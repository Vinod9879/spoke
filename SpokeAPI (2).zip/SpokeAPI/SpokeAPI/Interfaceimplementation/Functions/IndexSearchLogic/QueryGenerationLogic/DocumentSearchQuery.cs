﻿using Microsoft.Azure.Cosmos;
using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenerationLogic
{
    public static class DocumentSearchQuery
    {

#pragma warning disable
        public static string FipsRecordingDateDocumentNumberFileTypeQueryGenerator(List<SearchQueryParameters> searchQueryParameters , IndexSearchRequest indexSearchRequest)
        {

            string query = string.Format(Enums.IndexSearchMessages.FipsRecordingDateDocumentNumberFileTypeQuery, searchQueryParameters[0].SearchPropertyValue, searchQueryParameters[1].SearchPropertyValue, searchQueryParameters[2].SearchPropertyValue, string.Join("','", indexSearchRequest?.FNF_DocType).ToUpper());
            return query;
        }

        public static string FipsRecordingDateBookNumberPageNumberFileType(List<SearchQueryParameters> searchQueryParameters, IndexSearchRequest indexSearchRequest)
        {

            string query = string.Format(Enums.IndexSearchMessages.FipsRecordingDateBookNumberPageNumberFileType, searchQueryParameters[0].SearchPropertyValue, searchQueryParameters[1].SearchPropertyValue, searchQueryParameters[2].SearchPropertyValue, searchQueryParameters[3].SearchPropertyValue, string.Join("','", indexSearchRequest?.FNF_DocType).ToUpper());
            return query;
        }
#pragma warning restore
    }
}

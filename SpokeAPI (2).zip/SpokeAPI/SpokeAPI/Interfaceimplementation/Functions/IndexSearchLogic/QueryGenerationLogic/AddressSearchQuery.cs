﻿using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenationLogic
{
    public static class AddressSearchQueryGeneration
    {
        public static string AddressSearchQueryLogic(List<SearchQueryParameters> searchQueryParameters,IndexSearchRequest indexSearchRequest)
        {

            /* Bug #555799
             * Below properties are converted to Upper case based on the bug. This needs to be implemented in Property_Search container also, i.e., all searchable field in property_search container should be in Upper case so the case sensitivity is not applied and results are fetched everytime
             * param.SearchPropertyValue.ToUpper()
             * indexSearchRequest.Search_Type.ToUpper()
            */
            string Query = Enums.QueryKeyword.selectFrom + Enums.QueryKeyword.where;

            foreach (SearchQueryParameters param in searchQueryParameters)
            {
                Query += Enums.QueryKeyword.TableAliasC +
               Enums.QueryKeyword.Dot + param.SearchPropertyDBname + "=" +
               Enums.QueryKeyword.singleQuote + param?.SearchPropertyValue?.ToUpper() + Enums.QueryKeyword.singleQuote;
                Query += Enums.QueryKeyword.and;
            }
            if (indexSearchRequest?.searchInfo?.APN == null || indexSearchRequest.searchInfo.APN == "")
            {
                Query += Enums.QueryKeyword.TableAliasC +
                        Enums.QueryKeyword.Dot + Enums.QueryKeyword.Searchtype + Enums.QueryKeyword.singleQuote + Enums.DocType.APN_ADDRESS_OWNER + Enums.QueryKeyword.singleQuote + Enums.QueryKeyword.and;
            }
            Query = Query.Substring(0, Query.Length - 4);
            Query += Enums.QueryKeyword.Limit100;
            return Query;
        }
    }
}

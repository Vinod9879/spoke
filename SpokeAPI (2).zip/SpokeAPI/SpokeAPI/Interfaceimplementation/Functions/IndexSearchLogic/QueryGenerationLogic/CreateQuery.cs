﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenerationLogic;
using SpokeAPI.Utils;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenationLogic
{
    public static class CreateQuery
    {
        public static string APNFipsQuery(IndexSearchRequest indexSearchRequest)
        {
            List<SearchQueryParameters> searchQueryParameters = new List<SearchQueryParameters>();
            if(indexSearchRequest?.searchInfo != null)
            foreach (PropertyInfo prop in indexSearchRequest.searchInfo.GetType().GetProperties())
            {
#pragma warning disable
                    if (prop.GetValue(indexSearchRequest?.searchInfo) != null && !string.IsNullOrWhiteSpace(prop?.GetValue(indexSearchRequest?.searchInfo).ToString()))
                {
                    SearchQueryParameters queryGenerationPriority = new SearchQueryParameters();
                    string propertyName = "";
                    foreach (var v in prop.CustomAttributes.Where(x => x.AttributeType.Name == "DisplayAttribute"))
                    {
                        foreach (var m in v.NamedArguments.Where(x => x.MemberName == "Name"))
                        {
                            propertyName = m.TypedValue.Value.ToString();
                            queryGenerationPriority.SearchPropertyDBname = propertyName;
                            queryGenerationPriority.SearchProperty = prop?.Name;
                                if(prop!=null)
                            queryGenerationPriority.SearchPropertyValue = prop?.GetValue(indexSearchRequest?.searchInfo).ToString();
                        }
                    }
#pragma warning restore
                        if (indexSearchRequest?.boolFpsNApnDpidSearch == true && string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.AddressSearch, StringComparison.OrdinalIgnoreCase))
                    {
                        if (Enums.ApnFipsSearchProperties.Select(x => x.Value).Contains(prop?.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            searchQueryParameters.Add(queryGenerationPriority);
                            continue;
                        }
                    }

                    if (indexSearchRequest?.boolFipsFullStreetCityState == true && string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.AddressSearch, StringComparison.OrdinalIgnoreCase))
                    {
                        if (Enums.FipsFullStCityStateSearch_AND_FipsFullStZipSearchPropertiesProperties.Select(x => x.Value).Contains(prop?.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            searchQueryParameters.Add(queryGenerationPriority);
                            continue;
                        }
                    }

                    if (indexSearchRequest?.boolFipsFullStZipCode == true && string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.AddressSearch, StringComparison.OrdinalIgnoreCase))
                    {
                        if (Enums.FipsFullStCityStateSearch_AND_FipsFullStZipSearchPropertiesProperties.Select(x => x.Value).Contains(prop?.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            searchQueryParameters.Add(queryGenerationPriority);
                            continue;
                        }
                    }
                    if (indexSearchRequest?.boolFipsRecordingDateDocumentNumberFileType == true && string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.Document, StringComparison.OrdinalIgnoreCase))
                    {
                        if (Enums.FipsRecordingDateDocumentNumberFileType.Select(x => x.Value).Contains(prop?.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            searchQueryParameters.Add(queryGenerationPriority);
                            continue;
                        }
                    }

                    if (indexSearchRequest?.boolFipsRecordingDateBookNumberPageNumberFileType == true && string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.Document, StringComparison.OrdinalIgnoreCase))
                    {
                        if (Enums.FipsRecordingDateBookNumberPageNumberFileType.Select(x => x.Value).Contains(prop?.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            searchQueryParameters.Add(queryGenerationPriority);
                            continue;
                        }
                    }
                        if ( !string.IsNullOrWhiteSpace(indexSearchRequest?.Search_Type) && indexSearchRequest.Search_Type.Equals(Enums.SearchType.Owner, StringComparison.OrdinalIgnoreCase))
                        {
                            if (Enums.OwnerSearchFileType.Select(x => x.Value).Contains(prop?.Name, StringComparer.OrdinalIgnoreCase))
                            {
                                searchQueryParameters.Add(queryGenerationPriority);
                                continue;
                            }
                        }

                    }

            }
            string Query ="";
            if(indexSearchRequest?.boolFpsNApnDpidSearch == true)
            {
                Query =  APNFipsSearchQuery.ApnFipsSearchQueryLogic(searchQueryParameters, indexSearchRequest);
                return Query;
            }
           
          
          if(indexSearchRequest?.boolFipsFullStreetCityState == true || indexSearchRequest?.boolFipsFullStZipCode == true)
            {
                Query = AddressSearchQueryGeneration.AddressSearchQueryLogic(searchQueryParameters, indexSearchRequest);
                return Query;
            }

            if (indexSearchRequest?.boolFipsRecordingDateDocumentNumberFileType == true)
            {
                Query = DocumentSearchQuery.FipsRecordingDateDocumentNumberFileTypeQueryGenerator(searchQueryParameters, indexSearchRequest);
                return Query;
            }
            if (indexSearchRequest?.boolFipsRecordingDateBookNumberPageNumberFileType == true)
            {
                Query = DocumentSearchQuery.FipsRecordingDateBookNumberPageNumberFileType(searchQueryParameters, indexSearchRequest);
                return Query;
            }
            if (indexSearchRequest?.Search_Type!= null && indexSearchRequest.Search_Type.Equals(Enums.SearchType.Owner,StringComparison.OrdinalIgnoreCase))
            {
                Query = OwnerSearchQuery.OwnerSearchQueryGeneration(searchQueryParameters, indexSearchRequest);
                return Query;
            }
            
            return Query;
        }
    }
}

﻿using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenerationLogic
{
    public static class OwnerSearchQuery
    {
        public static string OwnerSearchQueryGeneration(List<SearchQueryParameters> searchQueryParameters, IndexSearchRequest indexSearchRequest)
        {
            string splittedOwnerQuery="";
            if (!string.IsNullOrWhiteSpace(searchQueryParameters[1].SearchPropertyValue))
            {
             splittedOwnerQuery = CommonMethod.parseOwnername(searchQueryParameters[1].SearchPropertyValue??"")??"";
              
            }
#pragma warning disable
            string query = string.Format(Enums.IndexSearchMessages.OwnerSearchQuery, searchQueryParameters[0].SearchPropertyValue, Enums.DocType.APN_ADDRESS_OWNER, string.Join("','", indexSearchRequest?.FNF_DocType).ToUpper(), splittedOwnerQuery);
#pragma warning restore
            return query;

        }
    }
}

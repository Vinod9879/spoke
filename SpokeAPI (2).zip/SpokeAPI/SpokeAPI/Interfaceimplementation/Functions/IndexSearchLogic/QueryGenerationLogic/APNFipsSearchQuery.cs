﻿using Microsoft.VisualBasic;
using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenerationLogic
{
    public class APNFipsSearchQuery
    {
        public static string ApnFipsSearchQueryLogic(List<SearchQueryParameters> searchQueryParameters, IndexSearchRequest indexSearchRequest)
        {
            string partitionKeyFips_APN = "'"+indexSearchRequest.searchInfo?.FIPS + "_" + "'";

           if( string.IsNullOrWhiteSpace( indexSearchRequest.searchInfo?.APN?.ToUpper()))
                {
                partitionKeyFips_APN = "'" + indexSearchRequest.searchInfo?.FIPS + "_DPID:" + indexSearchRequest.searchInfo?.DPID?.ToUpper() + "'";
            }
           if (string.IsNullOrWhiteSpace(indexSearchRequest.searchInfo?.DPID?.ToUpper()))
            {
                partitionKeyFips_APN = "'" + indexSearchRequest.searchInfo?.FIPS + "_APN:" + indexSearchRequest.searchInfo?.APN?.ToUpper() + "'";
            }
#pragma warning disable
            string? strFNF_DocType = "('" + string.Join("','", indexSearchRequest?.FNF_DocType?.ToList()) + "')";
            strFNF_DocType = strFNF_DocType.ToUpper();
            string Query = Enums.QueryKeyword.selectFrom + Enums.QueryKeyword.where
            + Enums.QueryKeyword.TableAliasC + Enums.QueryKeyword.Dot + Enums.QueryKeyword.PartitionKeyFips_Apn_DPID + Enums.QueryKeyword.equal
            + partitionKeyFips_APN + Enums.QueryKeyword.and
            + Enums.QueryKeyword.TableAliasC + Enums.QueryKeyword.Dot + Enums.QueryKeyword.PartitionKeyFNF_DocType + Enums.QueryKeyword.In
            + strFNF_DocType;
            return Query;
        }
    }
}

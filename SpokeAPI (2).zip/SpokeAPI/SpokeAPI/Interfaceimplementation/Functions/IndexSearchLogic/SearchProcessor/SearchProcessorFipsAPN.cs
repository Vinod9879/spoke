﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor
{
    public class SearchProcessorFipsAPN : IIndexSearchCommonEngine
    {// Fips_Apn Search Engine
        public async Task<(IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?,QuerySearchResult?)> IndexSearchCommonEngine(IndexSearchRequest indexSearchRequest, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            IndexSearchPropertyResponse indexSearchPropertyResponse = new IndexSearchPropertyResponse();
            CosmosClient client = _connection.GetReadCosmosClient();
            Container SearchContainer;
            List<dynamic> items = new List<dynamic>();
            QuerySearchResult querySearchResult = new();
            int intSearch = 0;

            //Get Current version of database and container from config
            indexSearchRequest.Database = DBVersionTranslator.GetCurrentDBVersion(indexSearchRequest.Database, _connection);

            //Order of assignment should be maintained in the same way to get _search appedend to the end of container name
            string searchContainer = DBVersionTranslator.GetCurrentContainerVersion(string.Concat(indexSearchRequest.Container, Enums.AdditionalKeywords.SearchKeywordcontainer), _connection);
            indexSearchRequest.Container = DBVersionTranslator.GetCurrentContainerVersion(indexSearchRequest.Container, _connection);
            List<string>? listFNF_DocType = indexSearchRequest.FNF_DocType?.ToList();
            JObject responsejson = new JObject();
            SearchContainer = client.GetContainer(indexSearchRequest.Database, indexSearchRequest.Container);
            _logger.LogInformation(EnumsLog.IndexSearch.Intiatedthe_Query_in_Propery_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            QueryDefinition queryDefinition = new QueryDefinition(indexSearchRequest.query);
            FeedIterator<dynamic> queryResultSetIterator = SearchContainer.GetItemQueryIterator<dynamic>(queryDefinition);
            var TotalTimeProperyContainerSearch = 0;
            double ProperyRequestCharge = 0.00;
            try
            {
                while (queryResultSetIterator.HasMoreResults)
                {
#pragma warning disable
                    FeedResponse<dynamic> currentResultSet = await queryResultSetIterator.ReadNextAsync();
                    foreach (var item in currentResultSet)
                    {
                        JToken jToken = item[Enums.AdditionalKeywords.FNF_DocType];
                        string? strfNF_DocType = ((JValue)jToken).Value.ToString();
                        if ((bool)(listFNF_DocType?.Contains(strfNF_DocType, StringComparer.OrdinalIgnoreCase)))
                        {
                            intSearch++;
                            JArray nameTokenArray = (JArray)responsejson[strfNF_DocType];
                            if (nameTokenArray == null)
                            {
                                JArray jArray = new JArray();
                                responsejson.Add(strfNF_DocType?.ToUpper(), jArray);
                                nameTokenArray = (JArray)responsejson[strfNF_DocType];
                            }
                            // Append the new object to the JArray
                            nameTokenArray?.Add(item);
                        }
                    }
#pragma warning restore
                    ProperyRequestCharge = ProperyRequestCharge + currentResultSet.RequestCharge;
                    TotalTimeProperyContainerSearch = TotalTimeProperyContainerSearch + currentResultSet.Diagnostics.GetClientElapsedTime().Milliseconds;
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation(EnumsLog.IndexSearch.InternalSeverError, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID, ex.Message);
                if (querySearchResult.TotalTimeProperyContainerRequestCharge != 0)
                    _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest.SubscriptionKey, indexSearchRequest.Search_Type, EnumsLog.ApiType.IndexSearch, indexSearchRequest.Database, indexSearchRequest.Container, querySearchResult.TotalTimeProperyContainerSearch, querySearchResult.TotalTimeProperyContainerRequestCharge, CommonModels.GlobalTransactionID.TransactionID);
                if (querySearchResult.TotalPropertySearchContainerRequestCharge != 0)
                    _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest.SubscriptionKey, indexSearchRequest.Search_Type, EnumsLog.ApiType.IndexSearch, indexSearchRequest.Database, indexSearchRequest.Container + Enums.AdditionalKeywords.SearchKeywordcontainer, querySearchResult.TotalTimePropertySearchContainerSearch, querySearchResult.TotalPropertySearchContainerRequestCharge, CommonModels.GlobalTransactionID.TransactionID);

                return (indexSearchPropertyResponse, null,querySearchResult);
            }

            querySearchResult.TotalTimeProperyContainerSearch = TotalTimeProperyContainerSearch;
            querySearchResult.TotalTimeProperyContainerRequestCharge = ProperyRequestCharge;
            querySearchResult.CountResult = intSearch;
            querySearchResult.JObjectResult = responsejson;
            _logger.LogInformation(EnumsLog.IndexSearch.Endthe_Query_in_Propery_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            if (querySearchResult.TotalTimeProperyContainerRequestCharge != 0)
                _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest.SubscriptionKey, indexSearchRequest.Search_Type, EnumsLog.ApiType.IndexSearch, indexSearchRequest.Database, indexSearchRequest.Container, querySearchResult.TotalTimeProperyContainerSearch, querySearchResult.TotalTimeProperyContainerRequestCharge, CommonModels.GlobalTransactionID.TransactionID);
            if (querySearchResult.TotalPropertySearchContainerRequestCharge != 0)
                _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest.SubscriptionKey, indexSearchRequest.Search_Type, EnumsLog.ApiType.IndexSearch, indexSearchRequest.Database, indexSearchRequest.Container + Enums.AdditionalKeywords.SearchKeywordcontainer, querySearchResult.TotalTimePropertySearchContainerSearch, querySearchResult.TotalPropertySearchContainerRequestCharge, CommonModels.GlobalTransactionID.TransactionID);
             indexSearchPropertyResponse = IndexSearchCommonLogic.propertyContainerSearchRespose(querySearchResult, indexSearchRequest);
            _logger.LogInformation(EnumsLog.IndexSearch.Ended_Property_container_search, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
        
            return (indexSearchPropertyResponse, null, querySearchResult);
        }

      }
}

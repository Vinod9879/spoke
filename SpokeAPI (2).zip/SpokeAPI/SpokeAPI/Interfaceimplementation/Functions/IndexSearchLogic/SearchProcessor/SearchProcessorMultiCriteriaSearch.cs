﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor
{
    public class SearchProcessorMultiCriteriaSearch : IIndexSearchCommonEngine
    {
        //APN_Address/document/Owner search engine for Propery_search container
        public async Task<(IndexSearchModel.IndexSearchPropertyResponse?, IndexSearchModel.IndexSearchPropertySearchResponse?, QuerySearchResult?)> 
            IndexSearchCommonEngine(IndexSearchModel.IndexSearchRequest indexSearchRequest, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            IndexSearchPropertySearchResponse indexSearchPropertySearchResponse = new IndexSearchPropertySearchResponse();
            CosmosClient client = _connection.GetReadCosmosClient();
            Container SearchContainer;
            List<dynamic> items = new List<dynamic>();
            QuerySearchResult querySearchResult = new();
            int intSearch = 0;

            //Get Current version of database and container from config
            indexSearchRequest.Database = DBVersionTranslator.GetCurrentDBVersion(indexSearchRequest.Database, _connection);

            //Order of assignment should be maintained in the same way to get _search appedend to the end of container name
            string searchContainer = DBVersionTranslator.GetCurrentContainerVersion(string.Concat(indexSearchRequest.Container, Enums.AdditionalKeywords.SearchKeywordcontainer), _connection);
            indexSearchRequest.Container = DBVersionTranslator.GetCurrentContainerVersion(indexSearchRequest.Container, _connection);


            var TotalTimeProperySearchContainerSearch = 0;
            var ProperySearchRequestCharge = 0.00;
            SearchContainer = client.GetContainer(indexSearchRequest.Database, searchContainer);
            QueryDefinition queryDefinition = new QueryDefinition(indexSearchRequest.query);
            //Triger Query PropertySearch
            FeedIterator<dynamic> queryResultSetIterator = SearchContainer.GetItemQueryIterator<dynamic>(queryDefinition);
            _logger.LogInformation(EnumsLog.IndexSearch.Intiated_in_Property_Search_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            while (queryResultSetIterator.HasMoreResults)
            {
                FeedResponse<dynamic> currentResultSet = await queryResultSetIterator.ReadNextAsync();
                foreach (var item in currentResultSet)
                {
                    intSearch++;
                    // Convert  to JObject to manipulate dynamic content
                    JObject obj = JObject.FromObject(item);

                    // Remove the unwanted property
                    obj.Property(Enums.FilterField.SplitedOwnerName.ToString())?.Remove();
                    obj.Property(Enums.FilterField.FNF_CustomPartition.ToString())?.Remove();
                    items.Add(obj);
                }
                ProperySearchRequestCharge = ProperySearchRequestCharge + currentResultSet.RequestCharge;
                TotalTimeProperySearchContainerSearch = TotalTimeProperySearchContainerSearch + currentResultSet.Diagnostics.GetClientElapsedTime().Milliseconds;

            }
            _logger.LogInformation(EnumsLog.IndexSearch.Ended_in_Property_Search_container, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            querySearchResult.TotalPropertySearchContainerRequestCharge = ProperySearchRequestCharge;
            querySearchResult.TotalTimePropertySearchContainerSearch = TotalTimeProperySearchContainerSearch;
            querySearchResult.CountResult = intSearch;
            querySearchResult.dynamicListResult = items;
           
            if (items.Count > 1)
            {
               
                _logger.LogInformation(EnumsLog.IndexSearch.Response_picklist_Property_Search_containe_more_result, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                indexSearchPropertySearchResponse.responsePicklist = JsonDocument.Parse(JsonConvert.SerializeObject(querySearchResult.dynamicListResult));
                indexSearchPropertySearchResponse.responseCodeDescription = ResponseCodeDescription.MultipleRecordFound;
                indexSearchPropertySearchResponse.responseCode = ResponseCode.Success;
            }
            else if (items.Count ==1)
            {
              
                indexSearchPropertySearchResponse.responsePicklist = JsonDocument.Parse(JsonConvert.SerializeObject(querySearchResult.dynamicListResult));
                indexSearchPropertySearchResponse.responseCodeDescription = ResponseCodeDescription.Success;
                indexSearchPropertySearchResponse.responseCode = ResponseCode.Success;
            }
            else
            {
                indexSearchPropertySearchResponse.responseCodeDescription = ResponseCodeDescription.RecordNotFound;
                indexSearchPropertySearchResponse.responseCode = ResponseCode.NoResultFound;
            }
                return (null, indexSearchPropertySearchResponse, querySearchResult);
        }
       
        }
    }


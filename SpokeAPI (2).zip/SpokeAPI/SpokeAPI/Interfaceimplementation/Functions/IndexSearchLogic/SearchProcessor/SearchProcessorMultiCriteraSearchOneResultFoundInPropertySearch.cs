﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenationLogic;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor
{
    public class SearchProcessorMultiCriteraSearchOneResultFoundInPropertySearch : IIndexSearchCommonEngine
    {
        //APN_Fips search engine for property table
        public async Task<(IndexSearchModel.IndexSearchPropertyResponse?, IndexSearchModel.IndexSearchPropertySearchResponse?, IndexSearchModel.QuerySearchResult?)> IndexSearchCommonEngine(IndexSearchModel.IndexSearchRequest indexSearchRequest, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            IndexSearch indexSearch = new IndexSearch();
            IndexSearchPropertySearchResponse indexSearchPropertySearchResponse = new IndexSearchPropertySearchResponse();
            (IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?, QuerySearchResult?) fipsAPNResponse = new();
                try
                {
#pragma warning disable
                var root = indexSearchPropertySearchResponse.responsePicklist.RootElement;
                    IndexSearchPropertyResponse indexSearchPropertyResponse = new IndexSearchPropertyResponse();
                    if (root[0].TryGetProperty("Apn", out JsonElement apnElement))
                    {
                        _logger.LogInformation(EnumsLog.IndexSearch.Getting_APN_from_propery_container_search_result, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                        string? apn = root[0].GetProperty("Apn").GetString();
                    if (indexSearchRequest.searchInfo != null)
                        indexSearchRequest.searchInfo.APN = apn;
                        indexSearchRequest.isFipsApnDipdSearch();
                        indexSearchRequest.query = indexSearch.BuildQuery(indexSearchRequest);
                        _logger.LogInformation(EnumsLog.IndexSearch.Created_query, indexSearchRequest.query, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);

                    SearchProcessorFipsAPN searchProcessorFipsAPN = new SearchProcessorFipsAPN();
                  fipsAPNResponse = await searchProcessorFipsAPN.IndexSearchCommonEngine(indexSearchRequest, _connection, _logger);

                        if ( fipsAPNResponse.Item3?.TotalTimeProperyContainerRequestCharge != 0)
                            _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest.SubscriptionKey, indexSearchRequest.Search_Type, EnumsLog.ApiType.IndexSearch, indexSearchRequest.Database, indexSearchRequest.Container, fipsAPNResponse.Item3?.TotalTimeProperyContainerSearch, fipsAPNResponse.Item3?.TotalTimeProperyContainerRequestCharge, CommonModels.GlobalTransactionID.TransactionID);
                  
                    return fipsAPNResponse;
                }

#pragma warning restore
            }
            catch (Exception ex) { _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + indexSearchRequest.SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + CommonModels.GlobalTransactionID.TransactionID); }

            return fipsAPNResponse;
        }
    }
}

﻿using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Serialization.HybridRow;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor
{
    public class SearchProcessorDocumentGetProperty : IIndexSearchDocumentGetPropertyEngine
    {//Document search Engine
        public async Task<(IndexSearchModel.IndexSearchPropertyResponse?, IndexSearchModel.QuerySearchResult?)> IndexSearchDocumentGetPropertyEngine(IndexSearchModel.IndexSearchRequest indexSearchRequest, IndexSearchModel.IndexSearchPropertySearchResponse? indexSearchPropertySearchResponse, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            List<DocumentProperySearchResponse> listdocumentProperySearchResponse = new List<DocumentProperySearchResponse>();
            IndexSearchPropertyResponse indexSearchPropertyResponse = new IndexSearchPropertyResponse();
            if (indexSearchPropertySearchResponse?.responsePicklist != null)
                // Take the list of Propery_search container result and get ID,Fips_Apn ,Fnf_DocType
                foreach (var jsonElement in indexSearchPropertySearchResponse.responsePicklist.RootElement.EnumerateArray())
                {
                    DocumentProperySearchResponse documentProperySearchResponse = new DocumentProperySearchResponse();
                    documentProperySearchResponse.id = jsonElement.GetProperty("id").GetString();
                    documentProperySearchResponse.Fips_APN = jsonElement.GetProperty("Fips_APN").GetString();
                    documentProperySearchResponse.FNF_DocType = jsonElement.GetProperty("FNF_FileType").GetString();
                    listdocumentProperySearchResponse.Add(documentProperySearchResponse);

                }


            Microsoft.Azure.Cosmos.Container PropertyContainer;
            CosmosClient client = _connection.GetReadCosmosClient();
            indexSearchRequest.Container = DBVersionTranslator.GetCurrentContainerVersion(indexSearchRequest.Container, _connection);
            PropertyContainer = client.GetContainer(indexSearchRequest.Database, indexSearchRequest.Container);

            //Use the parallel search for all the Hit the Db at a time
            QuerySearchResult querySearchResult = new();
            var TotalTimeProperyContainerSearch = 0;
            var ProperyRequestCharge = 0.00;
            List<dynamic> result = new List<dynamic>();
            if (listdocumentProperySearchResponse.Count > 0)
            {
                foreach (var z in listdocumentProperySearchResponse)
                {
                    try
                    {
                        PartitionKey partitionKey = new PartitionKeyBuilder().Add(z.Fips_APN).Add(z.FNF_DocType).Build();
                        ItemResponse<ExpandoObject> response = await PropertyContainer.ReadItemAsync<ExpandoObject>(z.id, partitionKey);
                        result.Add(response.Resource);
                        TotalTimeProperyContainerSearch = TotalTimeProperyContainerSearch + response.Diagnostics.GetClientElapsedTime().Milliseconds;
                        ProperyRequestCharge = ProperyRequestCharge + double.Parse(response.RequestCharge.ToString());
                    }
                    catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        _logger.LogInformation(EnumsLog.IndexSearch.Resultnotfound, System.Net.HttpStatusCode.NotFound, "Fips_Apn:"+ z.Fips_APN + " FNF_DocType: " + z.FNF_DocType + " ID:" + z.id,
                     indexSearchRequest.SubscriptionKey,CommonModels.GlobalTransactionID.TransactionID);
                    }
                }
                if (ProperyRequestCharge != 0.0)
                    _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails,
                    "SubscriptionKey", "", EnumsLog.ApiType.PointedLookup, indexSearchRequest.Database, indexSearchRequest.Container, TotalTimeProperyContainerSearch, ProperyRequestCharge, CommonModels.GlobalTransactionID.TransactionID);

                querySearchResult.TotalPropertySearchContainerRequestCharge = ProperyRequestCharge;
                querySearchResult.TotalTimePropertySearchContainerSearch = TotalTimeProperyContainerSearch;
                querySearchResult.CountResult = result.Count;
                if (result.Count == 0)
                {
                    return (NotFoundResponse(indexSearchPropertyResponse), null);
                }

                indexSearchPropertyResponse.responseJson = JsonDocument.Parse(JsonConvert.SerializeObject(result));
                indexSearchPropertyResponse.responseCodeDescription = ResponseCodeDescription.Success;
                indexSearchPropertyResponse.responseCode = ResponseCode.Success;
                return (indexSearchPropertyResponse, null);
            }
            else
            {
                return (NotFoundResponse(indexSearchPropertyResponse), null);
            }
        }
        public IndexSearchPropertyResponse NotFoundResponse(IndexSearchPropertyResponse indexSearchPropertyResponse)
        {
            indexSearchPropertyResponse.responseCodeDescription = ResponseCodeDescription.RecordNotFound;
            indexSearchPropertyResponse.responseCode = ResponseCode.NoResultFound;
            indexSearchPropertyResponse.responseJson = JsonDocument.Parse(JsonConvert.SerializeObject("{}"));
            return indexSearchPropertyResponse;

        }

    }

}

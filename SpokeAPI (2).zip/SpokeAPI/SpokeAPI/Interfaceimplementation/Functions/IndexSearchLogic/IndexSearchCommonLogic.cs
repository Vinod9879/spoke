﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenationLogic;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using SpokeAPI.Validations;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic
{
    public static class IndexSearchCommonLogic
    {
        public static IndexSearchPropertyResponse propertyContainerSearchRespose(QuerySearchResult SearchResult, IndexSearchRequest indexSearchRequest)
        {
            IndexSearchPropertyResponse indexSearchResponse = new IndexSearchPropertyResponse();
            if (SearchResult.CountResult == 1)
            {
                indexSearchResponse.responseCodeDescription = ResponseCodeDescription.Success;
                indexSearchResponse.responseCode = ResponseCode.Success;
            }
            else if (SearchResult.CountResult > 1)
            {
                indexSearchResponse.responseCodeDescription = ResponseCodeDescription.Success;
                indexSearchResponse.responseCode = ResponseCode.Success;
            }
            else
            {
                indexSearchResponse.responseCodeDescription = ResponseCodeDescription.RecordNotFound;
                indexSearchResponse.responseCode = ResponseCode.NoResultFound;
            }
            indexSearchResponse.responseJson = JsonDocument.Parse(JsonConvert.SerializeObject(SearchResult.JObjectResult));
            indexSearchResponse.searchInfo = indexSearchRequest.searchInfo;
            return indexSearchResponse;
        }

        public static IndexSearchRequest SetIndexSearchRequestOneProperySearchResult((IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?, QuerySearchResult?) fipsMultiCriteriaResponse, IndexSearchPropertySearchResponse indexSearchPropertySearchResponse, IndexSearchRequest indexSearchRequest, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            indexSearchPropertySearchResponse.responsePicklist = JsonDocument.Parse(JsonConvert.SerializeObject(fipsMultiCriteriaResponse.Item3?.dynamicListResult));
            _logger.LogInformation(EnumsLog.IndexSearch.Intitiate_in_Property_Search_container_count_is_1, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            indexSearchPropertySearchResponse.responseCodeDescription = ResponseCode.Success;
            indexSearchPropertySearchResponse.responseCode = ResponseCode.Success;
            try
            {
                var root = indexSearchPropertySearchResponse.responsePicklist.RootElement;
                IndexSearchPropertyResponse indexSearchPropertyResponse = new IndexSearchPropertyResponse();
                if (root[0].TryGetProperty("Apn", out JsonElement apnElement))
                {
                    _logger.LogInformation(EnumsLog.IndexSearch.Getting_APN_from_propery_container_search_result, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    string? apn = root[0].GetProperty("Apn").GetString();
                    if (indexSearchRequest.searchInfo != null) 
                    indexSearchRequest.searchInfo.APN = apn;
                    if ((string.IsNullOrWhiteSpace(apn))) {
                        if (root[0].TryGetProperty("DPID", out JsonElement DPIDapnElement))
                            {
                            _logger.LogInformation(EnumsLog.IndexSearch.Getting_DPID_from_propery_container_search_result, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                        string? dPID     = root[0].GetProperty("DPID").GetString();
                            if (indexSearchRequest.searchInfo != null)
                                indexSearchRequest.searchInfo.DPID = dPID;
                        }
                    }
                    indexSearchRequest.isFipsApnDipdSearch();
                    indexSearchRequest.query = CreateQuery.APNFipsQuery(indexSearchRequest);
                    _logger.LogInformation(EnumsLog.IndexSearch.Created_query, indexSearchRequest.query, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest.SubscriptionKey, indexSearchRequest.Search_Type, EnumsLog.ApiType.IndexSearch, indexSearchRequest.Database, indexSearchRequest.Container, fipsMultiCriteriaResponse.Item3?.TotalTimeProperyContainerSearch, fipsMultiCriteriaResponse.Item3?.TotalTimeProperyContainerRequestCharge, CommonModels.GlobalTransactionID.TransactionID);
                }
                           }
            catch (Exception ex) { _logger.LogError(HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + indexSearchRequest.SubscriptionKey + Enums.QueryKeyword.Space + ex.ToString() + CommonModels.GlobalTransactionID.TransactionID); }

            return indexSearchRequest;
        }


        public static async Task<(IndexSearchRequest?, bool)> ReadIndexSearchRequestAsync(IndexSearchRequest? indexSearchRequest, HttpRequest req, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            IndexSearchValidationResponse _indexSearchIsvalidJson = new();
            bool isvalidJson = true;
            try
            {

                isvalidJson = ValidationQueryAPI.IsvalidJson(requestBody, null);
                if (!isvalidJson)
                {

                    _logger.LogError("SubscriptionId = " + req.Headers["SubscriptionKey"].ToString() + " " + Enums.ManageSubscriptionMessages.InputBodyNotValid + " " + CommonModels.GlobalTransactionID.TransactionID);
                    _indexSearchIsvalidJson.Create(ResponseCode.MalformedRequest, ResponseCodeDescription.MalformedRequest, Enums.IndexSearchMessages.InputBodyNotValid ?? " ");
                    return (indexSearchRequest, isvalidJson);
                }
                indexSearchRequest = JsonConvert.DeserializeObject<IndexSearchRequest>(requestBody);
                if (indexSearchRequest != null)
                {
                    indexSearchRequest.Database = req.RouteValues?.Where(x => x.Key == Enums.HttpRequestUrlParameters.Database).Select(x => x.Value).FirstOrDefault()?.ToString();
                    indexSearchRequest.Container = req.RouteValues?.Where(x => x.Key == Enums.HttpRequestUrlParameters.Container).Select(x => x.Value).FirstOrDefault()?.ToString();
                    indexSearchRequest.SubscriptionKey = req.Headers["SubscriptionKey"].ToString();
                    indexSearchRequest.ClientId = req.Headers["ClientId"].ToString();
                    indexSearchRequest.TransactionId = CommonModels.GlobalTransactionID.TransactionID;
                    if (indexSearchRequest.Match_Type == null)
                    {
                        indexSearchRequest.Match_Type = Enums.MatchType.Exact.ToString();
                    }
                    if ( !string.IsNullOrWhiteSpace(indexSearchRequest.Search_Type) && indexSearchRequest.Search_Type.Equals(Enums.SearchType.Owner, StringComparison.OrdinalIgnoreCase)   )
                    {
                        List<string> FNF_DocType = new List<string>();
                        if (indexSearchRequest.FNF_DocType == null || (indexSearchRequest.FNF_DocType.Count ==1 && indexSearchRequest.FNF_DocType.Any(x => x.Equals(Enums.FnfDocType.ASMT.ToString(), StringComparison.OrdinalIgnoreCase))))
                        {
                            FNF_DocType.Add(Enums.FnfDocType.ASMT.ToString());
                            indexSearchRequest.FNF_DocType = FNF_DocType;
                        }
                        else if(indexSearchRequest.FNF_DocType.Count>1 || !indexSearchRequest.FNF_DocType.Any(x=>x.Equals(Enums.FnfDocType.ASMT.ToString(),StringComparison.OrdinalIgnoreCase)))
                            {
                            FNF_DocType.Add(Enums.FnfDocType.Invalid.ToString());
                            indexSearchRequest.FNF_DocType = FNF_DocType;
                        }
                    }

                    _logger.LogInformation(EnumsLog.General.Readbodyissuccessfull, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation(EnumsLog.General.FailedtoReadtheBody, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                _logger.LogInformation(EnumsLog.IndexSearch.InternalSeverError, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID, ex.Message.ToString());
                throw;
            }
            return (indexSearchRequest, isvalidJson);

        }


        public static async Task<FunctionValidation> ValidationAsync(IndexSearchRequest? indexSearchRequest, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            _logger.LogInformation(EnumsLog.General.Validating_user_input, indexSearchRequest?.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            FunctionValidation functionValidation = await ValidationIndexSearch.ValidateIndexSearchInput(indexSearchRequest, _connection, _logger);
            if (functionValidation.TotalRequestChargeCheckAccess != 0.00)
                _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, indexSearchRequest?.SubscriptionKey, indexSearchRequest?.Search_Type, EnumsLog.ApiType.IndexSearch, _connection.SubscriptionDatabase, _connection.SubscriptionContainer, functionValidation.TotalTimeCheckAccess, functionValidation.TotalRequestChargeCheckAccess, CommonModels.GlobalTransactionID.TransactionID);
            if (functionValidation.Message != null && functionValidation.Success == false)
            {
                _logger.LogInformation(EnumsLog.General.Validation_failed, indexSearchRequest?.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            }
            _logger.LogInformation(EnumsLog.General.Validation_success, indexSearchRequest?.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            return functionValidation;
        }
    }
}

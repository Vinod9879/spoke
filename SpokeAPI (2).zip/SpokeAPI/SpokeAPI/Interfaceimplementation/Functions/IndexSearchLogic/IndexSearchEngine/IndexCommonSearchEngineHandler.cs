﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenationLogic;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.IndexSearchEngine
{
    public class IndexCommonSearchEngineHandler : IIndexSearchEngineHandler
    {
        // This is request Handler based on the APN_Search/Document and Diffrent combination
        // request  redirected to respective search engine.
        // Interface IIndexSearchCommonEngine and method IndexSearchCommonEngine implimented for all Search engine  


        public async Task<dynamic?> IndexSearchEngineHandler(IndexSearchModel.IndexSearchRequest? indexSearchRequest, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            IndexSearchPropertySearchResponse indexSearchPropertySearchResponse = new IndexSearchPropertySearchResponse();
             CosmosClient client = _connection.GetReadCosmosClient();

            //APN_Address with  FIPS APN combination. Search Direct Property container Fetch and return the result
            if (indexSearchRequest?.boolFpsNApnDpidSearch == true)
            {
                SearchProcessorFipsAPN searchProcessorFipsAPN = new SearchProcessorFipsAPN();
                (IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?, QuerySearchResult?) fipsAPNResponse = 
                    await searchProcessorFipsAPN.IndexSearchCommonEngine(indexSearchRequest, _connection, _logger);
                if (fipsAPNResponse.Item1 != null) return fipsAPNResponse.Item1;
            }

            // Fetch Property_Search Container  APN_Address(Address/Zip/Sate/city etc) /  Document(DocumentNumber/Booknumber/Pagenumber etc) Combinations
            if (indexSearchRequest?.Search_Type!= null && indexSearchRequest.Search_Type.Equals(Enums.SearchType.Owner,StringComparison.OrdinalIgnoreCase) || indexSearchRequest?.boolFipsFullStreetCityState == true || indexSearchRequest?.boolFipsFullStZipCode == true || string.Equals(indexSearchRequest?.Search_Type,Enums.SearchType.Document,StringComparison.OrdinalIgnoreCase))
            {

                //Trigger the Generated query on Propery_Search Container APN_Address/Document/Owner
                SearchProcessorMultiCriteriaSearch SearchProcessorMultiCriteriaSearch = new SearchProcessorMultiCriteriaSearch();
                (IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?, QuerySearchResult?) fipsMultiCriteriaResponse
#pragma warning disable
                    = await SearchProcessorMultiCriteriaSearch.IndexSearchCommonEngine(indexSearchRequest, _connection, _logger);
#pragma warning restore

                //Return if null result

                if (fipsMultiCriteriaResponse.Item2?.responsePicklist == null)
                {
                    return fipsMultiCriteriaResponse.Item2;
                }

                // Return Document/Owner SearchResult It may be single or multiple record from Propery_Search container

                if (string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.Document,StringComparison.OrdinalIgnoreCase)|| string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.Owner, StringComparison.OrdinalIgnoreCase))
                {
                    return fipsMultiCriteriaResponse.Item2;
                }

                //Return APN_Address Multiple APN found in Propery_Search container

                if (fipsMultiCriteriaResponse.Item3 != null && fipsMultiCriteriaResponse.Item3.CountResult > 1)
                {
                    if (fipsMultiCriteriaResponse.Item2 != null) return fipsMultiCriteriaResponse.Item2;
                }

                //APN_Address search in case 1 result found

                if (fipsMultiCriteriaResponse.Item3 != null && fipsMultiCriteriaResponse.Item3.CountResult == 1)
                {
                    //Get the  APN number from the 1 result found in Propery_Search
                    if(fipsMultiCriteriaResponse.Item2 != null)
                    indexSearchPropertySearchResponse = fipsMultiCriteriaResponse.Item2;
                    indexSearchRequest = IndexSearchCommonLogic.SetIndexSearchRequestOneProperySearchResult(fipsMultiCriteriaResponse, indexSearchPropertySearchResponse, indexSearchRequest, _logger);

                    //Get data from the Propery container using FIps APN etc.

                    SearchProcessorFipsAPN searchProcessorFipsAPN = new SearchProcessorFipsAPN();
                    (IndexSearchPropertyResponse?, IndexSearchPropertySearchResponse?, QuerySearchResult?) fipsAPNResponse = 
                        await searchProcessorFipsAPN.IndexSearchCommonEngine(indexSearchRequest, _connection, _logger);
                    if (fipsAPNResponse.Item1 != null)
                        return fipsAPNResponse.Item1;
                }


            }
            return indexSearchPropertySearchResponse;
        }
  
    }
}

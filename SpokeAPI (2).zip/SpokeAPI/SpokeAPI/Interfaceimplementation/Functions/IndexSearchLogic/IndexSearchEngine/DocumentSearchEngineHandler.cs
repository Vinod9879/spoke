﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.IndexSearchEngine
{
    public class DocumentSearchEngineHandler : IDocumentProperytSearchHandler
    {
        //Document search handler for property container search

        public async Task<IndexSearchPropertyResponse> IndexSearchDocumentEngine(IndexSearchRequest indexSearchRequest, IndexSearchPropertySearchResponse? indexSearchPropertySearchResponse, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            SearchProcessorDocumentGetProperty SearchProcessorDocumentGetProperty = new SearchProcessorDocumentGetProperty();
            (IndexSearchModel.IndexSearchPropertyResponse?, IndexSearchModel.QuerySearchResult?) FuncProcessorDocumentGetProperty = new ();
            FuncProcessorDocumentGetProperty =
                await SearchProcessorDocumentGetProperty.IndexSearchDocumentGetPropertyEngine(indexSearchRequest, indexSearchPropertySearchResponse, _connection, _logger);
            //Get Propery Document data from 
#pragma warning disable
            return FuncProcessorDocumentGetProperty.Item1;
#pragma warning restore


        }
    }
}

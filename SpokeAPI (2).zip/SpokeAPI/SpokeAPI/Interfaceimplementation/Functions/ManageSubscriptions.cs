﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using Microsoft.Extensions.Logging;
using SpokeAPI.Functions;
using System.Text.Json;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Utils.Enums;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Validations;

namespace SpokeAPI.Interfaceimplementation.Functions
{
    public class ManageSubscriptions : IManageSubscriptions
    {
        public async Task<dynamic> UpsertSubscription(HttpRequest req,IConnection _connection, ILogger<ManageSubscription>  _logger)
        {
           
            _logger.LogInformation(EnumsLog.ManageSubscription.Started_UpsertSubscription_Method, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
            string? TransactinID = GlobalTransactionID.TransactionID;
            CosmosClient client = _connection.GetReadWriteCosmosClient();
            Container subscriptionContainer = client.GetContainer(_connection.SubscriptionDatabase, _connection.SubscriptionContainer);
            ManageSubscriptionRequest manageSubscriptionRequest = new();
            FunctionResponse _functionResponse = new();
            FunctionValidation? manageSubscriptionValidation = new();
            string _caller_subscriptionKey = req.Headers["SubscriptionKey"].ToString();
            string _caller_clientId = req.Headers["ClientId"].ToString();
            try
            {
                _logger.LogInformation(EnumsLog.General.Validating_user_input, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                try
                {
                  bool isvalidJson =  ValidationQueryAPI.IsvalidJson(requestBody,null);
                    if (!isvalidJson) {
                        _logger.LogError("SubscriptionId = " + _caller_subscriptionKey + " " + Enums.ManageSubscriptionMessages.InputBodyNotValid + " " + CommonModels.GlobalTransactionID.TransactionID);
                        return new BadRequestObjectResult(_functionResponse.Create(Enums.ResponseCode.MalformedRequest, Enums.ResponseCodeDescription.MalformedRequest, Enums.ManageSubscriptionMessages.InputBodyNotValid));

                    }
#pragma warning disable
                    manageSubscriptionRequest = JsonConvert.DeserializeObject<ManageSubscriptionRequest>(requestBody);
#pragma warning restore
                    if (manageSubscriptionRequest == null)
                    {
                        _logger.LogError("SubscriptionId = " + _caller_subscriptionKey + " "+ Enums.ManageSubscriptionMessages.InputBodyNotValid +" " + CommonModels.GlobalTransactionID.TransactionID);
                        return new BadRequestObjectResult(_functionResponse.Create(Enums.ResponseCode.MalformedRequest, Enums.ResponseCodeDescription.MalformedRequest, Enums.ManageSubscriptionMessages.InputBodyNotValid));

                    }
                }
                catch( Exception ex)
                {
                    _logger.LogError("SubscriptionId = " + _caller_subscriptionKey + ex.ToString() + " "+ CommonModels.GlobalTransactionID.TransactionID);
                    return new ObjectResult(CommonMethod.ManageSubscriptionException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID??"", Enums.ResponseCodeDescription.ValidationError, Enums.ResponseCode.ValidationError,Enums.ManageSubscriptionMessages.InputBodyNotValid))
                    {
                        StatusCode = 400
                    };
                }
                manageSubscriptionRequest.TransactionID = TransactinID;
                manageSubscriptionValidation = SpokeAPI.Validations.ValidationManageSubscription.Validateinput(manageSubscriptionRequest, requestBody,_connection, _logger);
                if (manageSubscriptionValidation.Message != null && manageSubscriptionValidation.Success == false)
                {
                    _logger.LogInformation(EnumsLog.General.Validation_failed, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(_functionResponse.Create(manageSubscriptionValidation.ResponseCode??"", codedescription: manageSubscriptionValidation.ResponseCodeDescription??"", manageSubscriptionValidation.Message.ToString()))
                    {
                        StatusCode = 400
                    };
                }
               
                _logger.LogInformation(EnumsLog.General.Validation_success, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
            }
            catch (Exception ex)
            {
                _logger.LogError("SubscriptionId = "+ _caller_subscriptionKey + ex.ToString(), CommonModels.GlobalTransactionID.TransactionID);
                return new ObjectResult(CommonMethod.ManageSubscriptionException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID ?? "", Enums.ResponseCodeDescription.InternalServerError, Enums.ResponseCode.InternalServerError,GeneralMessages.InternalErrorOccurredPleasecontactSupport))
                {
                    StatusCode = 500
                };
            }
            Microsoft.Azure.Cosmos.PartitionKey partitionKeys = new Microsoft.Azure.Cosmos.PartitionKey(manageSubscriptionRequest.SubscriptionId);

            bool isInsert = false;
            try
            {
                 
                JsonDocument dynamic = await GetItemPointedSearch.ReadItemAsync(subscriptionContainer, manageSubscriptionRequest.Clientid + "_" + manageSubscriptionRequest.FNF_DocType, manageSubscriptionRequest.SubscriptionId ?? "", manageSubscriptionRequest, manageSubscriptionValidation,_connection, _logger, TransactinID??"");
                CommonModels.GlobalTransactionID.TransactionID = TransactinID;
                Models.ManageSubscriptionsModels? manageSubscriptions = JsonConvert.DeserializeObject<Models.ManageSubscriptionsModels>(System.Text.Json.JsonSerializer.Serialize(dynamic));
               if (manageSubscriptions != null && manageSubscriptions.IsEnabled == true && manageSubscriptionRequest.IsEnabled == true)
                {
                    _logger.LogInformation(EnumsLog.ManageSubscription.No_change_in_upsert_operation, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(_functionResponse.Create(Enums.ResponseCode.SubscriptionKeyNotConfigured, codedescription: Enums.ResponseCodeDescription.SubscriptionKeyNotConfigured.ToString(), msg: Enums.ManageSubscriptionMessages.ProvidedSubscriptionConfigurationisalreadyenabled)) { StatusCode = 200 }; 
                }
                if (manageSubscriptions != null && manageSubscriptions.IsEnabled == false && manageSubscriptionRequest.IsEnabled == false)
                {
                    _logger.LogInformation( EnumsLog.ManageSubscription.No_change_in_upsert_operation, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(_functionResponse.Create(code: Enums.ResponseCode.SubscriptionKeyNotConfigured, codedescription: Enums.ResponseCodeDescription.SubscriptionKeyNotConfigured.ToString(), msg: Enums.ManageSubscriptionMessages.ProvidedSubscriptionConfigurationisalreadydisabled)) { StatusCode = 200 };
                }
#pragma warning disable
                manageSubscriptions.IsEnabled = manageSubscriptionRequest.IsEnabled;
#pragma warning restore
                manageSubscriptions.AuditHistory?.Add(new AuditHistory
                {
                    LastModifiedDate = DateTime.UtcNow,
                    IsEnabled = manageSubscriptionRequest.IsEnabled,
                    UpdatedByClientId = _caller_clientId,
                    UpdatedBySubscriptionId = _caller_subscriptionKey
                });
                if (manageSubscriptions.AuditHistory?.Count > 10)
                {
                    manageSubscriptions.AuditHistory = manageSubscriptions.AuditHistory.OrderByDescending(x => x.LastModifiedDate).Take(10).ToList();
                }
                _logger.LogInformation(EnumsLog.ManageSubscription.Write_audit_history, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                ItemResponse<ManageSubscriptionsModels> responses  = await subscriptionContainer.UpsertItemAsync(manageSubscriptions);
                _logger.LogInformation(EnumsLog.ManageSubscription.Update_is_succes, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                return new OkObjectResult(_functionResponse.Create(Enums.ResponseCode.Success, codedescription: Enums.ResponseCodeDescription.Success.ToString(), msg: Enums.ManageSubscriptionMessages.SubscriptionConfigupdatedsuccessfully));
            }
            catch(Exception ex)
            {
                ex.ToString();
                if (ex.Message.Contains("404"))
                {
                    _logger.LogInformation( EnumsLog.ManageSubscription.Existing_Subscription_not_found, _caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    isInsert = true;
                }
                else if(ex.Message.Contains("503"))
                {
                    _logger.LogError(EnumsLog.ManageSubscription.Service_not_found_Please_check_service_client_and_container,_caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                }
                else
                    _logger.LogError(Enums.HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + _caller_subscriptionKey + ex.ToString()+ CommonModels.GlobalTransactionID.TransactionID);
                
            }
            if (isInsert == true)
            {
                try
                {
                    Models.ManageSubscriptionsModels subscriptions = new Models.ManageSubscriptionsModels();
                    subscriptions.SubscriptionId = manageSubscriptionRequest.SubscriptionId;
                    subscriptions.SubscriptionName = manageSubscriptionRequest.SubscriptionName;
                    subscriptions.ClientId = manageSubscriptionRequest.Clientid;
                    subscriptions.Database = manageSubscriptionRequest.Database;
                    subscriptions.Container = manageSubscriptionRequest.Container;
                    subscriptions.FNF_DocType = manageSubscriptionRequest.FNF_DocType;
                    subscriptions.id = manageSubscriptionRequest.Clientid + "_" + manageSubscriptionRequest.FNF_DocType;
                    subscriptions.IsEnabled = manageSubscriptionRequest.IsEnabled;
                    List<AuditHistory> listAauditHistory = new List<AuditHistory>();
                    AuditHistory auditHistory = new AuditHistory();
                    auditHistory.LastModifiedDate = DateTime.UtcNow;
                    auditHistory.IsEnabled = manageSubscriptionRequest.IsEnabled;
                    auditHistory.UpdatedByClientId = _caller_clientId;
                    auditHistory.UpdatedBySubscriptionId = _caller_subscriptionKey;
                    listAauditHistory.Add(auditHistory);
                    subscriptions.AuditHistory = listAauditHistory;
                    await subscriptionContainer.UpsertItemAsync(subscriptions);
                    _logger.LogInformation(EnumsLog.ManageSubscription.Insert_is_successful,_caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    return new OkObjectResult(_functionResponse.Create(code: Enums.ResponseCode.Success, codedescription: Enums.ResponseCodeDescription.Success, msg: Enums.ManageSubscriptionMessages.SubscriptionConfigCreatedsuccessfully));
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("1003"))
                    {
                        _logger.LogInformation(EnumsLog.General.ResourcesContainer_not_found,_caller_subscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    }
                    return new ObjectResult(CommonMethod.ManageSubscriptionException(_logger, ex, req.Headers["SubscriptionKey"].ToString(),  CommonModels.GlobalTransactionID.TransactionID ?? "", ResponseCode.InternalServerError, ResponseCodeDescription.InternalServerError,GeneralMessages.InternalErrorOccurredPleasecontactSupport))
                    { StatusCode = 500 };
                }

            }
            return false;

        }

      
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Cosmos;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Models.QueryAPIModel;

namespace SpokeAPI.Interfaceimplementation.Functions.PointedLookupLogic
{
    public static class OrderPartitionKey
    {
        public static PointedLookupRequest  OrderPartitionKeyLogic(Dictionary<string, string>? reqParameter,HttpRequest? req, IConnection connection)
        {
            List<CosmosDBConfig>? _cosmosDBConfig = connection.Getcosmosdb_config();
            PointedLookupRequest? pointedLookupRequest = new();
            pointedLookupRequest.Database = req?.RouteValues?.Where(x => x.Key == Enums.HttpRequestUrlParameters.Database)?.Select(x => x.Value)?.FirstOrDefault()?.ToString()?.ToLower();
            pointedLookupRequest.Container = req?.RouteValues?.Where(x => x.Key == Enums.HttpRequestUrlParameters.Container)?.Select(x => x.Value)?.FirstOrDefault()?.ToString()?.ToLower();
#pragma warning disable
            IEnumerable<List<string>> cosmosDBConfig = _cosmosDBConfig?.Where(a => string.Equals(a.database, pointedLookupRequest?.Database) && string.Equals(a.container, pointedLookupRequest?.Container) ).Select(x=>x.query_params);
#pragma warning restore
            pointedLookupRequest.IDKey = cosmosDBConfig?.FirstOrDefault()?.Skip(0).FirstOrDefault();
            pointedLookupRequest.IDValue = reqParameter?.Where(x => x.Key == pointedLookupRequest.IDKey).Select(x => x.Value).FirstOrDefault()?.ToString();
            pointedLookupRequest.PartionKey1 = cosmosDBConfig?.FirstOrDefault()?.Skip(1).FirstOrDefault();
            pointedLookupRequest.PartionKey1Value = reqParameter?.Where(x => x.Key == pointedLookupRequest.PartionKey1).Select(x => x.Value).FirstOrDefault()?.ToString();
            pointedLookupRequest.PartionKey2 = cosmosDBConfig?.FirstOrDefault()?.Skip(2).FirstOrDefault();
            pointedLookupRequest.PartionKey2Value = reqParameter?.Where(x => x.Key == pointedLookupRequest.PartionKey2).Select(x => x.Value).FirstOrDefault()?.ToString();
            pointedLookupRequest.PartionKey3 = cosmosDBConfig?.FirstOrDefault()?.Skip(3).FirstOrDefault();
            pointedLookupRequest.PartionKey3Value = reqParameter?.Where(x => x.Key == pointedLookupRequest.PartionKey3).Select(x => x.Value).FirstOrDefault()?.ToString();
            pointedLookupRequest.SubscriptionKey = req?.Headers[Enums.HttpRequestUrlParameters.SubscriptionKey].ToString();
            pointedLookupRequest.ClientId = req?.Headers[Enums.HttpRequestUrlParameters.ClientId].ToString();
            pointedLookupRequest.Req = req;
            pointedLookupRequest.FNF_DocType = req?.Query.Where(x => string.Equals(x.Key, Enums.AdditionalKeywords.FNF_DocType, StringComparison.OrdinalIgnoreCase)).Select(x => x.Value).FirstOrDefault();
            if (pointedLookupRequest.PartionKey1Value != null && pointedLookupRequest.PartionKey2Value == null)
            {
                pointedLookupRequest.NumberofPartitionKey = 1;
                pointedLookupRequest.PartitionKey = new PartitionKey(pointedLookupRequest.PartionKey1Value);
            }
            if (pointedLookupRequest.PartionKey1Value != null && pointedLookupRequest.PartionKey2Value != null && pointedLookupRequest.PartionKey3Value == null)
            {
                pointedLookupRequest.NumberofPartitionKey = 2;
                pointedLookupRequest.PartitionKey = new PartitionKeyBuilder().Add(pointedLookupRequest.PartionKey1Value).Add(pointedLookupRequest.PartionKey2Value).Build();
            }
            if (pointedLookupRequest.PartionKey1Value != null && pointedLookupRequest.PartionKey2Value != null && pointedLookupRequest.PartionKey3Value != null)
            {
                pointedLookupRequest.NumberofPartitionKey = 3;
                pointedLookupRequest.PartitionKey = new PartitionKeyBuilder().Add(pointedLookupRequest.PartionKey1Value).Add(pointedLookupRequest.PartionKey2Value).Add(pointedLookupRequest.PartionKey3Value).Build();
            }
            return pointedLookupRequest;
        }
    }
}

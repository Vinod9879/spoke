﻿using Microsoft.AspNetCore.Http;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interfaceimplementation.Functions.PointedLookupLogic;
using SpokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Models.QueryAPIModel;

namespace SpokeAPI.Interfaceimplementation.Functions.QueryAPILogic
{
    public static class OrderPartitionKeyQueryAPI
    {
        public static ParseQueryAPIRequest? FuncOrderPartitionKeyQueryAPI(HttpRequest req , ParseQueryAPIRequest? parseQueryAPIRequest, List<ConfigPartitionKeys>? _configPartitionKeys, IConnection connection)
        {
           
            PointedLookupRequest pointedLookupRequest = OrderPartitionKey.OrderPartitionKeyLogic(parseQueryAPIRequest?.queryAPIRequest?.QueryParameter, req , connection);
            if (parseQueryAPIRequest?.queryAPIRequest != null)
            {
                parseQueryAPIRequest.queryAPIRequest.IDKey = pointedLookupRequest.IDKey;
                parseQueryAPIRequest.queryAPIRequest.PartionKey1 = pointedLookupRequest.PartionKey1;
                parseQueryAPIRequest.queryAPIRequest.PartionKey2 = pointedLookupRequest.PartionKey2;
                parseQueryAPIRequest.queryAPIRequest.PartionKey3 = pointedLookupRequest.PartionKey3;
#pragma warning disable
                parseQueryAPIRequest.queryAPIRequest.PartitionKeys = _configPartitionKeys?.Where(a => a.database?.ToLower() == pointedLookupRequest?.Database?.ToLower() && a.container?.ToLower() == pointedLookupRequest?.Container.ToLower()).Select(x => x.query_params);
#pragma warning restore
            }
            return parseQueryAPIRequest;
        }
    }
}

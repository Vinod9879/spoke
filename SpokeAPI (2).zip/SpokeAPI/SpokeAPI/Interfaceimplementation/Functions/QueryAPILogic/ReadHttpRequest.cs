﻿using Microsoft.AspNetCore.Http;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using SpokeAPI.Validations;
using System.Reflection.Metadata.Ecma335;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Models.QueryAPIModel;

namespace SpokeAPI.Interfaceimplementation.Functions.QueryAPILogic
{
    public static class ReadHttpRequest
    {
        public static async Task<ParseQueryAPIRequest> ParseHttpRequestAsync(HttpRequest req , IConnection connection)
        {
            ParseQueryAPIRequest? parseQueryAPIRequest = new ();
            QueryAPIRequest queryAPIRequest = new();
            try
            {
               
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                parseQueryAPIRequest.functionValidation = ValidationQueryAPI.ValidateQueryAPI(requestBody);
                if (parseQueryAPIRequest.functionValidation?.Success == false)
                {
                    return parseQueryAPIRequest;
                }
               
                parseQueryAPIRequest.queryAPIRequest = System.Text.Json.JsonSerializer.Deserialize<QueryAPIRequest>(requestBody);
                if (parseQueryAPIRequest.queryAPIRequest != null)
                {
                parseQueryAPIRequest.queryAPIRequest.RequestBody=requestBody; 
                parseQueryAPIRequest.queryAPIRequest.query = GetJsonElement(requestBody,Enums.HttpRequestUrlParameters.JsonQuery);
                parseQueryAPIRequest.queryAPIRequest.Database = req.RouteValues?.Where(x => x.Key == Enums.HttpRequestUrlParameters.Database).Select(x => x.Value).FirstOrDefault()?.ToString();
                parseQueryAPIRequest.queryAPIRequest.Container = req.RouteValues?.Where(static x => x.Key == Enums.HttpRequestUrlParameters.Container).Select(x => x.Value).FirstOrDefault()?.ToString();
                    Dictionary<string, string> reqQueryParams = new Dictionary<string, string>();
                    foreach (var v in req.Query)
                    {
                        reqQueryParams.Add(v.Key.ToLower(), v.Value.ToString());
                    }
                parseQueryAPIRequest.queryAPIRequest.ContinuationToken = reqQueryParams?.Where( x => x.Key == Enums.HttpRequestUrlParameters.ContinuationToken).Select(x => x.Value).FirstOrDefault()?.ToString();
                    string? strParameter = GetJsonElement(requestBody, Enums.HttpRequestUrlParameters.JsonParameter);
                    if (strParameter != null)
                    {
                        var dicParameters = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(strParameter);
                        parseQueryAPIRequest.queryAPIRequest.QueryParameter = new Dictionary<string, string>();
                        if (dicParameters?.Count > 0)
                            foreach (var item in dicParameters)
                            {
                                foreach (var kvp in item)
                                {
                                    parseQueryAPIRequest.queryAPIRequest.QueryParameter.Add(kvp.Key, kvp.Value.ToString());
                                }
                            }
                    }
                    parseQueryAPIRequest.queryAPIRequest.req = req;
                parseQueryAPIRequest.queryAPIRequest.SubscriptionKey = req.Headers["SubscriptionKey"].ToString()?? "";
                parseQueryAPIRequest.queryAPIRequest.ClientId = req.Headers["ClientId"].ToString()?? "";
                parseQueryAPIRequest.queryAPIRequest.TransactionId = CommonModels.GlobalTransactionID.TransactionID;
                parseQueryAPIRequest = ValidationQueryAPI.ValidatePartitionKeyFilterApplied(parseQueryAPIRequest,req ,connection);
                parseQueryAPIRequest = UpdateCosmosDBPartitionKeytoQuery(parseQueryAPIRequest, connection.GetConfigPartitionKeys());
                }
#pragma warning disable
                return parseQueryAPIRequest;
            }
            catch (Exception )
            {
             return parseQueryAPIRequest;
            }

        }
        //Ignore the Hypen partition key and generate the query with actual cosmosDB partition key names
        public static ParseQueryAPIRequest UpdateCosmosDBPartitionKeytoQuery(ParseQueryAPIRequest? parseQueryAPIRequest ,  List<ConfigPartitionKeys>? cosmosDBConfigs)
        {
            foreach (var kvp in cosmosDBConfigs.Where(x => x.container.Equals(parseQueryAPIRequest.queryAPIRequest.Container, StringComparison.OrdinalIgnoreCase) && x.database.Equals(parseQueryAPIRequest.queryAPIRequest.Database, StringComparison.OrdinalIgnoreCase)))
            {
                if (parseQueryAPIRequest?.queryAPIRequest?.query != null && Regex.IsMatch(parseQueryAPIRequest?.queryAPIRequest?.query, kvp?.partitionsKeyHypenAlias?.FirstOrDefault().Key, RegexOptions.IgnoreCase))
                {
                    // Replace only the found/matched text with your replacement value
                    parseQueryAPIRequest.queryAPIRequest.query = Regex.Replace(
                        parseQueryAPIRequest?.queryAPIRequest?.query,
                        kvp?.partitionsKeyHypenAlias?.FirstOrDefault().Key,
                        kvp?.partitionsKeyHypenAlias?.FirstOrDefault().Value,
                        RegexOptions.IgnoreCase
                    );
                }
            }
            return parseQueryAPIRequest;
        }
#pragma warning restore

        private static string? GetJsonElement( string requestBody,string Keyword)
        {
            JsonDocument document = JsonDocument.Parse(requestBody);
            JsonElement root = document.RootElement;
            return TryGetPropertyCaseInsensitive(root, Keyword, out JsonElement queryElement);  
        }
        public static string TryGetPropertyCaseInsensitive(JsonElement element, string propertyName, out JsonElement value)
        {
            string propertyNameLower = propertyName.ToLower();
            foreach (JsonProperty property in element.EnumerateObject())
            {
                if (property.Name.ToLower() == propertyNameLower)
                {
                    value = property.Value;
                   return value.ToString();
                }
            }
            value = default;
            return string.Empty;
        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions.QueryAPILogic;
using SpokeAPI.Models;
using SpokeAPI.Utils;

using System.Text.Json;
using System.Web;
using static SpokeAPI.Models.QueryAPIModel;
using static SpokeAPI.Utils.Enums;

namespace SpokeAPI.Interfaceimplementation.Functions
{
    public class QueryAPI : IQueryAPI
    {
        public async Task<IActionResult> GetQueryResult(HttpRequest req, ILogger<SpokeAPI.Functions.QueryAPI> _logger, IConnection connection)
        {
            try
            {
                
                ParseQueryAPIRequest? parseQueryAPIRequest = new();
                QueryAPIRequest queryAPIRequest = new();
                QuerySearchResponse querySearchResponse = new();
                parseQueryAPIRequest.queryAPIRequest = queryAPIRequest;
                parseQueryAPIRequest.queryAPIRequest.SubscriptionKey = req.Headers["SubscriptionKey"].ToString()??" "  ;
                parseQueryAPIRequest.queryAPIRequest.TransactionId = CommonModels.GlobalTransactionID.TransactionID??" ";
                parseQueryAPIRequest.queryAPIRequest.ClientId = req.Headers["ClientId"].ToString();
                _logger.LogInformation(EnumsLog.QueryAPI.Initiate_GetQueryResult_method, parseQueryAPIRequest.queryAPIRequest.SubscriptionKey, parseQueryAPIRequest.queryAPIRequest.TransactionId);
                _logger.LogInformation(EnumsLog.QueryAPI.InitiateDataBaseConnection, parseQueryAPIRequest.queryAPIRequest.SubscriptionKey, parseQueryAPIRequest.queryAPIRequest.TransactionId);
                CosmosClient client = connection.GetReadCosmosClient();
                _logger.LogInformation(EnumsLog.QueryAPI.InitiateDataBaseConnection, parseQueryAPIRequest.queryAPIRequest.SubscriptionKey, parseQueryAPIRequest.queryAPIRequest.TransactionId);
                Container SearchContainer;
                QueryAPIResult queryAPIResult = new();
                _logger.LogInformation(EnumsLog.General.Validating_user_input, parseQueryAPIRequest.queryAPIRequest.SubscriptionKey, parseQueryAPIRequest.queryAPIRequest.TransactionId);
                 parseQueryAPIRequest = await ReadHttpRequest.ParseHttpRequestAsync(req, connection);
              if (parseQueryAPIRequest.functionValidation?.Message != null && parseQueryAPIRequest.functionValidation.Success == false)
                {
                    _logger.LogInformation(EnumsLog.General.Validation_failed, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey, parseQueryAPIRequest?.queryAPIRequest?.TransactionId);
                    return new ObjectResult(CommonMethod.ValidationErrorReponse(parseQueryAPIRequest?.functionValidation.ResponseCode??"", parseQueryAPIRequest?.functionValidation.ResponseCodeDescription??"", parseQueryAPIRequest?.functionValidation?.Message ?? ""))
                    {
                        StatusCode = 400
                    };
                }
                _logger.LogInformation(EnumsLog.General.Validation_success, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey, parseQueryAPIRequest?.queryAPIRequest?.TransactionId);
                int intSearch = 0;
                List<dynamic> items = new List<dynamic>();
                var TotalTimeProperySearchContainerSearch = 0;
                var ProperySearchRequestCharge = 0.00;
                string?  parameter = "";
                try
                {
                 
                    _logger.LogInformation(EnumsLog.QueryAPI.InitiateDataBaseConnection, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey, parseQueryAPIRequest?.queryAPIRequest?.TransactionId);
                    SearchContainer = client.GetContainer(parseQueryAPIRequest?.queryAPIRequest?.Database, parseQueryAPIRequest?.queryAPIRequest?.Container);
                    QueryDefinition queryDefinition = new QueryDefinition(parseQueryAPIRequest?.queryAPIRequest?.query);
                 
                    if (parseQueryAPIRequest?.queryAPIRequest?.QueryParameter != null)
                        foreach (var v in parseQueryAPIRequest.queryAPIRequest.QueryParameter)
                        {
                            queryDefinition.WithParameter(v.Key, v.Value);
                            parameter = parameter + " " + v.Key + ":" + v.Value;
                        }
                    _logger.LogInformation(EnumsLog.QueryAPI.InitiateQuery, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey, parseQueryAPIRequest?.queryAPIRequest?.TransactionId, parseQueryAPIRequest?.queryAPIRequest?.query, parameter);
                    var queryOptions = new QueryRequestOptions { MaxItemCount = Convert.ToInt32(connection.MaxItemCount) };
                    string? continuationToken = parseQueryAPIRequest?.queryAPIRequest?.ContinuationToken ?? null;
                    FeedIterator<dynamic> queryResultSetIterator = SearchContainer.GetItemQueryIterator<dynamic>(queryDefinition, continuationToken: continuationToken, queryOptions);
                    while (queryResultSetIterator.HasMoreResults)
                    {
                     
                        FeedResponse<dynamic> currentResultSet = await queryResultSetIterator.ReadNextAsync();
                        continuationToken = currentResultSet.ContinuationToken;
                        foreach (var item in currentResultSet)
                        {
                            intSearch++;
                            items.Add(item);
                        }
                        ProperySearchRequestCharge = ProperySearchRequestCharge + currentResultSet.RequestCharge;
                        TotalTimeProperySearchContainerSearch = TotalTimeProperySearchContainerSearch + currentResultSet.Diagnostics.GetClientElapsedTime().Milliseconds;
                        break;
                    }
                    queryAPIResult.TotalRequestChargeQueryAPI = ProperySearchRequestCharge;
                    queryAPIResult.TotalTimeQueryAPISearch = TotalTimeProperySearchContainerSearch;
                    if (queryAPIResult.TotalTimeQueryAPISearch != 0)
                    _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey, "N/A", EnumsLog.ApiType.QueryAPI, parseQueryAPIRequest?.queryAPIRequest?.Database, parseQueryAPIRequest?.queryAPIRequest?.Container, queryAPIResult.TotalTimeQueryAPISearch, queryAPIResult.TotalRequestChargeQueryAPI, parseQueryAPIRequest?.queryAPIRequest?.TransactionId);
                    _logger.LogInformation(EnumsLog.QueryAPI.QuerySuccessful, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey, parseQueryAPIRequest?.queryAPIRequest?.TransactionId);
                    querySearchResponse.responseCodeDescription = Enums.ResponseCodeDescription.Success;
                    querySearchResponse.responseCode = Enums.ResponseCode.Success;
                    querySearchResponse.responseJson = items;
                    if (items.Count == 0)
                    { 
                    querySearchResponse.responseCodeDescription = Enums.ResponseCodeDescription.RecordNotFound;
                    querySearchResponse.responseCode = Enums.ResponseCode.NoResultFound;
                    }
                    string? encodedJson = HttpUtility.UrlEncode(continuationToken);
                    querySearchResponse.ContinuationToken = encodedJson ?? null;
                    return new OkObjectResult(JsonDocument.Parse(JsonConvert.SerializeObject(querySearchResponse)));

                }
                catch (Exception ex)
                {
                    string? errorMessage = string.Empty;
                    if(ex.GetType().Name.Contains("CosmosException") && ((Microsoft.Azure.Cosmos.CosmosException)ex).StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        errorMessage = ex.InnerException?.Message.ToString()?? Enums.GeneralMessages.InternalErrorOccurredPleasecontactSupport;
                        return new ObjectResult(CommonMethod.ValidationErrorReponse(ResponseCode.ValidationError, ResponseCodeDescription.ValidationError, errorMessage ?? ""))
                        {
                            StatusCode = 400
                        };
                    }
                    if (string.IsNullOrWhiteSpace(ex.InnerException?.ToString()))
                        errorMessage = Enums.GeneralMessages.InternalErrorOccurredPleasecontactSupport;
                    else errorMessage = ex.InnerException.Message.ToString();
                    return new ObjectResult(CommonMethod.QueryAPIException(_logger, ex, errorMessage, parseQueryAPIRequest?.queryAPIRequest?.SubscriptionKey?? "", parseQueryAPIRequest?.queryAPIRequest?.TransactionId?? "", ResponseCode.InternalServerError, ResponseCodeDescription.InternalServerError))
                    {
                        StatusCode = 500
                    };
                }
                
            }
            catch (Exception ex)
            {
                return new ObjectResult(CommonMethod.QueryAPIException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID??"", ResponseCode.InternalServerError, ResponseCodeDescription.InternalServerError))
                {
                    StatusCode = 500
                };
            }

        }
    }
}

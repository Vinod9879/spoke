﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.QueryGenationLogic;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using SpokeAPI.Validations;
using System.Text.Json;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Utils.Enums;
using static SpokeAPI.Utils.EnumsLog;
using static SpokeAPI.Utils.CommonMethod;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Linq;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor;
using SpokeAPI.Functions;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.IndexSearchEngine;
using System.ComponentModel;


namespace SpokeAPI.Interfaceimplementation.Functions
{
    public class IndexSearch : IIndexSearch
    {

        public async Task<dynamic?> IndexSearchAsyc(HttpRequest req, IConnection _connection, ILogger<SpokeAPI.Functions.IndexSearch> _logger)
        {
            IndexSearchRequest? indexSearchRequest = new();
            IndexSearchPropertySearchResponse? indexSearchPropertySearchResponse = new IndexSearchPropertySearchResponse();
            IndexSearchValidationResponse _indexSearchIsvalidJson = new();
            IndexSearchValidationResponse _indexSearchValidationResponse = new();
            FunctionValidation _functionValidation = new();
            bool isValidJson = true;
            try
            {
                //Read the Http Request Return In case Invalid Json Request

                (IndexSearchRequest?, bool) readRequest = await IndexSearchCommonLogic.ReadIndexSearchRequestAsync(indexSearchRequest, req, _logger);
                isValidJson = readRequest.Item2;
                if (isValidJson == false)
                {
                    return _indexSearchIsvalidJson?.Create(ResponseCode.MalformedRequest ?? "", ResponseCodeDescription.MalformedRequest ?? "", IndexSearchMessages.InputBodyNotValid ?? " ");
                }
                indexSearchRequest = readRequest.Item1;


                //Validate the request return in case of validation error

                _functionValidation = await IndexSearchCommonLogic.ValidationAsync(indexSearchRequest, _connection, _logger);
                if (_functionValidation.Message != null && _functionValidation.Success == false)
                {
                    return _indexSearchValidationResponse.Create(ResponseCode.ValidationError, ResponseCodeDescription.ValidationError, _functionValidation.Message.ToString());
                }


                //Process the APN_Address/Document/Owner Request post validations

                if (indexSearchRequest?.Search_Type?.ToLower() == Enums.SearchType.AddressSearch.ToLower() || indexSearchRequest?.Search_Type?.ToLower() == Enums.SearchType.Document.ToLower() || indexSearchRequest?.Search_Type?.ToLower() == Enums.SearchType.Owner.ToLower())
                {
                    // Generate the DB Query based on the Http request Body for APN_Address/Document
                    
                    indexSearchRequest.query = BuildQuery(indexSearchRequest);
                    _logger.LogInformation(EnumsLog.IndexSearch.Created_query, indexSearchRequest.query, indexSearchRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);



                    //Common Search Engine handler for  Propery or Property_Search Fetch Based on requestbody 
                    // APN_Addess/Document/Owner

                    IndexCommonSearchEngineHandler indexCommonSearchEngine = new IndexCommonSearchEngineHandler();
                    var response = await indexCommonSearchEngine.IndexSearchEngineHandler(indexSearchRequest, _connection, _logger);

                    //If APN Address Search from Property container  return 1 Property data
                    //else Assign to Property_Search object  and return

                    if (string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.AddressSearch, StringComparison.OrdinalIgnoreCase)|| string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.Owner, StringComparison.OrdinalIgnoreCase))
                    {
                        if (response?.GetType().FullName.Contains(Enums.IndexSearchMessages.IndexSearchPropertyResponse))
                            return response;
                        else
                        {
                            indexSearchPropertySearchResponse = response;
                            return indexSearchPropertySearchResponse;
                        }

                    }
                    else
                        indexSearchPropertySearchResponse = response;
                    //If document search send the result to Document search engine for further process  and return the result

                    if (string.Equals(indexSearchRequest.Search_Type, Enums.SearchType.Document, StringComparison.OrdinalIgnoreCase))
                    {
                        DocumentSearchEngineHandler documentSearchEngineHandler = new DocumentSearchEngineHandler();
                        return await documentSearchEngineHandler.IndexSearchDocumentEngine(indexSearchRequest, indexSearchPropertySearchResponse, _connection, _logger);
                    }
                    return indexSearchPropertySearchResponse;

                }


                return indexSearchPropertySearchResponse;

            }
            catch (Exception ex)
            {
                return IndexSearchException(_logger, ex, indexSearchRequest?.SubscriptionKey ?? "", indexSearchRequest?.TransactionId ?? "", Enums.ResponseCodeDescription.InternalServerError, Enums.ResponseCode.InternalServerError, GeneralMessages.InternalErrorOccurredPleasecontactSupport);
            }

        }



        public IndexSearchPropertyResponse propertyContainerSearchRespose(QuerySearchResult SearchResult, IndexSearchRequest indexSearchRequest)
        {
            IndexSearchPropertyResponse indexSearchResponse = new IndexSearchPropertyResponse();
            if (SearchResult.CountResult == 1)
            {
                indexSearchResponse.responseCodeDescription = ResponseCodeDescription.Success;
                indexSearchResponse.responseCode = ResponseCode.Success;
            }
            else if (SearchResult.CountResult > 1)
            {
                indexSearchResponse.responseCodeDescription = ResponseCodeDescription.Success;
                indexSearchResponse.responseCode = ResponseCode.Success;
            }
            else
            {
                indexSearchResponse.responseCodeDescription = ResponseCodeDescription.RecordNotFound;
                indexSearchResponse.responseCode = ResponseCode.NoResultFound;
            }

            indexSearchResponse.responseJson = JsonDocument.Parse(JsonConvert.SerializeObject(SearchResult.JObjectResult));
            indexSearchResponse.searchInfo = indexSearchRequest.searchInfo;
            return indexSearchResponse;
        }


        public string BuildQuery(IndexSearchRequest? indexSearchRequest)
        {
            if(indexSearchRequest != null)
            return CreateQuery.APNFipsQuery(indexSearchRequest);
            else
                return string.Empty;
        }

    }
}

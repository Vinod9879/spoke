﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SpokeAPI.Functions;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions.PointedLookupLogic;
using SpokeAPI.Models;
using SpokeAPI.Utils;
using SpokeAPI.Validations;
using System.Dynamic;
using System.Numerics;
using System.Text.Json;
using static SpokeAPI.Models.CommonModels;
using static SpokeAPI.Models.IndexSearchModel;
using static SpokeAPI.Models.PointedLookupModel;
using static SpokeAPI.Utils.Enums;
using static SpokeAPI.Utils.EnumsLog;

namespace SpokeAPI.Interfaceimplementation.Functions
{
    public class PointedLookup : IPointedLookup
    {
        

        async Task<dynamic> IPointedLookup.LookupAsync(HttpRequest req, ILogger<PointLookup> _logger, IConnection connection)
        {
            _logger.LogInformation(EnumsLog.PointedLookup.Initiate_LookupAsync_method, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
            FunctionResponse _functionResponse = new();
            try
            {
               
                CosmosClient client = connection.GetReadCosmosClient();
                Container SearchContainer;
                Dictionary<string, string> reqQueryParams = new Dictionary<string, string>();
                foreach (var v in req.Query)
                {
                    if (v.Key.ToLower() == AdditionalKeywords.FNF_DocType.ToLower())
                        reqQueryParams.Add(v.Key.ToLower(), v.Value.ToString().ToUpper());
                    else
                        reqQueryParams.Add(v.Key.ToLower(), v.Value.ToString());
                }
               
                  PointedLookupRequest pointedLookupRequest = OrderPartitionKey.OrderPartitionKeyLogic(reqQueryParams,req,connection);
                _logger.LogInformation(EnumsLog.PointedLookup.Ordering_PartitionKey_and_assigning_to_pointedLookupRequest_, pointedLookupRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                pointedLookupRequest.ReqParameter = reqQueryParams;
                FunctionValidation functionValidation = new FunctionValidation();
                _logger.LogInformation(EnumsLog.General.Validating_user_input, pointedLookupRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                functionValidation = await ValidationPointedLookup.ValidatePointedSearchInput(pointedLookupRequest, _logger, connection).ConfigureAwait(false);
                if (!string.IsNullOrWhiteSpace(functionValidation.SubscriptionDetails))
                    _logger.LogInformation(General.Checkaccesscomplete + functionValidation.SubscriptionDetails + General.TransactionId + CommonModels.GlobalTransactionID.TransactionID + General.SubscriptionID + req.Headers["SubscriptionKey"].ToString());
                if (functionValidation.TotalRequestChargeCheckAccess != 0.00)
                    _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails,
                       pointedLookupRequest.SubscriptionKey, "N/A", EnumsLog.ApiType.PointedLookup, connection.SubscriptionDatabase, connection.SubscriptionContainer, functionValidation.TotalTimeCheckAccess, functionValidation.TotalRequestChargeCheckAccess, CommonModels.GlobalTransactionID.TransactionID);
                if (functionValidation.Message != null && functionValidation.Success == false)
                {
                    _logger.LogInformation(EnumsLog.General.Validation_error, pointedLookupRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
#pragma warning disable
                    return _functionResponse.Create(Enums.ResponseCode.ValidationError, Enums.ResponseCodeDescription.ValidationError, msg: functionValidation.Message.ToString());
#pragma warning restore
                }
                _logger.LogInformation(EnumsLog.General.Validation_success, pointedLookupRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
               PointedLookupResponse pointedLookupResponse = new();
                try
                {
                    
                    SearchContainer = client.GetContainer(DBVersionTranslator.GetCurrentDBVersion(pointedLookupRequest.Database,connection), DBVersionTranslator.GetCurrentContainerVersion(pointedLookupRequest.Container, connection));
                    ItemResponse<ExpandoObject> response = await SearchContainer.ReadItemAsync<ExpandoObject>(pointedLookupRequest.IDValue, pointedLookupRequest.PartitionKey);
                    _logger.LogInformation(EnumsLog.PointedLookup.Pointed_look_up_sucessfully_retrived_the_data, pointedLookupRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                    pointedLookupResponse.responseJson = JsonDocument.Parse(JsonConvert.SerializeObject(response.Resource));
                    pointedLookupResponse.responseCodeDescription = ResponseCodeDescription.Success;
                    pointedLookupResponse.responseCode = ResponseCode.Success;
                    var v = response.Diagnostics.GetClientElapsedTime().Milliseconds;
                    if (response.RequestCharge != 0.0)
                        _logger.LogInformation(EnumsLog.TotalTimeAndRequestChargeLog.TotalTimeAndRequestChargeLogDetails,
                        pointedLookupRequest.SubscriptionKey, "", EnumsLog.ApiType.PointedLookup, pointedLookupRequest.Database, pointedLookupRequest.Container, v.ToString(), response.RequestCharge.ToString(), CommonModels.GlobalTransactionID.TransactionID);
                }
                catch (Exception ex)
                {
                    ex.ToString();
                    if (ex.Message.Contains("404"))
                    {
                        _logger.LogInformation(EnumsLog.General.ResourcesContainer_not_found, pointedLookupRequest.SubscriptionKey, CommonModels.GlobalTransactionID.TransactionID);
                        pointedLookupResponse.responseJson = JsonDocument.Parse(JsonConvert.SerializeObject(""));
                        pointedLookupResponse.responseCodeDescription = ResponseCodeDescription.RecordNotFound;
                        pointedLookupResponse.responseCode = ResponseCode.NoResultFound;
                        _logger.LogError(Enums.HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + pointedLookupRequest.SubscriptionKey + ex.ToString() + " " + CommonModels.GlobalTransactionID.TransactionID);

                    }
                    else
                    {
                        _logger.LogError(Enums.HttpRequestUrlParameters.SubscriptionKey + Enums.QueryKeyword.Space + pointedLookupRequest.SubscriptionKey + ex.ToString() + " " + CommonModels.GlobalTransactionID.TransactionID);
                        return CommonMethod.PointedLookupException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID ?? "", ResponseCode.InternalServerError, GeneralMessages.InternalErrorOccurredPleasecontactSupport);
                    }
                }
                return pointedLookupResponse;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("503"))
                {
                    _logger.LogError(EnumsLog.General.Service_not_found_Please_check_service_client_and_container, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID);
                }
                return CommonMethod.PointedLookupException(_logger, ex, req.Headers["SubscriptionKey"].ToString(), CommonModels.GlobalTransactionID.TransactionID??"", ResponseCode.InternalServerError, GeneralMessages.InternalErrorOccurredPleasecontactSupport);
            }

        }
    }
}

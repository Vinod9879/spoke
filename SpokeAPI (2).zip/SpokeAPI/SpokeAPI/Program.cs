using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SpokeAPI.Interface.Connection;
using SpokeAPI.Interface.Functions;
using SpokeAPI.Interfaceimplementation.Functions;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic;
using SpokeAPI.Interfaceimplementation.Functions.IndexSearchLogic.SearchProcessor;
using SpokeAPI.Utils;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices(services =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
        services.AddSingleton<IManageSubscriptions, ManageSubscriptions>();
        services.AddSingleton<IIndexSearch, IndexSearch>();
        services.AddSingleton<IPointedLookup, PointedLookup>();
        services.AddSingleton<IManageCosmosDBObject, ManageCosmosDBObject>();
        services.AddSingleton<IQueryAPI, QueryAPI>();
        services.AddSingleton<IConnection,Connections>();
       // services.AddSingleton<IIndexSearchSearchHandler, SearchProcessorMultiCriteriaSearch>();
        services.Configure<LoggerFilterOptions>(options =>
        {
            // The Application Insights SDK adds a default logging filter that instructs ILogger to capture only Warning and more severe logs. Application Insights requires an explicit override.
            // Log levels can also be configured using appsettings.json. For more information, see https://learn.microsoft.com/en-us/azure/azure-monitor/app/worker-service#ilogger-logs
            LoggerFilterRule? toRemove = options.Rules.FirstOrDefault(rule => rule.ProviderName
                == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");

            if (toRemove is not null)
            {
                options.Rules.Remove(toRemove);
            }
        });
    })
    .Build();

host.Run();
